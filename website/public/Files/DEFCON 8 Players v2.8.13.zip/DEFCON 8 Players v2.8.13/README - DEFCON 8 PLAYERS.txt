------------------------------------------------------
DEFCON: 8 Players Prerelease v2.8.13
By: Sievert, FasterThanRaito, Wan May and KezzaMcFezza
------------------------------------------------------

This is a modified build of the game DEFCON: Everybody Dies by Introversion Software. This build is meant to overcome the six-player limit hardcoded into the vanilla game and accomodate up to eight different players simultaneously.
This mod also works an an all-around enhancement for the game which fixes some territory gaps, bad city data, UI and UX improvements, expanded color options, and overall polish.
It is built on top of MINICOM by bert_the_turtle, the minimal community enhanced version of DEFCON which includes bugfixes, performance improvements, and improvements to unit behavior.

This package contains the following files:
- a data folder which contains new territories, travel nodes, sailable, unit outlines/ghosts, coastlines, and city data
- a mods folder which packages MINICOM's vanilla reversion mods
- the DEFCON Expanded Edition executable
- a link to the installation tutorial on KezzaMcFezza's YouTube channel
- this README
- the DEFCON developer license agreement
- a troubleshooting guide in case of certain technical issues

Installation Guide:
[tbd]

Notes:
- All players must be running the same build of the game.
- Mods that require MINICOM to run will also run on this build of the game.
- Mods that make changes to gameoptions.txt will not run on this build of the game.
- This mod will NOT work unless the copy of DEFCON is purchased for Introversion Software or a licensed distributor (such as Steam).
- The license agreement for DEFCON source code applies. End users are allowed to modify the modded game subject to the same license.
- This is NOT a cracked version of the game. Code relating to purchase authentication is not modified in any way. You still need to buy the game.

Visit our website! https://defconexpanded.com/

Foundational Work:
- Introversion Software (DEFCON)
- bert_the_turtle (MINICOM)
- Fiiral (Initial 8-player build)

Mod Developers:
- Sievert
- FasterThanRaito
- wan may
- KezzaMcFezza

Website Developers:
- KezzaMcFezza
- Nexustini
- DEVIL

Prerelease Testers:
- Annatar
- Ben Herr/Corporation
- Colimin
- Erroneous
- GoodNight
- Gyarados
- Jackolite
- ItsEK
- KezzaMcFezza
- Laika
- Lævateinn
- Lord Haw Haw
- MemeWarrior
- Nexustini
- photophobic/Nicole
- Rad
- Red Duck/demo0096
- Sierra
- Vault Tec/Idealist0
- Very Fine Art
- zak

MINICOM Developers:
- amoskvin
- bert_the_turtle
- jhkrischel
- multimania
- sysctl

---------
Changelog
---------

Prerelease v1.0 (Released 6/30/2024):
- Added two new player colors, pink and purple
- Added support for eight teams in the lobby and in-game
- Changed the maximum number of teams in the server display window to eight to properly show empty/full player slots
- Relabelled team "Turq" to "Cyan"
- Changed territories to accomodate new teams: North America, South America, Europe+Greenland, Russia+Kazakhstan, Middle East+North Africa, Sub-Saharan Africa, South Asia+Oceania, and East Asia
- Various minor changes to territories, such as cleaner borders and sensible territory inclusion
- Changed travel nodes around the Philippines to allow passage around and into the South China Sea rather than straight through
- Added travel nodes to connect through the Bering Strait to allow easier passage
- Rounded out China's coastline so that random cities don't appear to be in the middle of the Taiwan strait
- Rebalanced populations by metropolitan area, changes are minor but city data should be more accurate proportionally
- Changed the capital for the Philippines to Manila instead of Quezon City
- Fixed bugged cities in Algeria and Benin, they now show properly instead of random British cities
- Fixed Vladivostok, Miami and Copenhagen not placing properly
- Added Pyongyang to the cities file for North Korea
- Moved Jeddah onto land so that it does not appear to be in the middle of the Red Sea
- Moved San Francisco closer to the west coast of the United States
- Moved Las Vegas to its proper place, it was east of Santa Fe before
- Deleted a duplicate entry of St. John, New Brunswick
- Deleted a duplicate entry of Manila, Philippines
- Deleted Oroumich, Iran from the cities list as it is the same city as Rezaiyeh 
- Deleted Kananga, Zaire from the cities list as it is the same city as Luluabourg 
- Cities which previously included a province or state in its name no longer do so
- Renamed certain cities with bizarre spellings and formatting
- Unabbreviated USA and USSR when country names are displayed, now they are simply displayed as "United States" and "Soviet Union"
- North and South Korean cities properly display "North Korea" and "South Korea" instead of just "Korea"
- North and South Vietnamese cities display "North Vietnam" and "South Vietnam" instead of just "Viet Nam"
- Shortened various country names in city data that were unnecessarily long (East Germany, Libya, Syria, Cambodia)
- Post-Soviet states have all their cities properly marked as their respective country rather than just the capital and major cities
- Renamed Ho Chi Minh City to Saigon and marked it as a capital so that it would not get overwritten by Phnom Penh during city placement
- Added DEFCON Discord link as splash text
- Updated each localization to properly display color text and tutorial text for correct matchups
- Changed text for DEFCON version on main menu to display build version and developers

Prerelease v1.1 (Released 7/7/2024):
- Removed the panic button/boss key as it doesn't have a real use and just confuses people unfamiliar with it 
- Added a custom icon to the program to differentiate it from vanilla DEFCON 
- Fixed right-facing airbases/carriers/subs from having offset smallnuke/smallbomber/smallfighter sprites (bug that popped up in Prerelease v1.0)
- Moved modified game resources into a new data directory instead of having to activate a companion mod
- Packaged a modified version of All Cities mod with the build
- Packaged an 8-Player Cold War mod by FasterThanRaito with the build
- Gave Sakhalin to Russia's territory
- Gave Cuba, Hispaniola, Puerto Rico, and Jamaica to North America
- Shaved some territory off of southern Spain to avoid Europe placing in Morocco
- Changed travel nodes around the Carribean islands to allow for naval passage into the Gulf of Mexico and the Carribean Sea
- Deleted Kermanshah, Iran from the cities list as it is the same city as Bakhtaran
- Changed the Rolling Demo to show 8 players instead of 3
- Added an installation video guide

Prerelease v1.2 (Released 7/14/2024):
- Changed the game base from DEFCON to MINICOM
- Undid MINICOM's feature which stored preferences and authkey files in Documents/My Games
- Reformat and clean up MINICOM's packaged vanilla reversion mods, they will be the only mods packaged from the start
- Removed Cold War: 8 Players and All Cities: 8 Players from the package, they will be available on the modlist
- Removed Panic Key dropdown in Options since functionality was removed in Prerelease v1.1
- Added a game option which lets you scale the number of units in a game. Mostly intended to allow cancelling out more units on a larger world scale
- Moved Discord splash message to localization files and given proper translations instead of being hardcoded to English
- Fixed bug where the last language in the options menu would display twice

Prerelease v1.3 (Released 7/21/2024):
- Added support for 16 different team colors
- Added option for unit outlines in graphics settings to make them easier to see against the water
- Changed unit ghost texture so that it is hatched. This makes ghosts distinct from the light gray team color
- Packaged a temporary 7-player setup until we can get arbitrary numbers of players working

Prerelease v2.8.7 (Released 7/28/2024):
- Created three builds (temporarily) for 8, 10, and 16 players
- Redid version schema
- Added a bomber launch option that allows for launching without a nuke loaded
- Added a color picker in the alliance window for quickly swapping to the desired color - you can't swap to colors in use and if you're in an alliance, more than half must vote for the change
- Made the alliances window open in the center of the screen
- Slightly increased the height of the graphics option window to allow space for the new graphical options

Prerelease v2.8.8 (Released 8/4/2024):
- Changed territory distribution based on opinions from more experienced players, now the setup is near identical to the original aside from splitting asia into west and east, and adding Oceania
- Packaged some 7-player and 8-player setups for testing

Prerelease v2.8.9 (Released 8/11/2024):
- Added troubleshooting guide in case people crash randomly during game as sometimes the necessary C++ redistributables are missing or have corrupted .dll files
- Added an outline texture for blip.bmp so it does not show an error texture if unit outlines are turned on
- Fixed color picker window getting longer when a vote is active
- Graphical option to display population/dead in three ways (thousands/millions/individuals)
- Graphical option to toggle display of travel nodes and AI markers so that you don't have to edit the preferences.txt each time
- Added a unique message to display when trying to select empty bomber launch mode when it is disabled, similar to an invalid DEFCON level message
- Fixed Yokohama appearing in the wrong place in Japan
- Edited travel nodes around Svalbard to make commanding units near it less likely to take long ways around for no good reason
- Edited travel nodes around Indonesia to make the Karimata Strait traversible, connecting the Java Sea to the South China Sea
- Edited some coastlines for Borneo, will be adjusted some more in the future
- Fixed Jerusalem not appearing
- Fixed Sapporo not appearing
- Standardized sailable.bmp to avoid future annoyances with inconsistent edges
- Fixed the outline stretching slightly below ghosted units

Prerelease v2.8.10 (Released 8/18/2024):
- Fixed ghosted silos having their state changes immediately visible even without radar coverage
- Added AI markers to the Antarctic coast
- Made the Denmark Strait, Torres Strait, Tsugaru Strait, Tsushima Strait, Vilkitsky Strait, and Kara Strait traversible. The Sea of Japan and Kara Sea are accessible again
- Fix crashes involving attempting team switching to nonexistent player slots
- Character limit for chat is now 1000 characters

Prerelease v2.8.11 (Released 8/31/2024)
- Fixed broken main menu crawl text showing apostraphes and dashes as garbage data for the English localization
- Adjusted territories of NA/SA/Africa/Middle East to get coastal/border cities to appear properly
- Slight population readjustment
- Fixed Nouakchott and Vancouver not appearing
- Added companion mods for setups with 4-7 players

Prerelease v2.8.11.2 (Released 9/8/2024)
- Increased player slots to 10 to differentiate servers

Prerelease v2.8.12 (Released 9/21/2024)
- Started building on Visual Studio 2013 for improved performance and stability
- Added a Linux build
- Added an installer for Windows
- Fixed non-host spectator names always showing as "Spectator". This was an issue in base MINICOM (thanks to bert_the_turtle for the patch!)
- Fixed spectators who join mid-game always showing as "joining...". This was an issue is base MINICOM (thanks to bert_the_turtle for the patch!)
- Added a new "Victory Mode" along Game Mode and Score mode, allowing for team victories as score is calculated cumulatively based on team and assigned to all members. The game announces the winning team color at the end rather than a single victor.
- Made it so spectators can view private messages instead of just alliance chat
- Changed the population density overlay to use population.bmp instead of explosion.bmp to avoid problems with modded explosion sprites
- Fixed default water showing even when shaded is selected if using 16-bit color depth
- Fixed orders screen not showing an order from the carrier or airbase if a nukeless bomber is queued to launch
- Added KezzaMcFezza as a creator on the main menu
- Redirected the "Get more mods" button to the modlist on Kezza's website
- Redirected the network troubleshooting button to the DEFCON Discord
- Redirected broken game purchase links for demo users to the DEFCON Steam page

Prerelease v2.8.13 (Released 10/5/2024)
- Fixed crashing issue on some systems when a global message was rendered (thanks to bert_the_turtle for the suggestion to use snprintf instead of sprintf!)
- Added main menu scroll for developers and testers
- Added graphics option for ring explosions
- Added Bastard Diplomacy as a game mode
- Changed default configuration for Diplomacy and Bastard Diplomacy so that Radar Sharing is selective

Future Plans (Not final, kind of a wishlist):
- Add a Mac OS build
- Package setups for 2-16 players
- Add an option in-game to allow for selecting a value for Max Teams
- Add a map selector
- Radar range bmp toggle
- Ability to toggle the seam on and off
- More drawing tools - cirlces, line segments, et cetera
- More Game Modes (Bastard Diplomacy, Anonymous Diplomacy, etc.)
- Spectator ability to draw and see other alliances whiteboards
- Game option to revert missile pathfinding to its legacy algorithm instead of corrected shortest path
- Ping Kezza's website for the modlist before opening. If ping fails, open Google Sheets modlist
- Overhaul game tutorial to teach better strategy
- Re-add support for Polish and Russian languages
- Update all localization files (will be done at the end of the project)

Known Issues
- Travel node graph connecting over land across the planet instead of the seam. This is purely visual and does not affect unit movement. This is an issue in base MINICOM
- Cheating issue caused by stealth editing of files. This is an issue in base MINICOM
- Some areas where ship pathfinding causes abnormal things to happen such as pathfinding back and forth in a loop
- Spectators who join mid-game being able to access the alliances window. This is an issue in base DEFCON and will cause a crash for all players if they attempt to use the color picker.
- If one adds AI, then sets themselves to spectator, and then does NOT add back an AI for Player 0, the game will crash at DEFCON 4. This is an issue in base MINICOM
- In the language selection dropdown in the options menu, Spanish appears twice. This is an issue in base DEFCON