====================
DEFCON Canada Map version 1.0
====================

The six territories in this mod are:

BC/Yukon
Alberta/Northwest Territories
Saskatchewan/Mantioba/Nunavut
Ontario
Quebec
Martime provinces

To install, create a folder called "mods" in the directory that Defcon is installed. Place the 
Canada folder you extracted into that mod folder.

If playing against computer opponents, it would be a good idea to play with the survivor scoring
mode on, otherwise one CPU ususally racks up a huge score early.