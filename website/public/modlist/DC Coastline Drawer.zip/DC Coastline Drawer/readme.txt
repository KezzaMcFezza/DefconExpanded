=================================
=    DEFCON COASTLINE DRAWER    =
=========== VERSION ? ===========
= README FILE    6th of October =
=================================

= 1. TABLE OF CONTENTS =
========================
1. Table of Contents
2. Files in archive
3. Who? What? When? Where?
4. How to install
5. Version History


= 2. FILES IN ARCHIVE =
=======================
ARCHIVE NAME: dccoastlinedrawer.zip

dccoastlinedrawer.exe			The application
readme.txt				This file

If there are any other files/directories than these in the archive, quickly delete the archive and all files extracted, but not listed above, then do a full virus scan. If you still want to use this mod, please download a fresh .zip archive file from http://defcongame.tk/


= 3. WHO? WHAT? WHEN? WHERE? =
==============================
The "DEFCON CoastlineDrawer" is a small application for quickly and painlessly drawing coastlines for the game (more specifically, to 'data\earth\coastlines.dat'.
If an existing 'coastline.dat' is found, the application appends every new coastline to that. Else it just creates a new 'data\earth\coastlines.dat' file.

The program reads current coastlines from "data\earth\coastlines.dat", and draws these to the screen.
This way, you can easily see where you've drawn, and what places lack coastlines.

By default, the program loads the map from "data\graphics\map.bmp" (or uses it's internal high-res map.bmp if that file doesn't exist).
By using the menu, you can load a different map file as a background, thus making the tool exponentially more useful.

Anyway, more info can be found at:
http://defcongame.tk/


= 4. HOW TO INSTALL =
=====================
Unzip this archive in the main DEFCON directory. Then just run the application.

Click anywhere with the left mouse button to start drawing.
Keep clicking with the left mouse button to continue drawing the same coastline.
Right click to place the current line and stop drawing that coastline.


= 5. Version History =
======================

release 6th of October