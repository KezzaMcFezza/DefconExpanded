Defcon Mod: The man in High Castle Version 2.5 
Created by: Mirdan2102

Description: This mod is based on Amazon's TV Show "The Man In High Castle" (which based on book also). It tells us about an alternative universe where Axis won WW2.
The world split into two superpowers: The Great Nazi Reich and Imperial Japan. Two countries lived in peace for more than 20 years, but in 1962 all changed. 
Most of the Nazi generals think that declaring a peace with Japan was mistake and they are only true nation who deserves to rule this world. 
The only wall which still hold this ruining castle of peace is... Adolf Hitler (seriously?). He believes that the peace with Japan still making sense. 
But he is dying now, and Japanese know what that mean for them...

Mod changes:
1)Territories:

1.Great Nazi Reich, which holds whole Europe, Africa, Middle east, Venezuela, Panama, Guyana and South Brazil. Easiest to play because of huge territory and a lot of cities with small populations;

2.American Reich which holds East part of USA, Canada and whole Greenland. You can be with Reich or trying to make own Nazi country like Reichsmarshal John Smith. Easy in default mode if you shoot first. Hard in bigworld;

3.Japanese Empire. You are an old Emperior Hirohito who seeing how your empire goes down. Can you hold Japan, Manjo-go, East China, Kamchatka, Vladivostok, India, Australia, Oceania and Chile-Equador's coast at once? 
Well you can! This factuon isn't so easy as Reich, but you still have a lot of advances like huge territories which splited by seas and Ocean. At least you always can to run in Australia :)

4.Japanese Pacific States. Like your East brothers, you can be with Japan, or start a Black Communist rebellion. Play carefully. Your cities in California, East Canada and Alaska have extremely huge populations, 
so few nukes can kill most of your citizens.

5.China-Siberia. Well. Technically there are a lot of other countries in this commie heaven, but they are nothing without this two. You haven't fleet because you are minor faction who is here only for being giant border between empires. 
But they are focusing on America, so you have some time to take a revenge on Berlin for Moscow.

6.Last and my favourite: Neutral zone. It is a union between North Brazil, Columbia, Mexico and American Neutral states who trying to save all what they have. 
In this time Americans from Denver and Canon city trying to Rise a rebellion in one of two neighbors. You are alone, without fleet, on small territory with VERY strange borders and High population in all of your cities. 
All Countries are bordering with you (except Siberians of course). And you are near a total fallout.

2)New map style (also some changes with sailable territories);

3)New icons textures;

4)New units textures;

5)Team colors renamed to alliance names:

1.Red to Reichkommissariats;
2.Blue to US rebels;
3.Green to Chineese;
4.Yellow to Neutral zones;
5.Orange to Black communists;
6.Cyan to Imperial Japan;

6)Text-changes in Main menu:
1.Start New game renamed to Start new Blitzkrieg;
2.Join game renamed to declare a war;
7)Text-changes in Options:
1.Leave game renamed to surrender;
2.Player name renamed to Reichsmarschall Name;
3.Set Player name to Set Reichsmarschall Name;

7)New menu stile;

8)Map of cities Changed. Some new cities like Canon city, New Berlin and Karakas added;

9)New fonts don't belongs to me. They are from DMW 4.0 mod. this mod created by Synapse and modified by Experiment632.

That's all!

In future I will add some new sounds and fix bugs. And ofcourse redraw some Icons. If you have problems write them here https://www.reddit.com/r/defcongame/ 
under one of my posts.


Recomended Scenarios: 
1)Housman press the button:
Team red: Great Nazi reich-American-Reich;
Team cyan: Imperial japan-Pacific states ;
2)Housman press the button 2:
Team red: Great Nazi reich-American-Reich
Team cyan: Imperial japan-Pacific states ;
Team yellow: China_Siberia-Neutral zone ;
3)Black Communists Rebellion or American invasion:
Team red: Great Nazi reich-American-Reich;
Team orange: Pacific states;
Team cyan: Imperial japan;
4)American rebellion (Challenge for Great Nazi Reich or Imperial Japan):
Team red: Great Nazi reich;
Team blue: American-Neutral zone-Pacific states;
Team cyan: Imperial japan;
5)The last war in hummanities history (Challenge for Japan):
Team cyan: Imperial japan;
Team red: All other factions;