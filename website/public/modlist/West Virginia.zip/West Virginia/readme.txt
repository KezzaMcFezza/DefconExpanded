------------------------------
DEFCON: West Virginia Mod
By: Sievert
------------------------------

This mod replaces the world map with nothing but West Virginia. I made this in a day or so and recorded my mapping process so that you can see exactly how I've set up my workflow. I will post the video on the modlist later for reference in case anyone needs help bringing their ideas to life. That being said, I did my best to also make this a high-quality game experience, so I hope you don't just see this as an example mod.

The only snag that might be a little annoying to the player is that the nodes at the top of the map wont connect across the peninsula at the top of the map. Nodes are quite annoying. You will have to move your ships up to the passage first and then tell them to move across it. It's not terribly annoying but if you want to set your units and forget about them for a while you can't really do that.

I very much hope you enjoy my little mod. It's just a little something I made to showcase how I achieve the standards that I hold myself to when mapping. Please let me know if you think I can improve on something for the future.

Thanks,
	Sievert

----------
Changelog:
----------

v1.0: Initial release