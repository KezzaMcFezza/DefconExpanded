---------------------------------------
DEFCON - North America Mod - By Sievert
---------------------------------------

This mod replaces the playable world with a detailed map of North and Central America. Each terriory has a full roster of at least 50 cities with populations slightly rebalanced for gameplay reasons.
If you want to play with original unbalanced city population proportions, I've included a cities_irl.dat which you can swap between as you please. Please note that this will put some territories at a massive disadvantage.
The map features fully functioning travel nodes through the Northwest Passage and the West Indes. Movement through the Panama Canal and above Greenland is possible but requires human player micromanagement.
The Atlantic-Pacific reacharound is baked into DEFCON's source code and is impossible to remove in the vanilla executable.
Each city is marked as a captial in city.dat to override DEFCON's city placement distance requirements, so you probably want to disable "Show Country Names" in graphics settings.

Thank you very much for playing my mod. Please let me know if there's anything I can do to improve it. You can contact me via Discord if you'd like at my handle "megasievert". 
I sincerely hope you enjoy.

	-Sievert