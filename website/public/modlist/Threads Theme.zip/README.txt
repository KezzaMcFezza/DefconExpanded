------------------------------
DEFCON: Threads Theme Mod
By: Sievert
------------------------------

This mod is meant to replace the font with the one used in the nuclear war movie Threads. It also replaces the global message sounds to the typewriter text crawl sound effect the movie uses and the launch detection sounds to the Attack Warning Red signal used in the movie.

----------
Changelog:
----------
v1.0 (Released 10/11/2024)
- Initial release

v1.1 (Released 10/17/2024)
- Fixed some text in the main menu being capitalized unintentionally
- Muted the "Game Over" sound effect to achieve the effect of the text crawls turning silent after the attack scene in the movie