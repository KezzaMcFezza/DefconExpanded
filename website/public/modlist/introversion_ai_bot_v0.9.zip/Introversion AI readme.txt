Hi!

This readme belongs to the Introversion Bot for the Defcon AI.

All the up-to date information on the Defcon AI API can be found here:
http://www.introversion.co.uk/defcon/bots/index.html

Please refer to the documentation for info on how to get started. 
There's a quickstart guide for the impatient, so don't worry!


General Download and Installation Instructions:

If you don't have the bot-enabled Defcon version yet:
    * Windows demo: http://www.introversion.co.uk/defcon/
    * Bot-enabled Defcon executable and framework

   1. Download and install the Windows demo version of DEFCON.
   2. Unzipped the contents of the Defcon API zip file.
      Copy the contents of the zip file into the directory where you installed 
      Defcon, overwriting the original Defcon.exe (you can make a backup of that).

If you have installed the bot-enabled Defcon version:
    * Unzip the contents of the bot-zip file (which came with this readme) into 
      the AI folder of your Defcon directory, so that the DLL file is in a 
      subfolder of the AI folder. 
      Example:
      C:\DEFCON-Directory\AI\iv ai\ivai.dll
      C:\DEFCON-Directory\Defcon.exe
      ...
    1. Start Defcon.exe
    2. Start a new game or join another game.
    2. Select the bot from the drop-down list when you are in the game lobby.

Changelog:

===================
    IV AI v0.9
 8th December 2008
===================

Initial release.
Please report bugs to me (rb1006@doc.ic.ac.uk).
