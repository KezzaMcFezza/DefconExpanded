#pragma once

#include "dll/abstract_bot.h"
#include "bot/objects/fleet.h"
#include "bot/objects/object.h"
#include "bot/objects/world.h"
#include "tools/llist.h"
#include "tools/conditional_commands.h"

#include <hash_map>
#include <string>
#include <vector>

using namespace stdext;  // for hash_map

class Event;

class Bot : public AbstractBot
{
public:
	Bot();
	~Bot();
	virtual bool Update();
	virtual bool Initialise(Funct *f, std::vector< std::vector< std::string > > commandLineOptions);
	virtual void AddEvent(int _eventType, int _causeObjectId, int _targetObjectId, 
		int _unitType, float _longitude, float _latitude);
	 
    
    bool IsFriend(int teamId1, int teamId2);
	bool IsValidTeamId(int teamId);
	void CheckPanicState();
	void PlacementAI();
	bool CanAssembleFleet( int fleetType );
	bool CanAssembleFleet();
	void GetFleetMembers( int fleetType, int *ships, int *subs, int *carriers );
	bool AssembleFleet( int fleetType );
    int CountTargettedUnits( int targetId );
	int GetNumTargets();
	int GetPlacementPriority();
	int GetUnitCountInPlay(int unitType);
	void PopulatePlacementPoints();
	bool CheckCityCoverage( int objectType, float *longitude, float *latitude );
	int GetNearestObject( int teamId, float longitude, float latitude, int objectType = -1, bool enemyTeam = false );
	float GetDistanceToClosestObject( int cityId, int objectType );
	bool GetUncoveredArea( bool radar, float *longitude, float *latitude );
	bool IsSafeLocation(float longitude, float latitude);
	int GetTerritoryOwner( int territoryId );
	vector<float> GetPopulationCenter(int territoryId);
	void ChangeState( int newState );
	float Sfrand(int spread);
	bool ValidFleetPlacement( float longitude, float latitude, int memberCount );
	void ScoutingAI();
	void AssaultAI();
	void StrikeAI();
	void HandleAIEvents();
	bool SeenUnit(int unitId);
	bool IsAlive(int unitId);
	void AddUnit(int unitId, int type, int teamId, int currentState, float longitude, float latitude);
	WorldObject2* GetObject2(int unitId);
	void UpdateUnits();
	void UpdateFleets();
	int getRemainingPlaceableUnits(int typeId);
	World2* GetWorld2();
    void DebugOut(char * src, ...);
    string ComposeString(char * src, ...);
    void DeleteEvent( int id );
    Fleet2* GetFleet2( int fleetId );
public:
	enum
	{
		StatePlacement,     // initial unit placement
		StateScouting,      // no silo launches, airbases/carriers only launch fighters
		StateAssault,       // tactical strikes against enemy bases using subs/carriers
		StateStrike,         // Full strike against civs/remaining bases
		StatePanic,         // no silos left, all airbases/carriers switch to bomber launches only, try to cause as much damage as possible
		StateFinal         // Assault finished - now either reteating to own territory for defensive, or going fully offensive, depending on aggression value
	};


	enum
	{
		SubStateExploration,
		SubStateLaunchScouts,
		SubStateLaunchBombers,
		SubStateLaunchNukes,
		SubStateActivateSubs,
		NoSubState
	};
	enum
	{
		FleetTypeBattleships,
		FleetTypeScout,
		FleetTypeNuke,
		FleetTypeSubs,
		FleetTypeMixed,
		FleetTypeAntiSub,
		FleetTypeDefender,
		FleetTypeDefender2,
		FleetTypeRandom,
		NumFleetTypes
	};

	int m_targetTeam;                   // The team that is currently targeted
	int m_teamId;                       // Own Team Id
	int m_validTargetPopulation;        
	int m_subState;
	int m_currentState;
	int m_targetsVisible;
	int m_maxTargetsSeen;
	int m_aggression;
	World2 *m_world;
	vector<Fleet2 *> m_fleets;
	float m_siloSwitchTimer;
	float m_aiStateTimer;
	float m_aiAssaultTimer;
	float m_aiActionTimer;
	float m_aiActionSpeed;
	vector<float> m_aiPlacementPoints;
	vector<float> m_targetCoords;
	LList<Event *> m_eventLog;
	vector<int> m_couldntPlaceUnits;
    ConditionalCommandList m_conditionalCommands;
    vector<vector<float>> m_populationCenters;    // This holds the "center of mass" of all cities (not counting population) per territory
    bool m_firstUpdate;
};

class Event
{
public:
	enum
	{
		TypeEnemyIncursion,
		TypeSubDetected,
		TypeIncomingAircraft,
		TypeNukeLaunch
	};

	int m_type;
	int m_objectId;
	int m_actionTaken;  // incremented each time action is taken (ie. retaliatory nuke fired)
	int m_teamId;       // team of the object that caused the event
	int m_fleetId;

	float m_longitude;
	float m_latitude;

public:
	Event()
		:   m_type(-1),
		m_teamId(-1),
		m_fleetId(-1),
		m_objectId(-1),
		m_actionTaken(0),
		m_longitude(0),
		m_latitude(0)
	{
	}
};