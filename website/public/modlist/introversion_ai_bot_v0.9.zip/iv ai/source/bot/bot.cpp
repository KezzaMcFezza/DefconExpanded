#include "dll/stdafx.h"
#include "bot/bot.h"
#include "dll/enums.h"
#include <sstream>

Bot *g_bot = NULL;

Bot::Bot()
{
	// Initialise settings
	m_validTargetPopulation = 300000;
	m_targetTeam = -1;
	m_aiAssaultTimer = 1800.0f + rand() % 900 - 450;
	m_siloSwitchTimer = 10.0f;
	m_currentState = StatePlacement;
	m_subState = SubStateExploration;
	m_aiActionTimer = 0.0f;
	m_aiStateTimer = 0.0f;
	m_aiActionSpeed = 5;
	m_targetsVisible = 0;
	m_maxTargetsSeen = 0;
	m_aggression = 6 + rand() % 5;
	PopulatePlacementPoints();
	m_couldntPlaceUnits.resize(NumObjectTypes, 0);
	
	m_world = new World2();
	g_bot = this;
    m_firstUpdate = true;
    m_aiActionTimer = Sfrand( (int) m_aiActionSpeed );
    m_aiAssaultTimer = 5400 + ( 200 * (float) m_aggression * ( rand() % 5 + 1));

}


Bot::~Bot()
{
	delete m_world;
}

bool Bot::Initialise(Funct *f, vector<vector<string>> commandLineOptions)
{
	g_game = f;
    g_game->SendChatMessage("/name [Bot]Original4",0);
	return true;
}

bool Bot::Update()
{
    if ( m_firstUpdate )
    {
        m_firstUpdate = false;

    }

	if( g_game->GetGameSpeed() == 0 || g_game->DebugIsReplayingGame() )
	{
		return true;
	}

	m_teamId = g_game->GetOwnTeamId();
	if (m_teamId < 0)
	{		
		return false;
	}
	vector<int> teamIds = g_game->GetTeamIds();
    UpdateUnits();
    UpdateFleets();

    m_conditionalCommands.Update();
	//
	// Choose a target team

	if( m_targetTeam == -1 )
	{
		LList<int> validTargetTeams;
		for( unsigned int i = 0; i < teamIds.size(); ++i )
		{
			int teamId = teamIds[i];
			if( !IsFriend( m_teamId, teamId ) )
			{
				validTargetTeams.PutData(teamId);
			}
		}

		if( validTargetTeams.Size() )
		{
			int randomIndex = rand() % validTargetTeams.Size();
			m_targetTeam = validTargetTeams[randomIndex];
		}
	}

	if( IsValidTeamId(m_targetTeam) )
	{
		int populationThreshold = (int) g_game->GetOptionValue( "PopulationPerTerritory" ) * 
			g_game->GetOptionValue( "TerritoriesPerTeam" ) * 1000000 / 4;
		if( g_game->GetRemainingPopulation(m_targetTeam) < populationThreshold )
		{
			if( teamIds.size() > 2 )
			{
				int oldTeam = m_targetTeam;
				m_targetTeam = -1;
				int pop = 0;
				for( unsigned int i = 0; i < teamIds.size(); ++i )
				{
					if( !IsFriend( m_teamId, teamIds[i] ) )
					{
						int teamPop = g_game->GetRemainingPopulation(teamIds[i]);
						if( teamPop > pop )
						{
							pop = teamPop;
							m_targetTeam = teamIds[i];
						}
					}
				}
				if( m_targetTeam != oldTeam )
				{
					for( unsigned int i = 0; i < m_fleets.size(); ++i )
					{
						if( m_fleets[i] && !m_fleets[i]->IsInCombat() )
						{
                            m_fleets[i]->StopFleet();
						}
					}
				}
			}
			else
			{
				m_validTargetPopulation = (m_validTargetPopulation * 3) / 4;
			}
		}
	}
	if( g_game->IsVictoryTimerActive() )
	{
		m_validTargetPopulation = 0;
	}
	m_aiAssaultTimer -= SERVER_ADVANCE_PERIOD * g_game->GetGameSpeed();
/*
    This is an example of output to the console of Visual Studio (you need 
    to include windows.h for that):    
    char buf[512];
    sprintf(buf, "Timer: %f \n", m_aiAssaultTimer);
    OutputDebugStringA(buf);
*/
	if( m_currentState >= StateStrike )
	{
		m_siloSwitchTimer -= SERVER_ADVANCE_PERIOD * g_game->GetGameSpeed();
	}

	m_aiActionTimer -= SERVER_ADVANCE_PERIOD * g_game->GetGameSpeed();

	if( m_aiActionTimer <= 0 )
	{
		m_aiActionTimer = m_aiActionSpeed;

		m_targetsVisible = GetNumTargets();
		if( m_targetsVisible > m_maxTargetsSeen )
		{
			m_maxTargetsSeen = m_targetsVisible;
		}

		CheckPanicState();

		switch( m_currentState )
		{
		case StatePlacement:    PlacementAI();  break;
		case StateScouting:     ScoutingAI();   break;
		case StateAssault:      AssaultAI();    break;
		case StateStrike:       StrikeAI();     break;            
		}
		HandleAIEvents();

		//
		// Fleet AI
		for( unsigned int i = 0; i < m_fleets.size(); ++i )
		{
			m_fleets[i]->RunFleetAI();
		}


		//
		// Object AI 

		for( unsigned int i = 0; i < g_bot->GetWorld2()->m_units.size(); ++i )
		{

			WorldObject2 *obj = GetWorld2()->GetObject2(g_bot->GetWorld2()->m_units[i]);
			if( obj->m_teamId == m_teamId )
			{
				obj->RunAI();
			}
		}
	}
	

	return true;
}

void Bot::PlacementAI()
{
	int objectPriority = GetPlacementPriority();
	if( objectPriority != -1 )
	{
		bool createFleet = false;
		float minDistance = 0.0f;
		switch( objectPriority )
		{            
		case TypeRadarStation : minDistance = 20;   break;
		case TypeSilo         : minDistance = 10;   break;
		case TypeAirBase      : minDistance = 10;   break;

		default: 
			createFleet = true;   
			break;
		}

		float worldScale = (float) g_game->GetOptionValue("WorldScale") / 100.0f;
		minDistance /= worldScale;

		int x = 0;
		if( createFleet )
		{
			// set up a new fleet    
			int fleetType = -1;
			bool defensive = false;
			LList<int> fleetTypeList;

			if( CanAssembleFleet(FleetTypeScout)) fleetTypeList.PutData( FleetTypeScout );
			if( CanAssembleFleet(FleetTypeNuke)) fleetTypeList.PutData(  FleetTypeNuke );
			if( CanAssembleFleet(FleetTypeSubs)) fleetTypeList.PutData(  FleetTypeSubs );
			if( CanAssembleFleet(FleetTypeMixed)) fleetTypeList.PutData( FleetTypeMixed );

			if( getRemainingPlaceableUnits( TypeBattleShip ) +
				getRemainingPlaceableUnits( TypeSub ) +
				getRemainingPlaceableUnits( TypeCarrier ) <= 6 )
			{
				fleetType = FleetTypeMixed;
			}
			else
			{
				if( fleetTypeList.Size() > 0 )
				{
					int r = rand() % fleetTypeList.Size();
					fleetType = fleetTypeList[r];
				}
				else
				{
					fleetType = FleetTypeRandom;
				}
			}

			if(AssembleFleet( fleetType ))
			{
				unsigned int id = m_fleets.size() -1;
				switch( fleetType )
				{
				case FleetTypeScout :    
				case FleetTypeNuke :     
				case FleetTypeSubs :     m_fleets[id]->m_aiState = Fleet2::AIStateSneaking; break;

				default: m_fleets[id]->m_aiState = Fleet2::AIStateHunting; break;

				}
				LList<int> validPointsList;
				for( unsigned int i = 0; i < m_aiPlacementPoints.size(); i+=2 )
				{
					float longitude = m_aiPlacementPoints[i];
					float latitude = m_aiPlacementPoints[i+1];
					if( g_game->IsValidTerritory(m_teamId, longitude, latitude, true) )
					{
                        validPointsList.PutData(i);
					}
				}

				int attempt = 20;
				bool success = false;
				while( attempt > 0 && validPointsList.Size() )
				{
					int pointId = rand() % validPointsList.Size();
					float longitude = m_aiPlacementPoints[ validPointsList[pointId]] + Sfrand(10);
					float latitude = m_aiPlacementPoints[ validPointsList[pointId]+1] + Sfrand(10);
					if( ValidFleetPlacement(longitude,latitude,m_fleets[id]->m_memberTypes.size()) )
					{
						g_game->PlaceFleet(longitude,latitude,
							m_fleets[id]->m_memberTypes[0],
							m_fleets[id]->m_memberTypes.size() > 1? m_fleets[id]->m_memberTypes[1]:-1,
							m_fleets[id]->m_memberTypes.size() > 2? m_fleets[id]->m_memberTypes[2]:-1,
							m_fleets[id]->m_memberTypes.size() > 3? m_fleets[id]->m_memberTypes[3]:-1,
							m_fleets[id]->m_memberTypes.size() > 4? m_fleets[id]->m_memberTypes[4]:-1,
							m_fleets[id]->m_memberTypes.size() > 5? m_fleets[id]->m_memberTypes[5]:-1
							);
						success = true;
						break;
					}
					--attempt;
				}

				if( !success && validPointsList.Size() )
				{
					int pointId = rand() % validPointsList.Size();
					g_game->PlaceFleet(m_aiPlacementPoints[ validPointsList[pointId]],
						m_aiPlacementPoints[ validPointsList[pointId]+1],
						m_fleets[id]->m_memberTypes[0],
						m_fleets[id]->m_memberTypes.size() > 1? m_fleets[id]->m_memberTypes[1]:-1,
						m_fleets[id]->m_memberTypes.size() > 2? m_fleets[id]->m_memberTypes[2]:-1,
						m_fleets[id]->m_memberTypes.size() > 3? m_fleets[id]->m_memberTypes[3]:-1,
						m_fleets[id]->m_memberTypes.size() > 4? m_fleets[id]->m_memberTypes[4]:-1,
						m_fleets[id]->m_memberTypes.size() > 5? m_fleets[id]->m_memberTypes[5]:-1
						);
				}
			}
		}
		else
		{
			float longitude = 0;
			float latitude = 0;
			bool randomPlacement = false;

			if( objectPriority == TypeRadarStation ||
				objectPriority == TypeSilo )
			{
				if( CheckCityCoverage( objectPriority, &longitude, &latitude ) )
				{
					if( GetUncoveredArea( objectPriority == TypeRadarStation, &longitude, &latitude) )
					{
						g_game->PlaceStructure(objectPriority, longitude, latitude);
					}
					else
					{
						randomPlacement = true;
					}
				}
				else
				{
					int x = 0;
					while (x<1000)
					{
						x++;
						if( x >= 1000 )
						{
							randomPlacement = true;
						}
						float newLong = longitude + Sfrand(10);
						float newLat = latitude + Sfrand(10);
						if( g_game->IsValidPlacementLocation( newLong, newLat, objectPriority ) &&
							IsSafeLocation( newLong, newLat) )
						{
							g_game->PlaceStructure(objectPriority, newLong, newLat);
							
							break;
						}
					}
				}
			}
			else if( objectPriority == TypeAirBase )
			{
				int defensiveBases = 4 * g_game->GetOptionValue("TerritoriesPerTeam");
				defensiveBases = (int) (defensiveBases * (10.0f - m_aggression) / 10.0f);

				if( getRemainingPlaceableUnits(objectPriority) <= defensiveBases )
				{
					// place city-defensive airbases
					if( CheckCityCoverage( objectPriority, &longitude, &latitude ) )
					{
						randomPlacement = true;
					}
					else
					{
						int x = 0;
						while (x<1000)
						{
							x++;
							if( x >= 1000 )
							{
								randomPlacement = true;
							}
							float newLong = longitude + Sfrand(10);
							float newLat = latitude + Sfrand(10);
							if( g_game->IsValidPlacementLocation( newLong, newLat, objectPriority ) &&
								IsSafeLocation( newLong, newLat) )
							{
								g_game->PlaceStructure(objectPriority, newLong, newLat);
								break;
							}
						}
					}
				}
				else
				{
					// place coastal airbases
					int x = 0;
					bool success = false;
					while(true)
					{
						x++;
						if( x > 1000 )
						{
							randomPlacement = true;
							break;
						}
						longitude = Sfrand(360);
						latitude = Sfrand(180);

						int randTerritory = rand() % NumTerritories;
						int x = 0;
						while((GetTerritoryOwner(randTerritory) == m_teamId ||
							GetTerritoryOwner(randTerritory) == -1) &&
							x < 20 )
						{
							randTerritory = rand() % NumTerritories;
							x++;
						}

						if( g_game->IsValidPlacementLocation( longitude, latitude, objectPriority ) &&
							g_game->IsBorder( longitude, latitude ) &&
							g_game->IsValidTerritory( m_teamId, longitude, latitude, false ))
						{
							vector<float> populationCenter = GetPopulationCenter(randTerritory);
							if( g_game->GetDistance( longitude, latitude, 
								populationCenter[0], populationCenter[1]) < 90 )
							{
								int index = GetNearestObject( m_teamId, longitude, latitude, objectPriority );
								if( index != -1 )
								{
									if( g_game->GetDistance( longitude, latitude, 
										g_game->GetLongitude(index), 
										g_game->GetLatitude(index) ) > minDistance )
									{
										success = true;
										break;
									}
								}
								else
								{
									success = true;
									break;
								}
							}
						}
					}
					// place unit 
					if( success )
					{
						g_game->PlaceStructure(objectPriority,longitude,latitude );
					}
				}
			}

			if( randomPlacement )
			{
				int x = 0;
				while( x < 5000 )
				{
					x++;
					if( x >= 5000 )
					{
						// give up
						m_couldntPlaceUnits[objectPriority]++;
					}
					longitude = Sfrand(360);
					latitude = Sfrand(180);
					int index = GetNearestObject( m_teamId, longitude, latitude, objectPriority );
		
					if( g_game->IsValidPlacementLocation( longitude, latitude, objectPriority ) )
					{
						if (index == -1 || 
							g_game->GetDistance( longitude, latitude, 
							g_game->GetLongitude(index), g_game->GetLatitude(index)) > minDistance )
						{
							g_game->PlaceStructure(objectPriority,longitude,latitude );
							DebugOut("Placed Structure randomly: %d %f %f\n",objectPriority,longitude,latitude);
							break;
						}
					}
				}
			}

		}
	}
	else
	{
		m_currentState = StateScouting;
	}
}

void Bot::ScoutingAI()
{
	if( g_game->GetDefcon() == 1 )
	{
		int territoriesPerTeam = g_game->GetOptionValue( "TerritoriesPerTeam" );

		if( m_targetsVisible >= 5 * territoriesPerTeam ||
			m_aiAssaultTimer <= 0 ||
			g_game->IsVictoryTimerActive() )
		{
			m_currentState = StateAssault;
		}    
	}
}


void Bot::AssaultAI()
{
	if( g_game->GetDefcon() == 1 )
	{
		int territoriesPerTeam = g_game->GetOptionValue( "TerritoriesPerTeam" );
		int targetsDestroyed = m_maxTargetsSeen - m_targetsVisible;

		if( targetsDestroyed >= 5 * territoriesPerTeam ||
			m_aiAssaultTimer <= 0 ||
			g_game->IsVictoryTimerActive() )
		{
			m_currentState = StateStrike;
		}    
	}
}

///////////////////////
// Strike AI
// Full strike against cities. Enemy defensives should be low at this point
///////////////////////
void Bot::StrikeAI()
{
	if( m_subState < SubStateLaunchBombers )
	{
		m_subState = SubStateLaunchBombers;
	}

	m_aiStateTimer -= SERVER_ADVANCE_PERIOD * g_game->GetGameSpeed();
	if( m_aiStateTimer <= 0 )
	{
		switch( m_subState )
		{
		case SubStateLaunchBombers: m_subState = SubStateLaunchNukes;   break;
		case SubStateLaunchNukes  : m_subState = SubStateActivateSubs;  break;
		case SubStateActivateSubs : m_currentState = StateFinal;        break;
		}
		int territoryId = -1;
		int myTerritory = -1;
		for( int i = 0; i < NumTerritories; ++i )
		{
			if( GetTerritoryOwner(i) == m_targetTeam )
			{
				territoryId = i;
			}
			if( GetTerritoryOwner(i) == m_teamId )
			{
				myTerritory = i;
			}
		}
		if( territoryId != -1 && myTerritory != -1 )
		{
			vector<float> myCenter = GetPopulationCenter(myTerritory);
			vector<float> otherCenter = GetPopulationCenter(territoryId);
			float distance = g_game->GetDistance( myCenter[0], myCenter[1], otherCenter[0], otherCenter[1]);
			m_aiStateTimer = (distance / 0.15f) / 2.0f; // time it takes for nukes to get from friendly to enemy territory                                    
		}
	}
}



void Bot::HandleAIEvents()
{
	for( int i = 0; i < m_eventLog.Size(); ++i )
	{
		Event *event = m_eventLog[i];
		bool eventHandled = false;

		switch( event->m_type )
		{
		case Event::TypeSubDetected:
			{
				WorldObject2 *obj = GetWorld2()->GetObject2(event->m_objectId);
				if( !obj )
				{
					eventHandled = true;
				}
				else 
				{
					int bestFleetIndex = -1;
					float distance = 1000001;

					for( unsigned int j = 0; j < m_fleets.size(); ++j )
					{
						if( !m_fleets[j]->IsInCombat() &&
							m_fleets[j]->IsInFleet( TypeCarrier ) &&
							m_fleets[j]->m_aiState == Fleet2::AIStateHunting &&
							!m_fleets[j]->IsOnSameSideOfSeam() )
						{
							float fleetlon = 0.0f;
							float fleetlat = 0.0f;
							m_fleets[j]->GetFleetPosition(fleetlon, fleetlat);
							float newdist = g_game->GetDistance( fleetlon, 
								fleetlat, 
								event->m_longitude, 
								event->m_latitude );

							if( newdist < distance )
							{
								distance = newdist;
								bestFleetIndex = j;
							}
						}
					}

					if( bestFleetIndex != -1 )
					{
						m_fleets[bestFleetIndex]->m_aiState = Fleet2::AIStateIntercepting;
						m_fleets[bestFleetIndex]->m_targetObjectId = event->m_objectId;
						m_fleets[bestFleetIndex]->MoveFleet( obj->m_lastSeenLongitude, 
							obj->m_lastSeenLatitude );
						eventHandled = true;
					}
				}
				break;
			}
		case Event::TypeEnemyIncursion:
			{
				WorldObject2 *obj = GetWorld2()->GetObject2( event->m_objectId );
				if( !obj )
				{
					eventHandled = true;
				}

				if( obj )
				{
					int bestFleetIndex = -1;
					float dist= 1000001;

					for( unsigned int j = 0; j < m_fleets.size(); ++j )
					{
						if( !m_fleets[j]->IsInCombat() &&
								m_fleets[j]->m_aiState == Fleet2::AIStateHunting &&
								m_fleets[j]->IsOnSameSideOfSeam() )
						{							
							float fleetlon = 0.0f;
							float fleetlat = 0.0f;
							m_fleets[j]->GetFleetPosition(fleetlon, fleetlat);

							float thisDist = g_game->GetDistance(
								fleetlon, fleetlat, 
								event->m_longitude, event->m_latitude );

							if( thisDist < dist )
							{
								dist = thisDist;
								bestFleetIndex = j;
							}
						}
					}

					if( bestFleetIndex != -1 )
					{
						m_fleets[bestFleetIndex]->MoveFleet( obj->m_lastSeenLongitude, 
							obj->m_lastSeenLatitude );
						event->m_actionTaken++;
						if( event->m_actionTaken >= 2 )
						{
							eventHandled = true;
						}
					}
				}
				break;
			}

		case Event::TypeNukeLaunch:
			// Nobody bothers with this event, so delete it straight away
			eventHandled = true;
			break;

		case Event::TypeIncomingAircraft:
			break;
		}

		if( eventHandled )
		{    
			m_eventLog.RemoveData(i);
			delete event;
			--i;
		}
	}
}
int  Bot::GetPlacementPriority()
{
	float gameScale = 1.0f;//World::GetGameScale();

	int territoriesPerTeam = g_game->GetOptionValue("TerritoriesPerTeam");

	int numRadar = (int)(7 * gameScale * territoriesPerTeam);
	if( getRemainingPlaceableUnits(TypeRadarStation) > 0 &&
		GetUnitCountInPlay(TypeRadarStation) < numRadar )
	{
		return TypeRadarStation;
	}

	int numSilos = (int)(6 * gameScale);
	if( g_game->GetOptionValue("VariableUnitCounts") == 1 )
	{
		numSilos = (int) (numSilos / float(5.0f / m_aggression));
	}
	numSilos *= territoriesPerTeam;

	DebugOut("PlacementPriority: remradar: %d inplayradar: %d, sub: %d %d\n",
		getRemainingPlaceableUnits(TypeRadarStation),GetUnitCountInPlay(TypeRadarStation),
		getRemainingPlaceableUnits(TypeSub),GetUnitCountInPlay(TypeSub));

	if( getRemainingPlaceableUnits(TypeSilo) > 0 &&
		GetUnitCountInPlay(TypeSilo) < numSilos )
		return TypeSilo;

	int numAirbases = (int) (4 * territoriesPerTeam * gameScale);
	if( getRemainingPlaceableUnits(TypeAirBase) > 0 &&
		GetUnitCountInPlay(TypeAirBase) < numAirbases )
		return TypeAirBase;

	if( getRemainingPlaceableUnits(TypeSub) > 0 )
		return TypeSub;

	if( getRemainingPlaceableUnits(TypeCarrier) > 0 )
		return TypeCarrier;

	if( getRemainingPlaceableUnits(TypeBattleShip) > 0 )
		return TypeBattleShip;

	int unitCredits = g_game->GetUnitCredits();
	if(  unitCredits > 0 &&
		g_game->GetOptionValue("VariableUnitCounts") == 1)
	{
		if( unitCredits >= g_game->GetUnitValue( TypeSilo ) )
			return TypeSilo;

		if( unitCredits >= g_game->GetUnitValue( TypeAirBase ) )
			return TypeAirBase;

		if( unitCredits >= g_game->GetUnitValue( TypeRadarStation) )
			return TypeRadarStation;
	}

	return -1;
}

bool Bot::CanAssembleFleet()
{
	for (int i = 0; i < NumFleetTypes; i++)
	{
		if (CanAssembleFleet(i))
			return true;
	}
	return false;
}

bool Bot::CanAssembleFleet( int fleetType )
{
	int ships, subs, carriers;
	GetFleetMembers( fleetType, &ships, &subs, &carriers );
	int creditCost = g_game->GetUnitValue( TypeBattleShip ) * ships;
	creditCost += g_game->GetUnitValue( TypeSub ) * subs;
	creditCost += g_game->GetUnitValue( TypeCarrier ) * carriers;

	int variableTeamUnits = g_game->GetOptionValue("VariableUnitCounts");
	bool enoughCredits = g_game->GetUnitCredits() >= creditCost;
	if( !variableTeamUnits ) enoughCredits = true;

	if( getRemainingPlaceableUnits( TypeBattleShip ) >= ships &&
		getRemainingPlaceableUnits( TypeSub ) >= subs &&
		getRemainingPlaceableUnits( TypeCarrier ) >= carriers &&
		enoughCredits )
	{
		return true;
	}
	else 
	{
		return false;
	}
}


bool Bot::AssembleFleet( int fleetType )
{
	int ships = 0;
	int subs = 0;
	int carriers =0;
	GetFleetMembers( fleetType, &ships, &subs, &carriers );

	if( ( getRemainingPlaceableUnits( TypeBattleShip ) >= ships &&
		getRemainingPlaceableUnits( TypeSub ) >= subs &&
		getRemainingPlaceableUnits( TypeCarrier ) >= carriers ) ||
		( fleetType == FleetTypeMixed &&
		getRemainingPlaceableUnits( TypeBattleShip ) +
		getRemainingPlaceableUnits( TypeSub ) +
		getRemainingPlaceableUnits( TypeCarrier ) <= 6 ) ||
		fleetType == FleetTypeRandom )
	{
		//CreateFleet();
        Fleet2 *f = new Fleet2(m_fleets.size());
		m_fleets.push_back(f);

		if( (getRemainingPlaceableUnits( TypeBattleShip ) +
			getRemainingPlaceableUnits( TypeSub ) +
			getRemainingPlaceableUnits( TypeCarrier ) <= 6 &&
			fleetType == FleetTypeMixed ) ||
			!CanAssembleFleet())
		{
			fleetType = FleetTypeMixed;
			ships = getRemainingPlaceableUnits( TypeBattleShip );
			subs = getRemainingPlaceableUnits( TypeSub );
			carriers = getRemainingPlaceableUnits( TypeCarrier );
		}
		else if( fleetType == FleetTypeRandom )
		{
			ships = 0;
			subs = 0;
			carriers = 0;

			int credits = g_game->GetUnitCredits();
			if( g_game->GetOptionValue("VariableUnitCounts") == 0 ) credits = 9999999;

			bool outOfResources = false;
			while( ships + subs + carriers < 6 &&
				!outOfResources)
			{                
				int r = rand() % 3;
				switch(r)
				{
				case 0 : 
					{
						if( getRemainingPlaceableUnits( TypeBattleShip ) - ships > 0 &&
							credits - g_game->GetUnitValue(TypeBattleShip) >= 0) 
						{
							ships++; 
							credits -= g_game->GetUnitValue(TypeBattleShip );
							break;
						}
					}
				case 1 : 
					{
						if( getRemainingPlaceableUnits( TypeSub ) - subs > 0  &&
							credits - g_game->GetUnitValue(TypeSub) >= 0) 
						{
							subs++;
							credits -= g_game->GetUnitValue(TypeSub);
							break;
						}
					}
				case 2 :
					{
						if( getRemainingPlaceableUnits( TypeCarrier ) - carriers > 0  &&
							credits - g_game->GetUnitValue(TypeCarrier) >= 0) 
						{
							carriers++;
							credits -= g_game->GetUnitValue(TypeCarrier );
							break;
						}
					}
				default: 
					outOfResources = true;
				}
			}

		}

		for( int i = 0; i < ships; ++i )
		{
			if( getRemainingPlaceableUnits( TypeBattleShip ) > 0 )
			{
				m_fleets.back()->m_memberTypes.push_back(TypeBattleShip);
			}
		}

		for( int i = 0; i < subs; ++i )
		{
			if( getRemainingPlaceableUnits( TypeSub ) > 0 )
			{
				m_fleets.back()->m_memberTypes.push_back(TypeSub);
			}
		}

		for( int i = 0; i < carriers; ++i )
		{
			if( getRemainingPlaceableUnits( TypeCarrier ) > 0 )
			{
				m_fleets.back()->m_memberTypes.push_back(TypeCarrier);
			}
		}
		return true;
	}
	else
	{
		return false;
	}
}
void Bot::GetFleetMembers( int fleetType, int *ships, int *subs, int *carriers )
{
	int ship = TypeBattleShip;
	int sub = TypeSub;
	int carrier = TypeCarrier;

	int fleetMembers[ NumFleetTypes ] [ 3 ] =     

	{   
		//ships     //subs      // carriers
		6,          0,          0,          // FleetTypeBattleShips
		3,          0,          3,          // FleetTypeScout
		0,          3,          3,          // FleetTypeNuke
		0,          6,          0,          // FleetTypeSub
		2,          2,          2,          // FleetTypeMixed
		2,          0,          4,          // FleetTypeAntiSub
		5,          0,          1,          // FleetTypeDefender
		0,          2,          4,          // FleetTypeDefender2
	};

	*ships      = fleetMembers[fleetType][0];
	*subs       = fleetMembers[fleetType][1];
	*carriers   = fleetMembers[fleetType][2];
}

void Bot::AddEvent(int _eventType, int _causeObjectId, int _targetObjectId, 
				   int _unitType, float _longitude, float _latitude)
{

	//DebugOut("DLL received event: id: %d cause: %d target: %d type: %d coord: %3.2f %3.2f\n",
	//	_eventType, _causeObjectId, _targetObjectId, _unitType, _longitude, _latitude);

}

void Bot::CheckPanicState()
{
	if( m_currentState < StateStrike )
	{
		if( g_game->GetDefcon() == 1 )
		{
			int friendlyDeaths = g_game->GetFriendlyDeaths(m_teamId);
			int territoriesPerTeam = g_game->GetOptionValue("TerritoriesPerTeam");
			float totalFriendly = 100000000.0f * territoriesPerTeam;
			float fractionAlive = 1.0f - friendlyDeaths / totalFriendly;
			fractionAlive = min( fractionAlive, 1.0f );
			fractionAlive = max( fractionAlive, 0.0f );

			if(  GetUnitCountInPlay(TypeSilo) < 3 ||
				fractionAlive < 0.3f )
			{
				if( m_currentState != StatePanic )
				{
					// panic!
					m_currentState = StatePanic;
				}
			}
		}
	}
}



bool Bot::IsFriend(int teamId1, int teamId2)
{
	int alliance1 = g_game->GetAllianceId(teamId1);
	if (alliance1 == -1)
		return false; // not a valid teamId
	int alliance2 = g_game->GetAllianceId(teamId2);
	if (alliance1 == alliance2)
		return true;
	return false;
}

bool Bot::IsValidTeamId(int teamId)
{
	vector<int> t = g_game->GetTeamIds();
	for (unsigned int i = 0; i < t.size(); i++)
	{
		if (t[i] == teamId)
			return true;
	}
	return false;
}

// Counts how many own units have given targetId as target
int Bot::CountTargettedUnits( int targetId )
{
    int num = 0;
    for( unsigned int i = 0; i < g_bot->GetWorld2()->m_units.size(); ++i )
    {
        WorldObject2 *obj = GetWorld2()->GetObject2(g_bot->GetWorld2()->m_units[i]);
        
        if( obj && obj->m_teamId == m_teamId )
        {
            if( g_game->GetCurrentTargetId( obj->m_objectId ) == targetId )
            {
                num++;
            }
            vector<int> queue = g_game->GetActionQueue( obj->m_objectId );
            for( unsigned int j = 0; j < queue.size(); ++j )
            {
                if( g_game->GetCurrentTargetId( queue[j] ) == targetId )
                {
                    num++;
                }
            }
        }
    }
    return num;
}


int Bot::GetNumTargets()
{
	int num = 0;
	for( unsigned int i = 0; i < g_bot->GetWorld2()->m_units.size(); ++i )
	{
		WorldObject2 *obj = GetWorld2()->GetObject2(g_bot->GetWorld2()->m_units[i]);
		if( obj && !IsFriend(obj->m_teamId, m_teamId ) &&
				( obj->m_type == TypeSilo ||
				obj->m_type == TypeRadarStation ||
				obj->m_type == TypeAirBase ) )           
			{
				num++;
			}
		
	}

	return num;
}

int Bot::GetUnitCountInPlay(int unitType)
{
	// could be optimised by keeping track of units internally
	int c = 0;
	for (unsigned int i = 0; i < g_bot->GetWorld2()->m_units.size(); i++)
	{
		WorldObject2 *obj = GetWorld2()->GetObject2(g_bot->GetWorld2()->m_units[i]);
		if (obj && obj->m_type == unitType && obj->m_teamId == m_teamId)
			c++;
	}
	return c;
}


void Bot::PopulatePlacementPoints()
{
	// This data was originally stored in bitmaps and then read out when the game starts.
	// However, the bitmap loading procedures are integrated deep into the game engine, so this has
	// been left away.
	m_aiPlacementPoints.push_back(-177.890625f);m_aiPlacementPoints.push_back(34.736842f);
	m_aiPlacementPoints.push_back(-177.187500f);m_aiPlacementPoints.push_back(46.666667f);
	m_aiPlacementPoints.push_back(-156.093750f);m_aiPlacementPoints.push_back(45.964912f);
	m_aiPlacementPoints.push_back(-151.875000f);m_aiPlacementPoints.push_back(35.438596f);
	m_aiPlacementPoints.push_back(-146.953125f);m_aiPlacementPoints.push_back(22.807018f);
	m_targetCoords.push_back(-142.031250f);m_targetCoords.push_back(45.964912f);
	m_targetCoords.push_back(-136.406250f);m_targetCoords.push_back(28.421053f);
	m_aiPlacementPoints.push_back(-133.593750f);m_aiPlacementPoints.push_back(20.701754f);
	m_aiPlacementPoints.push_back(-123.046875f);m_aiPlacementPoints.push_back(26.315789f);
	m_targetCoords.push_back(-118.828125f);m_targetCoords.push_back(9.473684f);
	m_aiPlacementPoints.push_back(-113.203125f);m_aiPlacementPoints.push_back(-9.473684f);
	m_aiPlacementPoints.push_back(-106.171875f);m_aiPlacementPoints.push_back(6.666667f);
	m_aiPlacementPoints.push_back(-93.515625f);m_aiPlacementPoints.push_back(-6.666667f);
	m_targetCoords.push_back(-93.515625f);m_targetCoords.push_back(-0.350877f);
	m_aiPlacementPoints.push_back(-91.406250f);m_aiPlacementPoints.push_back(-18.596491f);
	m_targetCoords.push_back(-88.593750f);m_targetCoords.push_back(-27.719298f);
	m_targetCoords.push_back(-64.687500f);m_targetCoords.push_back(29.122807f);
	m_aiPlacementPoints.push_back(-56.250000f);m_aiPlacementPoints.push_back(22.807018f);
	m_aiPlacementPoints.push_back(-55.546875f);m_aiPlacementPoints.push_back(35.438596f);
	m_targetCoords.push_back(-50.625000f);m_targetCoords.push_back(16.491228f);
	m_targetCoords.push_back(-47.812500f);m_targetCoords.push_back(36.842105f);
	m_aiPlacementPoints.push_back(-44.296875f);m_aiPlacementPoints.push_back(31.228070f);
	m_targetCoords.push_back(-43.593750f);m_targetCoords.push_back(48.771930f);
	m_aiPlacementPoints.push_back(-42.890625f);m_aiPlacementPoints.push_back(41.754386f);
	m_aiPlacementPoints.push_back(-40.078125f);m_aiPlacementPoints.push_back(4.561404f);
	m_aiPlacementPoints.push_back(-37.968750f);m_aiPlacementPoints.push_back(22.105263f);
	m_aiPlacementPoints.push_back(-37.265625f);m_aiPlacementPoints.push_back(-30.526316f);
	m_targetCoords.push_back(-31.640625f);m_targetCoords.push_back(-17.894737f);
	m_aiPlacementPoints.push_back(-31.640625f);m_aiPlacementPoints.push_back(35.438596f);
	m_targetCoords.push_back(-30.234375f);m_targetCoords.push_back(-35.438596f);
	m_aiPlacementPoints.push_back(-29.531250f);m_aiPlacementPoints.push_back(45.263158f);
	m_aiPlacementPoints.push_back(-28.828125f);m_aiPlacementPoints.push_back(9.473684f);
	m_aiPlacementPoints.push_back(-28.125000f);m_aiPlacementPoints.push_back(24.912281f);
	m_aiPlacementPoints.push_back(-26.718750f);m_aiPlacementPoints.push_back(0.350877f);
	m_aiPlacementPoints.push_back(-25.312500f);m_aiPlacementPoints.push_back(-17.894737f);
	m_targetCoords.push_back(-23.203125f);m_targetCoords.push_back(13.684211f);
	m_targetCoords.push_back(-22.500000f);m_targetCoords.push_back(31.228070f);
	m_aiPlacementPoints.push_back(-21.796875f);m_aiPlacementPoints.push_back(38.947368f);
	m_aiPlacementPoints.push_back(-21.796875f);m_aiPlacementPoints.push_back(52.280702f);
	m_targetCoords.push_back(-21.093750f);m_targetCoords.push_back(45.263158f);
	m_aiPlacementPoints.push_back(-14.765625f);m_aiPlacementPoints.push_back(35.438596f);
	m_aiPlacementPoints.push_back(-14.062500f);m_aiPlacementPoints.push_back(47.368421f);
	m_aiPlacementPoints.push_back(-11.953125f);m_aiPlacementPoints.push_back(-5.964912f);
	m_aiPlacementPoints.push_back(-10.546875f);m_aiPlacementPoints.push_back(60.000000f);
	m_targetCoords.push_back(-9.140625f);m_targetCoords.push_back(68.421053f);
	m_targetCoords.push_back(0.000000f);m_targetCoords.push_back(69.122807f);
	m_targetCoords.push_back(1.406250f);m_targetCoords.push_back(-4.561404f);
	m_aiPlacementPoints.push_back(2.812500f);m_aiPlacementPoints.push_back(73.333333f);
	m_aiPlacementPoints.push_back(3.515625f);m_aiPlacementPoints.push_back(-19.298246f);
	m_aiPlacementPoints.push_back(4.218750f);m_aiPlacementPoints.push_back(67.017544f);
	m_targetCoords.push_back(6.328125f);m_targetCoords.push_back(-31.929825f);
	m_aiPlacementPoints.push_back(12.656250f);m_aiPlacementPoints.push_back(71.929825f);
	m_aiPlacementPoints.push_back(28.828125f);m_aiPlacementPoints.push_back(76.140351f);
	m_targetCoords.push_back(35.859375f);m_targetCoords.push_back(75.438596f);
	m_aiPlacementPoints.push_back(38.671875f);m_aiPlacementPoints.push_back(74.736842f);
	m_aiPlacementPoints.push_back(48.515625f);m_aiPlacementPoints.push_back(75.438596f);
	m_targetCoords.push_back(49.218750f);m_targetCoords.push_back(-5.263158f);
	m_aiPlacementPoints.push_back(56.953125f);m_aiPlacementPoints.push_back(-10.175439f);
	m_aiPlacementPoints.push_back(58.359375f);m_aiPlacementPoints.push_back(1.754386f);
	m_targetCoords.push_back(64.687500f);m_targetCoords.push_back(8.771930f);
	m_targetCoords.push_back(70.312500f);m_targetCoords.push_back(-6.666667f);
	m_aiPlacementPoints.push_back(71.015625f);m_aiPlacementPoints.push_back(3.859649f);
	m_aiPlacementPoints.push_back(82.968750f);m_aiPlacementPoints.push_back(-3.859649f);
	m_targetCoords.push_back(90.000000f);m_targetCoords.push_back(-2.456140f);
	m_aiPlacementPoints.push_back(94.921875f);m_aiPlacementPoints.push_back(-12.280702f);
	m_targetCoords.push_back(132.890625f);m_targetCoords.push_back(21.403509f);
	m_targetCoords.push_back(134.296875f);m_targetCoords.push_back(10.175439f);
	m_aiPlacementPoints.push_back(144.843750f);m_aiPlacementPoints.push_back(27.017544f);
	m_aiPlacementPoints.push_back(149.062500f);m_aiPlacementPoints.push_back(15.087719f);
	m_targetCoords.push_back(150.468750f);m_targetCoords.push_back(31.228070f);
	m_aiPlacementPoints.push_back(154.687500f);m_aiPlacementPoints.push_back(34.035088f);
	m_aiPlacementPoints.push_back(157.500000f);m_aiPlacementPoints.push_back(21.403509f);
	m_targetCoords.push_back(158.906250f);m_targetCoords.push_back(41.052632f);
	m_aiPlacementPoints.push_back(163.828125f);m_aiPlacementPoints.push_back(46.666667f);
	m_aiPlacementPoints.push_back(165.234375f);m_aiPlacementPoints.push_back(8.771930f);
	m_aiPlacementPoints.push_back(167.343750f);m_aiPlacementPoints.push_back(32.631579f);
	m_aiPlacementPoints.push_back(172.265625f);m_aiPlacementPoints.push_back(20.701754f);
	m_aiPlacementPoints.push_back(172.968750f);m_aiPlacementPoints.push_back(45.964912f);
}

bool Bot::ValidFleetPlacement( float longitude, float latitude, int memberCount )
{	
	for( int i = 0; i < memberCount; ++i )
	{
		vector<float> offset = g_game->GetFleetMemberOffset(memberCount, i);

		// the placement validity is equal for battleships, carriers and subs.
		if( !g_game->IsValidPlacementLocation( longitude + offset[0], latitude + offset[1], TypeBattleShip ) )
		{
			return false;
		}
	}
	return true;
}


bool Bot::CheckCityCoverage( int objectType, float *longitude, float *latitude )
{
	float checkDistance = 20.0f; // radar and silo both have range of 30.0f, make sure cities are reasonably covered
	if( objectType == TypeAirBase ) 
	{
		checkDistance = 40.0f;
	}
	else if( objectType == TypeSilo )
	{
		checkDistance = 7.5f;
	}
	vector<int> cities = g_game->GetCityIds();
	for( unsigned int i = 0; i < cities.size(); ++i )
	{
		if( g_game->GetTeamId(cities[i]) == m_teamId )
		{
			float dist = GetDistanceToClosestObject( cities[i], objectType );
			if( dist > checkDistance ||
				dist == -1 )
			{
				*longitude = g_game->GetLongitude(cities[i]);
				*latitude = g_game->GetLatitude(cities[i]);
				return false;
			}
		}

	}
	return true;
}

float Bot::GetDistanceToClosestObject( int cityId, int objectType )
{
	float dist = 100001;
	int index = GetNearestObject( m_teamId, g_game->GetLongitude(cityId), g_game->GetLatitude(cityId), objectType );
	if (index == -1)
		return -1;

	dist = g_game->GetDistance( g_game->GetLongitude(cityId), g_game->GetLatitude(cityId), 
		g_game->GetLongitude(index), g_game->GetLatitude(index) );
	if (dist > 10000)
		DebugOut("DIST FAILURE: Bigger than 10000\n");
	return dist;
}

int Bot::GetNearestObject( int teamId, float longitude, float latitude, int objectType, bool enemyTeam )
{
	int result = -1;
	float nearest = 10000001;

	for( unsigned int i = 0; i < g_bot->GetWorld2()->m_units.size(); ++i )
	{

		int unitTeamId = g_game->GetTeamId(g_bot->GetWorld2()->m_units[i]);
		bool isFriend = IsFriend(unitTeamId , teamId );

		if( ( (isFriend && !enemyTeam) || (!isFriend && enemyTeam )) &&
			( objectType == -1 || g_game->GetType(g_bot->GetWorld2()->m_units[i]) == objectType) &&
			!g_game->IsCeaseFire(teamId, unitTeamId))
		{
			float dist = g_game->GetDistance( longitude, latitude, 
				g_game->GetLongitude(g_bot->GetWorld2()->m_units[i]), g_game->GetLatitude(g_bot->GetWorld2()->m_units[i]));
			if( dist < nearest )
			{
				result = g_bot->GetWorld2()->m_units[i];
				nearest = dist;
			}
		}
	}

	return result;
}

bool Bot::GetUncoveredArea( bool radar, float *longitude, float *latitude )
{
	int x = 0;

	int type = -1;
	float distance = 30;
	if( radar )
	{
		type = TypeRadarStation;
	}
	else
	{
		type = TypeSilo;
		distance = 7.5f;
	}

	while( x < 1000 )
	{
		x++;
		float randLong = Sfrand(360);
		float randLat = Sfrand(180);
		int index = GetNearestObject( m_teamId, randLong, randLat, type );
		
		if( index != -1 )
		{
			if( g_game->IsValidTerritory( m_teamId, randLong, randLat, false ) &&
				g_game->GetDistance( randLong, randLat, 
				g_game->GetLongitude(index), 
				g_game->GetLatitude(index)) > distance )
			{
				*longitude = randLong;
				*latitude = randLat;
				return true;
			}
		}
	}
	return false;
}

// Sfrand: returns symmetric float random number from -spread/2 to spread/2
float Bot::Sfrand(int spread )
{
	return (rand()%spread) - spread/2.0f + (rand()%10000) * 0.0001f;
}

bool Bot::IsSafeLocation(float longitude, float latitude)
{
	vector<int> cities = g_game->GetCityIds();
	for( unsigned int i = 0; i < cities.size(); ++i )
	{

		if( g_game->GetTeamId(cities[i]) == m_teamId )
		{
			if( g_game->GetDistance( longitude, latitude, 
				g_game->GetLongitude(cities[i]), g_game->GetLatitude(cities[i]) ) < 2.5f )
			{
				return false;
			}
		}

	}
	return true;
}

int Bot::GetTerritoryOwner( int territoryId )
{
	vector<int> teams = g_game->GetTeamIds();
	for( unsigned int i = 0; i < teams.size(); ++i )
	{
		vector<int> terrs = g_game->GetTeamTerritories(teams[i]);
		for (unsigned int j = 0; j < terrs.size(); j++)
		{
			if (terrs[j] == territoryId)
				return teams[i];
		}
	}
	return -1;
}


vector<float> Bot::GetPopulationCenter(int territoryId)
{
    // if not calculated before, fill m_populationCenters with centers of mass fo
    if ( m_populationCenters.size() == 0 )
    {
        for ( int terrId = 0; terrId < NumTerritories; terrId++ )
        {
            vector<int> cities = g_game->GetCityIds();
            float totlon = 0;
            float totlat = 0;
            int countedCities = 0;
            for( unsigned int i = 0; i < cities.size(); ++i )
            {
                float cityLongitude = g_game->GetLongitude(cities[i]);
                float cityLatitude = g_game->GetLatitude(cities[i]);

                if( g_game->GetTerritoryId(cityLongitude, cityLatitude) == terrId)
                {
                    totlon += g_game->GetLongitude(cities[i]);
                    totlat += g_game->GetLatitude(cities[i]);
                    countedCities++;
                }
            }
            m_populationCenters.push_back(vector<float> (2,0.0f));
            if ( countedCities > 0 )
            {
                m_populationCenters[terrId][0] = totlon / countedCities;
                m_populationCenters[terrId][1] = totlat / countedCities;
            }

        }
    }
	return m_populationCenters[territoryId];

}

void Bot::UpdateFleets()
{
	vector<int> fleetIds = g_game->GetFleets(m_teamId);
    for (unsigned int i = 0; i < fleetIds.size(); i++ )
    {
        bool fleetFound = false;
        for ( unsigned int j = 0; j < m_fleets.size(); j++ )
        {
            Fleet2 *fleet = m_fleets[j];
            if ( fleet->m_fleetId == fleetIds[i] )
            {
                fleetFound = true;
                if (!fleet->Update())
                {
                    // fleet is empty
                    delete fleet;
                    fleet = NULL;
                    m_fleets.erase(m_fleets.begin() + j);
                }
                break;
            }
        }
        if (!fleetFound)
        {
            // fleet does not exist, create it
            Fleet2 *f = new Fleet2(fleetIds[i]);
            m_fleets.push_back(f);
            f->Update();
            g_game->DebugLog(ComposeString("Created new fleet, id: %d", f->m_fleetId), fleetIds[i], "", 0, 255, 0);
        }

    }
}

void Bot::UpdateUnits()
{
    g_bot->GetWorld2()->m_units.clear();
	vector<Funct::UnitData *> updateData = g_game->GetAllUnitData();
	hash_map <int, WorldObject2 *> :: iterator it;
	for (unsigned int i = 0; i < updateData.size(); i++)
	{
		Funct::UnitData *datum = updateData[i];
        if (datum->m_visible) // do not cheat.
        {
            it = g_bot->GetWorld2()->m_unitHash.find(datum->m_objectId);
            if (it == g_bot->GetWorld2()->m_unitHash.end() || it->second == NULL)
            {
                // item not found
                g_bot->GetWorld2()->AddUnit(datum->m_objectId,
                    datum->m_type,
                    datum->m_teamId,
                    datum->m_currentState,
                    datum->m_longitude,
                    datum->m_latitude);
                g_game->DebugLog("Adding unit");
            }
            else
            {
                // item in the hash, update
                WorldObject2 *obj = it->second;
                obj->UpdatePosition(datum->m_longitude, datum->m_latitude);
                obj->m_currentState = datum->m_currentState;
            }
            g_bot->GetWorld2()->m_units.push_back(datum->m_objectId);
        }
		delete datum;
		updateData[i] = NULL;
	}

    int currentTick = g_game->GetGameTick();
    hash_map<int, WorldObject2 *>::const_iterator iter;
    for ( iter = GetWorld2()->m_unitHash.begin(); iter != GetWorld2()->m_unitHash.end(); ++iter )
    {
        WorldObject2 *w = iter->second;
        if (w && w->m_teamId == m_teamId && w->m_lastSeenServerTick != currentTick)
        {
            // Object hasnt been updated: it is dead
            g_game->DebugLog("Deleting unit!", w->m_objectId, "");
            delete w;
            GetWorld2()->m_unitHash[iter->first] = NULL;
        }
    }
}

string Bot::ComposeString(char * src, ...)
{
    char buf[1024];
    va_list ap;
    va_start (ap, src);
    vsprintf_s(buf, src, ap);

    return string(buf);
}

void Bot::DebugOut(char * src, ...)
{
    char buf[2048];
    va_list ap;
    va_start (ap, src);
    vsprintf_s(buf, src, ap);
    g_game->DebugLog(string(buf));
}

void Bot::DeleteEvent( int id )
{
    Event *event = m_eventLog[id];
    m_eventLog.RemoveData(id);
    delete event;
}

int Bot::getRemainingPlaceableUnits(int typeId)
{
	return g_game->GetRemainingUnits(typeId) - m_couldntPlaceUnits[typeId];
}

World2* Bot::GetWorld2()
{
	return m_world;
}

Fleet2* Bot::GetFleet2( int fleetId )
{
    for ( unsigned int i = 0; i < m_fleets.size(); i++ )
    {
        if (m_fleets[i]->m_fleetId == fleetId)
            return m_fleets[i];
    }
    return NULL;
}
