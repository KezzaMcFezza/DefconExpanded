#pragma once

#include "bot/objects/object.h"
#include <hash_map>

using namespace stdext;


class World2
{
public:
	bool SeenUnit(int unitId);
	bool IsAlive(int unitId);
	void AddUnit(int unitId, int type, int teamId, int currentState, float longitude, float latitude);
	WorldObject2* GetObject2(int unitId);
    int GetAttackOdds( int attackerType, int defenderType );
public:
	vector<int> m_units; // Contains all units, updated every Update() step.
	hash_map<int, bool> m_seen;
	hash_map<int, WorldObject2 *> m_unitHash;
};