#include "dll/stdafx.h"
#include "bot/objects/world.h"
#include "dll/enums.h"


bool World2::SeenUnit(int unitId)
{
	// unit has been seen if it appears in the unit hash
	hash_map <int, WorldObject2 *> :: iterator it;
	it = m_unitHash.find(unitId);
	return (it != m_unitHash.end());
}

bool World2::IsAlive(int unitId)
{
	hash_map <int, WorldObject2 *> :: iterator it = m_unitHash.find(unitId);
	return (it != m_unitHash.end() && it->second != NULL);		
}

void World2::AddUnit(int unitId, int type, int teamId, int currentState,
					 float longitude, float latitude)
{
	WorldObject2 *wobj = new WorldObject2(unitId);
	wobj->m_type = type;
	wobj->m_teamId = teamId;
	wobj->m_currentState = currentState;
	wobj->UpdatePosition(longitude, latitude);

    hash_map <int, WorldObject2 *> :: iterator it;
    it = m_unitHash.find(unitId);
    if (it != m_unitHash.end())
        it->second = wobj;
    else
        m_unitHash[unitId] = wobj;
}

WorldObject2* World2::GetObject2(int unitId)
{
	hash_map <int, WorldObject2 *> :: iterator it;
	it = m_unitHash.find(unitId);
	if (it != m_unitHash.end())
		return it->second;

	return NULL;
}

int World2::GetAttackOdds( int attackerType, int defenderType )
{

    if ( !(attackerType >= 0 && attackerType < NumObjectTypes &&
        defenderType >= 0 && defenderType < NumObjectTypes) )
        return 0;

    static int id = 10;               // odds of identical units against each other

    static int s_attackOdds[ NumObjectTypes ] [ NumObjectTypes ] = 

        /* ATTACKER */

        /* INV CTY SIL RDR NUK EXP SUB SHP AIR FTR BMR CRR TOR SAU*/

    {   
        0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  // Invalid
        0,  0,  0,  0, 99,  0,  0,  0,  0,  0,  0,  0,  0,  0,  // City
        0,  0,  0,  0, 99,  0,  0,  0,  0,  0,  0,  0,  0, 50,  // Silo
        0,  0,  0,  0, 99,  0,  0,  0,  0,  0,  0,  0,  0, 50,  // Radar
        0,  0, 25,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  // Nuke            DEFENDER
        0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  // Explosion
        0,  0,  0,  0, 99,  0, id, 30,  0,  3, 25, 30,  0, 50,  // Sub
        0,  0,  0,  0, 99,  0, 20, id,  0, 10, 25,  0,  0, 50,  // BattleShip
        0,  0,  0,  0, 99,  0,  0,  0,  0,  0,  0,  0,  0, 50,  // Airbase
        0,  0, 10,  0,  0,  0,  0, 30,  0, id,  0,  0,  0, 50,  // Fighter
        0,  0, 10,  0,  0,  0,  0, 20,  0, 30,  0,  0,  0, 50,  // Bomber
        0,  0,  0,  0, 99,  0, 20, 20,  0, 10, 25,  0,  0, 50,  // Carrier
        0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  // Tornado
        0,  0, 10,  0,  0,  0,  0, 10,  0, 10,  0,  0,  0,  0,  // Saucer
    };


    return s_attackOdds[ defenderType ][ attackerType ];
}
