#include "dll/stdafx.h"
#include "bot/objects/fleet.h"
#include "dll/enums.h"

Fleet2::Fleet2(int fleetId)
{
	m_currentState = 0;
    m_fleetId = fleetId;
	m_targetObjectId = -1;
}

// returns false if fleet is empty
bool Fleet2::Update()
{
    if ( m_fleetMembers.size() == 0 )
    {
        m_fleetMembers = g_game->GetFleetMembers( m_fleetId );
        if ( m_fleetMembers.size() == 0 )
            return false;
    }
    else
    {
        for( unsigned int i = 0; i < m_fleetMembers.size(); ++i )
        {
            WorldObject2 *obj = g_bot->GetWorld2()->GetObject2( m_fleetMembers[i] );
            if( !obj )
            {
                m_fleetMembers.erase(m_fleetMembers.begin() + i);
                --i;
            }
        }
    }
    return true;
}

bool Fleet2::IsInCombat()
{
    for( unsigned int i = 0; i < m_fleetMembers.size(); ++i )
    {
        if (g_game->IsRetaliating(m_fleetMembers[i]) || g_game->GetCurrentTargetId(m_fleetMembers[i]) != -1)
            return true;
    }
    return false;
}

void Fleet2::StopFleet()
{
    float currLongitude = 0;
    float currLatitude = 0;
    GetFleetPosition(currLongitude, currLatitude);
    MoveFleet( currLongitude, currLatitude );
}

bool Fleet2::IsInFleet(int objectType)
{
	for (unsigned int i = 0; i < m_memberTypes.size(); i++)
	{
		if (m_memberTypes[i] == objectType)
			return true;
	}
	return false;
}

bool Fleet2::IsOnSameSideOfSeam()
{
	float previousLong = 0;
	for( unsigned int i = 0; i < m_fleetMembers.size(); ++i )
	{
		int oid = m_fleetMembers[i];
		if( previousLong != 0 )
		{
			if( previousLong < -160 &&
				g_game->GetLongitude(oid) > 160 )
			{
				return false;
			}
			else if( previousLong > 160 &&
				g_game->GetLongitude(oid) < -160 )
			{
				return false;
			}
		}
		previousLong = g_game->GetLongitude(oid);
	}
	return true;
}

void Fleet2::GetFleetPosition( float &longitude, float &latitude )
{
	float totalLong = 0;
	float totalLat = 0;
	float previousTotal = 0;
	bool onSeam = IsOnSameSideOfSeam();
	int numMembers = 0;
	for( unsigned int i = 0; i < m_fleetMembers.size(); ++i )
	{
		if( g_game->GetType(m_fleetMembers[i] != TypeInvalid) )
		{
			numMembers++;
			totalLong += g_game->GetLongitude(m_fleetMembers[i]);
			totalLat += g_game->GetLatitude(m_fleetMembers[i]);

			if( !onSeam )
			{
				if( previousTotal != 0 )
				{
					if( previousTotal < 0 &&
						previousTotal < totalLong )
					{
						totalLong -= 360;
					}
					else if( previousTotal > 0 &&
						previousTotal > totalLong )
					{
						totalLong += 360;
					}
				}

				previousTotal = totalLong;
			}
		}
	}
	if( numMembers > 0 )
	{
		longitude = totalLong / numMembers;
		latitude = totalLat / numMembers;
	}
}

void Fleet2::MoveFleet(float longitude, float latitude)
{
	// move a member of the fleet
	for (unsigned int i = 0; i < m_fleetMembers.size(); i++)
	{
		if (g_game->GetType(m_fleetMembers[i]) != TypeInvalid)
		{
			g_game->SetMovementTarget(m_fleetMembers[i], longitude,latitude);
			return;
		}
	}
}

void Fleet2::GetFleetTarget( float &longitude, float &latitude )
{
    float totalLong = 0;
    float totalLat = 0;
    float previousTotal = 0;
    bool onSeam = IsOnSameSideOfSeam();
    int numMembers = 0;
    for( unsigned int i = 0; i < m_fleetMembers.size(); ++i )
    {
        if( g_game->GetType(m_fleetMembers[i]) != TypeInvalid )
        {
            numMembers++;
            vector<float> target = g_game->GetMovementTargetLocation( m_fleetMembers[i] );
            totalLong += target[0];
            totalLat += target[1];

            if( !onSeam )
            {
                if( previousTotal != 0 )
                {
                    if( previousTotal < 0 &&
                        previousTotal < totalLong )
                    {
                        totalLong -= 360;
                    }
                    else if( previousTotal > 0 &&
                        previousTotal > totalLong )
                    {
                        totalLong += 360;
                    }
                }

                previousTotal = totalLong;
            }
        }
    }
    if( numMembers > 0 )
    {
        longitude = totalLong / numMembers;
        latitude = totalLat / numMembers;
    }
}

bool Fleet2::IsInNukeRange()
{
    int targetTeam = g_bot->m_targetTeam;
    float longitude = 0;
    float latitude = 0;
    GetFleetPosition( longitude, latitude );

    if( g_game->IsVictoryTimerActive() )
    {        
        float maxrange = 40;
        float bestDist = 40;

        for( int i = 0; i < NumTerritories; ++i )
        {
            int owner = g_bot->GetTerritoryOwner(i);
            if( owner != -1 &&
                !g_bot->IsFriend( owner, g_bot->m_teamId ) )
            {
                vector<float> center = g_bot->GetPopulationCenter(i);
                float popCenterLong = center[0];
                float popCenterLat = center[1];
                float dist = g_game->GetDistance( longitude, latitude, popCenterLong, popCenterLat );

                if( dist < bestDist )
                {                
                    bestDist = dist;
                    targetTeam = g_bot->GetTerritoryOwner(i);
                }
            }
        }
        float longitude = 0;
        float latitude = 0;

        int objectId = -1;
        WorldObject2::FindTarget( g_bot->m_teamId, targetTeam, m_fleetMembers[0], maxrange, &longitude, &latitude, &objectId );

        if( longitude != 0 && latitude != 0 )
        {
            return true;
        }
        return false;
    }

    for( int i = 0; i < NumTerritories; ++i )
    {
        float maxrange = 40;

        int owner = g_bot->GetTerritoryOwner(i);
        if( owner != -1 &&
            !g_bot->IsFriend( owner, g_bot->m_teamId ) )
        {
            vector<float> center = g_bot->GetPopulationCenter(i);
            float popCenterLong = center[0];
            float popCenterLat = center[1];

            if( g_game->GetDistance( longitude, latitude, popCenterLong, popCenterLat ) < maxrange )
            {
                return true;
            }
        }
    }
    return false;
}

int Fleet2::CountNukesInFleet()
{
    int nukesInFleet = 0;
    for( unsigned int i = 0; i < m_fleetMembers.size(); ++i )
    {
        WorldObject2 *obj = g_bot->GetWorld2()->GetObject2( m_fleetMembers[i] );
        if( obj )
        {
            if( obj->m_type == TypeSub )
            {
                nukesInFleet += g_game->GetStateCount( obj->m_objectId, STATE_SUBNUKE );
            }
            else if(obj->m_type == TypeCarrier )
            {
                // Approximation: Might not have enough nukes for every bomber
                nukesInFleet += g_game->GetStateCount( obj->m_objectId, STATE_CARRIERBOMBERLAUNCH );
            }
        }
    }
    return nukesInFleet;
}

bool Fleet2::IsFleetIdle()
{
    for( unsigned int i = 0; i < m_fleetMembers.size(); ++i )
    {
        WorldObject2 *obj = g_bot->GetWorld2()->GetObject2( m_fleetMembers[i] );
        if( obj &&
            obj->IsMovingObject() )
        {
            if( !obj->IsIdle() )
            {
                return false;
            }
        }
    }
    return true;
}

void Fleet2::RunFleetAI()
{
    if( m_fleetMembers.size() == 0 )
    {
        return;
    }

    int nukesInFleet = CountNukesInFleet();
    if( g_bot->m_currentState == Bot::StatePanic )
    {
        if( nukesInFleet > 0 )
        {
            m_aiState = AIStateSneaking;
        }
        else
        {
            if( m_aiState != AIStateIntercepting )
            {
                m_aiState = AIStateHunting;
            }
        }
    }
    if( m_aiState != AIStateIntercepting )
    {
        if( nukesInFleet > 0 )
        {
            m_aiState = AIStateSneaking;
        }
        else
        {
            m_aiState = AIStateHunting;
        }
    }

    switch( m_aiState )
    {
    case AIStateHunting     :   RunAIHunting();     break;
    case AIStateSneaking    :   RunAISneaking();    break;
    case AIStateIntercepting:   RunAIIntercepting();break;
    }

    for( unsigned int i = 0; i < m_fleetMembers.size(); ++i )
    {
        WorldObject2 *obj = g_bot->GetWorld2()->GetObject2( m_fleetMembers[i] );
        if( !obj )
        {
            m_fleetMembers.erase(m_fleetMembers.begin() + i);
            --i;
        }
    }
}

void Fleet2::RunAIHunting()
{
    if( g_game->GetDefcon() <= 4 )
    {
        float targetLongitude = 0;
        float targetLatitude = 0;
        GetFleetTarget(targetLongitude, targetLatitude);
        if( targetLongitude == 0 && targetLatitude == 0 )
        {
            float attackLongitude, attackLatitude;

            bool success = FindGoodAttackSpot( attackLongitude, attackLatitude );
            if( success )
            {
                MoveFleet( attackLongitude, attackLatitude );
            }
        }
    }
}

void Fleet2::RunAISneaking()
{
    if( g_game->GetDefcon() <= 4 )
    {
        if( CountNukesInFleet() == 0 )
        {
            m_aiState = AIStateHunting;
            return;
        }
        
        float targetLongitude = 0;
        float targetLatitude = 0;
        GetFleetTarget(targetLongitude, targetLatitude);

        if( IsFleetIdle() && !IsInNukeRange() )
        {
            if( targetLongitude != 0 && targetLatitude != 0 )
            {
                MoveFleet( targetLongitude, targetLatitude );
            }
        }

        if( targetLongitude == 0 && targetLatitude == 0 )
        {
            if( !IsInNukeRange() )
            {   
                float attackLongitude, attackLatitude;
                bool success = FindGoodAttackSpot( attackLongitude, attackLatitude );
                if( success )
                {
                    MoveFleet( attackLongitude, attackLatitude );
                }
            }
        }
    }
}


struct ValidTargetPoint
{
    float m_longitude;
    float m_latitude;
    float m_sailRange;
};

bool Fleet2::IsIgnoringPoint( int pointId )
{
    for( int i = 0; i < m_pointIgnoreList.Size(); ++i )
    {
        if( m_pointIgnoreList[i] == pointId )
        {
            return true;
        }
    }
    return false;
}

bool Fleet2::FindGoodAttackSpot( float &_longitude, float &_latitude )
{
    LList<ValidTargetPoint> validTargetPoints;

    float attackRange = 60;
    int nukesInFleet = CountNukesInFleet();
    if( IsInFleet(TypeSub) &&
        nukesInFleet > 0 )
    {
        attackRange = 45;
    }

    for( unsigned int i = 0; i < g_bot->m_targetCoords.size(); i+=2 )
    {
        if( !IsIgnoringPoint(i) )
        {
            float pointX = g_bot->m_targetCoords[i];
            float pointY = g_bot->m_targetCoords[i+1];
            float myLatitude = 0;
            float myLongitude = 0;
            GetFleetPosition(myLongitude, myLatitude);

            bool inRange = false;            
            for( int j = 0; j < NumTerritories; ++j )
            {
                int owner = g_bot->GetTerritoryOwner(j);
                if( owner != -1 &&
                    !g_bot->IsFriend( owner, g_bot->m_teamId ) )
                {
                    vector<float> center = g_bot->GetPopulationCenter(j);
                    float popCenterLong = center[0];
                    float popCenterLat = center[1];

                    if( g_game->GetDistance( pointX, pointY, popCenterLong, popCenterLat ) < attackRange )
                    {
                        inRange = true;
                        break;
                    }
                }
            }
            if( inRange )
            {
                float sailRange = g_game->GetSailDistance( myLongitude, myLatitude, pointX, pointY );

                ValidTargetPoint newPoint;
                newPoint.m_longitude = pointX;
                newPoint.m_latitude = pointY;
                newPoint.m_sailRange = sailRange;

                if( sailRange < 5 )
                {
                    m_pointIgnoreList.PutData(i);
                }
                else
                {
                    // Ordered insert
                    bool added = false;
                    for( int j = 0; j < validTargetPoints.Size(); ++j )
                    {
                        ValidTargetPoint point = *validTargetPoints.GetPointer(j);
                        if( sailRange < point.m_sailRange )
                        {
                            validTargetPoints.PutDataAtIndex( newPoint, j );
                            added = true;
                            break;
                        }
                    }
                    if( !added )
                    {
                        validTargetPoints.PutDataAtEnd(newPoint);
                    }
                }
            }
        }
    }


    while(validTargetPoints.Size())
    {
        int numValid = int( validTargetPoints.Size() * 0.2f );
        numValid = max( numValid, 1 );
        int index = rand() % numValid;
        ValidTargetPoint point = *validTargetPoints.GetPointer(index);

        validTargetPoints.RemoveData(index);

        float longitude = point.m_longitude + g_bot->Sfrand( 10 );
        float latitude = point.m_latitude + g_bot->Sfrand( 10 );

        if( IsValidFleetPosition(longitude, latitude) )
        {
            _longitude = longitude;
            _latitude = latitude;
            return true;
        }
    }
    return false;
}

bool Fleet2::IsValidFleetPosition( float longitude, float latitude )
{
    if( longitude > 180 ||
        longitude < -180 )
    {
        return true;
    }

    for( unsigned int i = 0; i < m_fleetMembers.size(); ++i )
    {
        float thisLong = longitude;
        float thisLat = latitude;
        vector<float> offset = g_game->GetFleetMemberOffset(m_fleetMembers.size(), i);

        if( !g_game->IsValidTerritory(-1, thisLong + offset[0], thisLat + offset[1], true) )
        {
            return false;
        }
    }

    return true;
}

void Fleet2::RunAIIntercepting()
{    
    WorldObject2 *obj = g_bot->GetWorld2()->GetObject2( m_targetObjectId );
    if( obj )
    {
        float targetLongitude = 0;
        float targetLatitude = 0;
        GetFleetTarget(targetLongitude, targetLatitude);
        if( targetLongitude == 0 && targetLatitude == 0 )
        {
            if( IsValidFleetPosition( obj->m_lastSeenLongitude, obj->m_lastSeenLatitude ) )
            {
                MoveFleet( obj->m_lastSeenLongitude, obj->m_lastSeenLatitude );
                if( CountNukesInFleet() > 0 )
                {
                    m_aiState = AIStateSneaking;
                }
                else
                {
                    m_aiState = AIStateHunting;
                }
                return;
            }
        }
        float myLatitude = 0;
        float myLongitude = 0;
        GetFleetPosition(myLongitude, myLatitude);

        if( g_game->GetDistance(  myLongitude, myLatitude, targetLongitude, targetLatitude ) < 10 )
        {
            if( obj->m_lastSeenServerTick == g_game->GetGameTick() )
            {
                if( g_game->GetDistance(  myLongitude, myLatitude, obj->m_longitude, obj->m_latitude ) > 10 )
                {
                    MoveFleet( obj->m_longitude, obj->m_latitude );
                }
            }
            else
            {
                for( unsigned int i = 0; i < m_fleetMembers.size(); ++i )
                {
                    WorldObject2 *obj = g_bot->GetWorld2()->GetObject2( m_fleetMembers[i] );
                    if( obj )
                    {
                        if( obj->m_type == TypeCarrier  )
                        {
                            g_game->SetState( obj->m_objectId, STATE_CARRIERANTISUB );
                        }
                    }

                }
            }
        }
    }
    else
    {
        if( CountNukesInFleet() > 0 )
        {
            m_aiState = AIStateSneaking;
        }
        else
        {
            m_aiState = AIStateHunting;
        }
    }
}