#pragma once

#include <vector>
using namespace std;

class WorldObject2
{
public:
	WorldObject2(int objectId);
	void RunAI();
	void UpdatePosition(float newLongitude, float newLatitude);
	void RunAirBaseAI();
    bool IsMovingObject();
    bool IsIdle();
    int  GetClosestLandingPad();
    void RunBattleShipAI();
    void RunBomberAI();
    void RunCarrierAI();
    static void FindTarget( int team, int targetTeam, int launchedBy, float range, float *longitude, float *latitude, int *objectId );
    void LaunchScout();
    static int CountTargetedNukes( int teamId, float longitude, float latitude );
    void RunFighterAI();
    void RunSiloAI();
    void RunSubAI();
    bool IsInStateZero();
public:
	int m_objectId;
	int m_teamId;
	int m_type;
	int m_currentState;
	float m_longitude;
	float m_latitude;
	float m_lastSeenLongitude;
	float m_lastSeenLatitude;
    int m_lastSeenServerTick;
	float m_aiTimer;
	float m_aiSpeed;
	bool m_alive;

    bool m_nukeTargetedThisTick;
    float m_nukeTargetLongitude;
    float m_nukeTargetLatitude;

private:
	float m_lastSeenTime;
};
