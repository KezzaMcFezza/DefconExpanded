#pragma once

#include <vector>
#include "tools/llist.h"
using namespace std;

class Fleet2
{
public:
	Fleet2(int fleetId);
    bool Update();
    bool IsInFleet(int objectType);
	bool IsOnSameSideOfSeam();
    void GetFleetPosition( float &longitude, float &latitude );
	void MoveFleet(float longitude, float latitude);
	void RunFleetAI();
    bool IsInNukeRange();
    int CountNukesInFleet();
    void RunAIHunting();
    void GetFleetTarget( float &longitude, float &latitude );
    bool IsValidFleetPosition( float longitude, float latitude );
    bool IsFleetIdle();
    void RunAISneaking();
    void RunAIIntercepting();
    bool FindGoodAttackSpot( float &_longitude, float &_latitude );
    bool IsIgnoringPoint( int pointId );
    bool IsInCombat();
    void StopFleet();
public:
	enum
	{
		AIStateHunting,         // generic aggressive state. moves toward enemy territory to engage hostile ships
		AIStateScouting,        // launching fighters over enemy territory to reveal buildings
		AIStateDefending,       // moving around friendly territory looking for hostile ships
		AIStateSneaking,        // trying to covertly move into enemy territory, preferably close to coastline
		AIStateNuking,          // launching nukes/bombers at enemy territory.
		AIStateRetreating,      // retreating back to friendly territory. use after nuke strikes, or by sub hunters tracking subs
		AIStateIntercepting,    // intercepting a specified unit/fleet
	};

	int m_fleetId;
	int m_aiState;
	int m_targetObjectId;
    int         m_currentState; // combat state (aggressive/defensive/passive)
    vector<int> m_memberTypes;
	vector<int> m_fleetMembers;
    LList<int> m_pointIgnoreList;
};
