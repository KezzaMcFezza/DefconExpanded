#include "dll/stdafx.h"
#include "bot/objects/object.h"
#include "dll/enums.h"
#include <math.h> // for pow

// comparison function for conditional commands
// see also tools/conditional_commands.cpp
bool checkState( int _objId, int _state )
{
    return g_game->GetCurrentState( _objId ) == _state;
}

// floating point equality with error margin
inline bool CloseTo(float a, float b, float eps = 0.01f)
{
    return abs(a-b) <= eps;
}

WorldObject2::WorldObject2( int objectId )
{
	m_objectId = objectId;
	m_type = -1;
	m_teamId = -1;
	m_alive = true;
    m_nukeTargetedThisTick = false;
    m_nukeTargetLongitude = 0;
    m_nukeTargetLatitude = 0;

}

// UpdatePosition: if a new position of an object becomes known, UpdatePosition
// will keep track of this by updating the "last seen" variables
void WorldObject2::UpdatePosition( float newLongitude, float newLatitude )
{
	m_longitude = newLongitude;
	m_latitude = newLatitude;
	m_lastSeenLongitude = m_longitude;
	m_lastSeenLatitude = m_latitude;
    m_lastSeenTime = g_game->GetGameTime();
    m_lastSeenServerTick = g_game->GetGameTick();
    m_nukeTargetedThisTick = false;
}

bool WorldObject2::IsMovingObject()
{
    return ( m_type == TypeFighter ||
        m_type == TypeBomber ||
        m_type == TypeBattleShip ||
        m_type == TypeSub ||
        m_type == TypeCarrier ||
        m_type == TypeNuke );
}

int WorldObject2::GetClosestLandingPad()
{
    int nearestId = -1;
    int nearestWithNukesId = -1;

    float nearest = 10000000;
    float nearestWithNukes = 10000000;

    //
    // Look for any carrier or airbase with room
    // Favour objects with nukes if we are a bomber

    for( unsigned int i = 0; i < g_bot->GetWorld2()->m_units.size(); ++i )
    {
        WorldObject2 *obj = g_bot->GetWorld2()->GetObject2(g_bot->GetWorld2()->m_units[i]);
        if( obj && obj->m_teamId == m_teamId )
        {
            if( obj->m_type == TypeCarrier ||
                obj->m_type == TypeAirBase )
            {
                int roomInside = 0;
                int maxFighters = 10;
                int maxBombers = 10;
                if ( obj->m_type == TypeCarrier )
                {
                    maxFighters = 5;
                    maxBombers = 2;
                }
                if( m_type == TypeFighter ) roomInside = maxFighters - g_game->GetStateCount( obj->m_objectId, STATE_AIRBASEFIGHTERLAUNCH );  // StateAirbaseFighterlaunch = StateCarrierFighterlaunch
                if( m_type == TypeBomber ) roomInside = maxBombers - g_game->GetStateCount( obj->m_objectId, STATE_AIRBASEBOMBERLAUNCH);  // StateAirbaseFighterlaunch = StateCarrierFighterlaunch

                if( roomInside > 0 )
                {
                    float dist = g_game->GetDistance( m_longitude, m_latitude, obj->m_longitude, obj->m_latitude );
                    if( dist < nearest )
                    {
                        nearest = dist;
                        nearestId = obj->m_objectId;
                    }

                    if( m_type == TypeBomber && 
                        g_game->GetNukeSupply( obj->m_objectId ) > 0 &&
                        dist < nearestWithNukes )
                    {
                        nearestWithNukes = dist;
                        nearestId = obj->m_objectId;
                    }
                }
            }

        }
    }

    //
    // Fighter - go for nearest landing pad

    if( m_type == TypeFighter && 
        nearestId != -1 )
    {
        return nearestId;
    }

    //
    // Bomber - go for nearest with nukes if in range

    if( m_type == TypeBomber && 
        nearestWithNukesId != -1 &&
        nearestWithNukes < g_game->GetRange(m_objectId) )
    {
        return nearestWithNukesId;
    }

    //
    // Bomber - no nukes within range, so go for nearest

    if( m_type == TypeBomber &&
        nearestId != -1 )
    {
        return nearestId;
    }
    return -1;
}


bool WorldObject2::IsIdle()
{
    vector<float> target = g_game->GetMovementTargetLocation( m_objectId );
    if( target[0] == 0 &&
        target[1] == 0 &&
        g_game->GetCurrentTargetId(m_objectId) == -1 )
        return true;
    else return false;
}

void WorldObject2::RunAI()
{
	if ( m_type == TypeAirBase )
        RunAirBaseAI();
    else if ( m_type == TypeBattleShip )
        RunBattleShipAI();
    else if ( m_type == TypeBomber )
        RunBomberAI();
    else if ( m_type == TypeCarrier )
        RunCarrierAI();
    else if ( m_type == TypeFighter )
        RunFighterAI();
    else if ( m_type == TypeSilo )
        RunSiloAI();
    else if ( m_type == TypeSub )
        RunSubAI();
}

void WorldObject2::RunAirBaseAI()
{
	if( m_aiTimer <= 0 )
	{
		m_aiTimer = m_aiSpeed;

		vector<int> actionQueue = g_game->GetActionQueue(m_objectId);
		if(g_game->GetStateCount(m_objectId, m_currentState) - actionQueue.size() <= 0)
		{
			return;
		}

		if( g_game->GetDefcon() < 3 )
		{
			float aggressionDistance = 20;
			aggressionDistance += 5 * g_bot->m_aggression;
			if( aggressionDistance > 45 )
			{
				aggressionDistance = 45;
			}
			if( g_game->GetDefcon() > 1 &&
				g_game->GetStateCount(m_objectId, STATE_AIRBASEFIGHTERLAUNCH) > 2 &&
				g_bot->m_currentState == Bot::StateScouting)
			{
				if( m_currentState != STATE_AIRBASEFIGHTERLAUNCH )
				{
					g_game->SetState(m_objectId, STATE_AIRBASEFIGHTERLAUNCH);
				}
				for( int i = 0; i < NumTerritories; ++i )
				{
					int owner = g_bot->GetTerritoryOwner(i);
					if( owner != -1 && !g_bot->IsFriend(m_teamId, owner) )
					{
						vector<float> center = g_bot->GetPopulationCenter(i);
						float dist = g_game->GetDistance( m_longitude, m_latitude, 
							center[0], center[1] );
						if( dist < 50 )
						{
							float longitude = g_bot->Sfrand(40);
							float latitude  = g_bot->Sfrand(40);

                            g_bot->m_conditionalCommands.ConditionalActionTarget(m_objectId, -1, center[0] + longitude, center[1] + latitude, &checkState, m_objectId, STATE_AIRBASEFIGHTERLAUNCH);
						}
					}
				}
			}
			else
			{
                // check event log for planes or subs, if found send planes
				bool eventFound = false;

				for( int i = 0; i < g_bot->m_eventLog.Size(); ++i )
				{
					Event *event = g_bot->m_eventLog[i];
					if( event &&
						(event->m_type == Event::TypeIncomingAircraft ||
						event->m_type == Event::TypeEnemyIncursion ||
						event->m_type == Event::TypeSubDetected ) )
					{
						WorldObject2 *obj = g_bot->GetWorld2()->GetObject2( event->m_objectId );
						if( obj &&
							!g_bot->IsFriend( m_teamId, obj->m_teamId ) &&                            
							g_bot->CountTargettedUnits( obj->m_objectId ) < 3 &&
							g_game->GetDistance( m_longitude, m_latitude, obj->m_longitude, obj->m_latitude ) <= aggressionDistance )
						{
							if( obj->m_type == TypeFighter ||
								obj->m_type == TypeBomber )
							{
								if( g_game->GetStateCount(m_objectId, STATE_AIRBASEFIGHTERLAUNCH) > 0 )
								{
									if( m_currentState != STATE_AIRBASEFIGHTERLAUNCH )
									{
										g_game->SetState( m_objectId, STATE_AIRBASEFIGHTERLAUNCH );
									}
								}
								else
								{
									continue;
								}
							}
							else if( obj->m_type == TypeSub )
							{
								if( g_game->GetStateCount(m_objectId, STATE_AIRBASEBOMBERLAUNCH) > 0 )
								{
                                    g_game->SetState( m_objectId, STATE_AIRBASEBOMBERLAUNCH );
                                }
							}
							else
							{
								continue;
							}
							eventFound = true;

                            g_bot->m_conditionalCommands.ConditionalActionTarget(m_objectId, obj->m_objectId, obj->m_longitude, obj->m_latitude, &checkState, m_objectId, STATE_AIRBASEBOMBERLAUNCH);
                            return;
							event->m_actionTaken++;
							if( event->m_actionTaken >= 2 )
							{
								g_bot->DeleteEvent(i);
							}
							break;
						}                        
					}                    
				}

				LList<int> targetList;
				if( !eventFound )
				{
                    for( unsigned int i = 0; i < g_bot->GetWorld2()->m_units.size(); ++i )
					{
                        WorldObject2 *obj = g_bot->GetWorld2()->GetObject2(g_bot->GetWorld2()->m_units[i]);
                        if( !g_bot->IsFriend( m_teamId, obj->m_teamId ) &&
                            obj->IsMovingObject() &&
                            g_game->GetDistance( m_longitude, m_latitude, obj->m_longitude, obj->m_latitude ) <= aggressionDistance )
                        {
                            targetList.PutData( obj->m_objectId );
                        }

                    }
				}

				if( targetList.Size() > 0 )
				{

					int id = rand() % targetList.Size();

					WorldObject2 *obj = g_bot->GetWorld2()->GetObject2( targetList[id] );
					if( obj )
					{                        
                        g_game->SetActionTarget( m_objectId, obj->m_objectId, obj->m_longitude, obj->m_latitude );
					}
				}
				else
				{
					if( g_game->GetDefcon() == 1 )
					{
                        if( g_bot->m_subState >= Bot::SubStateLaunchBombers ||
                            g_bot->m_currentState == Bot::StatePanic )
						{
							if( m_currentState != STATE_AIRBASEBOMBERLAUNCH )
							{
                                g_game->SetState( m_objectId, STATE_AIRBASEBOMBERLAUNCH );
							}
							if( m_currentState == STATE_AIRBASEBOMBERLAUNCH )
							{
								// launch bombers!
								float longitude = 0;
								float latitude = 0;
								int objectId = -1;

								FindTarget( m_teamId, g_bot->m_targetTeam, m_objectId, 180, &longitude, &latitude, &objectId );
								if( longitude != 0 && latitude != 0)
								{
                                    g_bot->m_conditionalCommands.ConditionalActionTarget( m_objectId, objectId, longitude, latitude, &checkState, m_objectId, STATE_AIRBASEBOMBERLAUNCH );
                                    m_nukeTargetedThisTick = true;
                                    m_nukeTargetLongitude = longitude;
                                    m_nukeTargetLatitude = latitude;
                                }
							}
						}
					}
				}
			}
		}
	}
}

void WorldObject2::RunBattleShipAI()
{
    // Nothing.
}

void WorldObject2::RunBomberAI()
{
    if( IsIdle() )
    {
        for( unsigned int i = 0; i < g_bot->GetWorld2()->m_units.size(); ++i )
        {
            WorldObject2 *obj = g_bot->GetWorld2()->GetObject2(g_bot->GetWorld2()->m_units[i]);
            if( obj )
            {
                if( g_bot->GetWorld2()->GetAttackOdds( m_type, obj->m_type ) > 0 &&
                    !g_bot->IsFriend( m_teamId, obj->m_teamId ) &&        
                    g_game->GetDistance( m_longitude, m_latitude, obj->m_longitude, obj->m_latitude ) < g_game->GetRange( m_objectId ) - 15 )
                {
                    if ( m_currentState != STATE_BOMBERATTACK )
                    {
                        g_game->SetState( m_objectId, STATE_BOMBERATTACK );
                    }
                    else
                    {
                        g_bot->m_conditionalCommands.ConditionalActionTarget( m_objectId, obj->m_objectId, obj->m_longitude, obj->m_latitude, &checkState, m_objectId, STATE_BOMBERATTACK );
                        return;
                    }
                }
            }
        }
        g_game->SetLandingTarget( m_objectId, GetClosestLandingPad() );
    }
}

void WorldObject2::RunCarrierAI()
{    
    if( m_aiTimer <= 0 )
    {
        if( g_game->GetDefcon() <= 3 )
        {
            m_aiTimer = m_aiSpeed;
            int fleetId = g_game->GetFleetId( m_objectId );
            Fleet2 *fleet = g_bot->GetFleet2( fleetId );
            if (!fleet)
            {
                g_game->DebugLog("Warning: Fleet not created!", fleetId, "", 255, 0, 0);
            }
            vector<int> actionQueue = g_game->GetActionQueue(m_objectId);
            if( g_game->GetStateCount(m_objectId, m_currentState) - actionQueue.size() <= 0 &&
                m_currentState != STATE_CARRIERANTISUB )
            {
                return;
            }
            int desiredSate = m_currentState;
            if( m_currentState == STATE_CARRIERANTISUB )
            {
                if( fleet->m_currentState != Fleet2::AIStateIntercepting &&
                    g_game->GetCurrentTargetId(m_objectId) == -1 )
                {
                    for( unsigned int i = 0; i < fleet->m_fleetMembers.size(); ++i )
                    {
                        WorldObject2 *obj = g_bot->GetWorld2()->GetObject2( fleet->m_fleetMembers[i] );
                        if( obj )
                        {
                            if( obj->m_type == TypeCarrier && 
                                obj->m_currentState == STATE_CARRIERANTISUB && 
                                obj->m_objectId != m_objectId )
                            {
                                if( g_game->GetStateCount( m_objectId, STATE_CARRIERFIGHTERLAUNCH ) > 0 )
                                {
                                    g_game->SetState( m_objectId, STATE_CARRIERFIGHTERLAUNCH );
                                    desiredSate = STATE_CARRIERFIGHTERLAUNCH;
                                }
                                else if( g_game->GetStateCount( m_objectId, STATE_CARRIERBOMBERLAUNCH ) > 0 )
                                {
                                    g_game->SetState( m_objectId, STATE_CARRIERBOMBERLAUNCH );
                                    desiredSate = STATE_CARRIERBOMBERLAUNCH;
                                }
                                break;
                            }
                        }
                    }
                }
            }

            if( g_bot->m_targetsVisible >= 4 ||
                g_bot->m_currentState >= Bot::StateAssault )
            {
                if( g_game->GetStateCount( m_objectId, STATE_CARRIERBOMBERLAUNCH ) > 0 &&
                    g_game->GetDefcon() == 1 )
                {
                    if( m_currentState != 1 )
                    {
                        g_game->SetState( m_objectId, STATE_CARRIERBOMBERLAUNCH );
                        desiredSate = STATE_CARRIERBOMBERLAUNCH;
                    }
                    float longitude = 0;
                    float latitude = 0;
                    int objectId = -1;
                    float maxDistance = 90;
                    FindTarget( m_teamId, g_bot->m_targetTeam, m_objectId, maxDistance, &longitude, &latitude, &objectId );
                    if( ( longitude != 0 && latitude != 0 ) &&
                        ( objectId != -1 || g_bot->m_currentState >= Bot::StateAssault ) )
                    {
                        g_bot->m_conditionalCommands.ConditionalActionTarget( m_objectId, objectId, longitude, latitude, &checkState, m_objectId, desiredSate );
                        m_nukeTargetedThisTick = true;
                        m_nukeTargetLongitude = longitude;
                        m_nukeTargetLatitude = latitude;
                    }
                }
                else
                {
                    LaunchScout();
                }
            }
            else
            {
                LList<int> targets;
                int scanRange = 15;
                for( unsigned int i = 0; i < g_bot->GetWorld2()->m_units.size(); ++i )
                {
                    WorldObject2 *obj = g_bot->GetWorld2()->GetObject2( g_bot->GetWorld2()->m_units[i] );
                    if( obj )
                    {
                        // Todo: check here for events (visible through scan)
                        if( !g_bot->IsFriend( m_teamId, obj->m_teamId) &&                            
                            obj->IsMovingObject() &&
                            g_bot->CountTargettedUnits(obj->m_objectId) < 3 &&
                            g_game->GetDistance( m_longitude, m_latitude, obj->m_longitude, obj->m_latitude ) < scanRange )
                        {
                            targets.PutData( obj->m_objectId );
                        }
                    }
                }
                int targetIndex = -1;
                if( targets.Size() > 0 )
                {
                    targetIndex = targets[rand() % targets.Size()];
                }

                WorldObject2 *obj = g_bot->GetWorld2()->GetObject2( targetIndex );
                if( obj )
                {                
                    if( obj->m_type == TypeFighter ||
                        obj->m_type == TypeBomber )
                    {
                        if( g_game->GetStateTimer(m_objectId) <= 0 ) 
                        {
                            g_game->SetState( m_objectId, STATE_CARRIERFIGHTERLAUNCH );
                        }
                        g_bot->m_conditionalCommands.ConditionalActionTarget( m_objectId, obj->m_objectId, obj->m_longitude, obj->m_latitude, &checkState, m_objectId, STATE_CARRIERFIGHTERLAUNCH );
                    }
                    else if( obj->m_type == TypeSub )
                    {
                        if( g_game->GetStateTimer(m_objectId) <= 0 ) 
                        {
                            if( obj->m_currentState != STATE_CARRIERANTISUB )
                            {
                                g_game->SetState( m_objectId, STATE_CARRIERANTISUB );

                                // Move to the enemy sub
                                g_game->SetMovementTarget( m_objectId, obj->m_longitude, obj->m_latitude);
    
                            }
                            else
                            {
                                g_game->SetState( m_objectId, STATE_CARRIERBOMBERLAUNCH );
                                g_bot->m_conditionalCommands.ConditionalActionTarget( m_objectId, obj->m_objectId, obj->m_longitude, obj->m_latitude, &checkState, m_objectId, STATE_CARRIERBOMBERLAUNCH );
                                
                            }
                        }
                    }
                    else
                    {
                        if(  g_game->GetStateTimer(m_objectId) <= 0  ) 
                        {
                            g_game->SetState( m_objectId, STATE_CARRIERBOMBERLAUNCH );
                        }
                        g_bot->m_conditionalCommands.ConditionalActionTarget( m_objectId, obj->m_objectId, obj->m_longitude, obj->m_latitude, &checkState, m_objectId, STATE_CARRIERBOMBERLAUNCH );
                    }
                }
                else
                {
                    bool redirectingBombers = false;
                    int nukesupply = g_game->GetNukeSupply( m_objectId );
                    int stateBomberCount = g_game->GetStateCount( m_objectId, STATE_CARRIERBOMBERLAUNCH );
                    if( nukesupply == 0 && stateBomberCount > 0 )
                    {
                        for( unsigned int i = 0; i < g_bot->GetWorld2()->m_units.size(); ++i )
                        {
                            WorldObject2 *obj = g_bot->GetWorld2()->GetObject2( g_bot->GetWorld2()->m_units[i] );
                            if( obj )
                            {
                                if( obj->m_teamId == m_teamId &&
                                    ( obj->m_type == TypeCarrier ||
                                    obj->m_type == TypeAirBase ) )
                                {
                                    if( g_game->GetNukeSupply( obj->m_objectId ) 
                                        - g_game->GetStateCount( m_objectId, STATE_CARRIERBOMBERLAUNCH ) > 0 )
                                    {
                                        if( m_currentState != STATE_CARRIERBOMBERLAUNCH )
                                        {
                                            g_game->SetState( m_objectId, STATE_CARRIERBOMBERLAUNCH );
                                        }

                                        int nukesSpare = g_game->GetNukeSupply(obj->m_objectId) 
                                            - g_game->GetStateCount( m_objectId, STATE_CARRIERBOMBERLAUNCH );
                                        for( int j = 0; j < nukesSpare; ++j )
                                        {
                                            if( stateBomberCount - g_game->GetActionQueue(m_objectId).size() > 0 )
                                            {
                                                g_bot->m_conditionalCommands.ConditionalActionTarget( m_objectId, obj->m_objectId, obj->m_longitude, obj->m_latitude, &checkState, m_objectId, STATE_CARRIERBOMBERLAUNCH );
                                                m_nukeTargetedThisTick = true;
                                                m_nukeTargetLongitude = obj->m_longitude;
                                                m_nukeTargetLatitude = obj->m_latitude;
                                            }
                                        }
                                        redirectingBombers = true;
                                    }
                                }
                            }
                        }
                    }
                    if( g_game->GetStateCount(m_objectId, STATE_CARRIERFIGHTERLAUNCH) > 2 &&
                        !redirectingBombers )
                    {
                        LaunchScout();
                    }
                }
            }
        }
    }
}

void WorldObject2::LaunchScout()
{
    if( g_game->GetStateCount(m_objectId, STATE_CARRIERFIGHTERLAUNCH) > 0 )
    {
        if( m_currentState != STATE_CARRIERFIGHTERLAUNCH )
        {
            g_game->SetState( m_objectId, STATE_CARRIERFIGHTERLAUNCH );
        }

        int territoryId = -1;
        for( int i = 0; i < NumTerritories; ++i )
        {
            int owner = g_bot->GetTerritoryOwner( i );
            if( owner != -1 &&
                !g_bot->IsFriend( owner, m_teamId ) )
            {
                vector<float> populationCenter = g_bot->GetPopulationCenter(i);
                float distance = g_game->GetDistance( m_longitude, m_latitude, 
                    populationCenter[0], populationCenter[1]);
                float worldscale = g_game->GetOptionValue("WorldScale") / 100.0f;
                float maxRange = 45 / worldscale;
                if( distance < maxRange )
                {
                    territoryId = i;
                    break;
                }
            }
        }

        if( territoryId != -1 )
        {
            vector<float> populationCenter = g_bot->GetPopulationCenter(territoryId);
            float longitude = populationCenter[0] + g_bot->Sfrand( 60 );
            float latitude = populationCenter[1] + g_bot->Sfrand( 60 );
            g_bot->m_conditionalCommands.ConditionalActionTarget( m_objectId, -1, longitude, latitude, &checkState, m_objectId, STATE_CARRIERFIGHTERLAUNCH );
        }
    }
}

void WorldObject2::FindTarget( int team, int targetTeam, int launchedBy, float range, float *longitude, float *latitude, int *objectId )
{

    WorldObject2 *launcher = g_bot->GetWorld2()->GetObject2(launchedBy);
    if( !launcher ) 
    {
        return;
    }

    LList<int> validTargets;
    for( unsigned int i = 0; i < g_bot->GetWorld2()->m_units.size(); ++i )
    {
        WorldObject2 *obj = g_bot->GetWorld2()->GetObject2(g_bot->GetWorld2()->m_units[i]);
        if( obj->m_teamId == targetTeam &&
            !obj->IsMovingObject() )
        {
            float distance = g_game->GetDistance( launcher->m_longitude, launcher->m_latitude, obj->m_longitude, obj->m_latitude);
            if( distance <= range )
            {                    
                int numTargetedNukes = CountTargetedNukes( team, obj->m_longitude, obj->m_latitude );
                if( (obj->m_type == TypeRadarStation && numTargetedNukes < 2 ) ||
                    (obj->m_type != TypeRadarStation && numTargetedNukes < 4 ) )
                {
                    validTargets.PutData(obj->m_objectId);
                }
            }
        }
    }

    if( validTargets.Size() > 0 )
    {
        int targetId = rand() % validTargets.Size();
        int objIndex = validTargets[ targetId ];
        WorldObject2 *obj =g_bot->GetWorld2()->GetObject2(objIndex);
        if( obj )
        {
            *longitude = obj->m_longitude;
            *latitude = obj->m_latitude;
            *objectId = obj->m_objectId;
            return;
        }
    }

    int maxPop = 500000;        // Don't bother hitting cities with less than 0.5M survivors

    vector<int> cities = g_game->GetCityIds();
    for( unsigned int i = 0; i < cities.size(); ++i )
    {
        float cityLon = g_game->GetLongitude(cities[i]);
        float cityLat = g_game->GetLatitude(cities[i]);
        if( !g_bot->IsFriend( g_game->GetTeamId(cities[i]), team) && 
            g_game->GetDistance( cityLon, cityLat, launcher->m_longitude, launcher->m_latitude) <= range)               
        {
            int numTargetedNukes = CountTargetedNukes( team, cityLon, cityLat );
            int estimatedPop = (int) ( ((float) g_game->GetCityPopulation(cities[i])) * pow(0.5f, numTargetedNukes) );
            if( estimatedPop > maxPop )
            {
                maxPop = estimatedPop;
                *longitude = cityLon;
                *latitude = cityLat;
                *objectId = -1;
            }
        }
    }
}

int WorldObject2::CountTargetedNukes( int teamId, float longitude, float latitude )
{
    int targetedNukes = 0;
    for( unsigned int i = 0; i < g_bot->GetWorld2()->m_units.size(); ++i )
    {
        WorldObject2 *obj = g_bot->GetWorld2()->GetObject2(g_bot->GetWorld2()->m_units[i]);
        if (obj && obj->m_teamId == teamId )
        {
            if ( obj->m_nukeTargetedThisTick )
            {
                if( CloseTo(obj->m_nukeTargetLongitude, longitude) &&
                    CloseTo(obj->m_nukeTargetLatitude, latitude) )
                {
                    ++targetedNukes;
                }
            }
            if( obj->m_type == TypeNuke )
            {
                vector<float> movtarget = g_game->GetMovementTargetLocation( obj->m_objectId );
                float targetLongitude = movtarget[0];
                if( targetLongitude > 180 )
                {
                    targetLongitude -= 360;
                }
                else if( targetLongitude < -180 )
                {
                    targetLongitude += 360;
                }

                if( CloseTo(targetLongitude, longitude) &&
                    CloseTo(movtarget[1], latitude) )
                {
                    ++targetedNukes;
                }
            }
            else if( obj->m_type == TypeBomber )
            {
                vector<float> nukeTarget = g_game->GetBomberNukeTarget( obj->m_objectId );
                if( nukeTarget[0] == longitude &&
                    nukeTarget[1] == latitude )
                {
                    ++targetedNukes;
                }
            }
            else if( obj->m_type == TypeSub ||
                obj->m_type == TypeSilo)
            {
                int nukeState = 0;
                if( obj->m_type == TypeSub ) 
                {
                    nukeState = 2;
                }
                if( obj->m_currentState == nukeState )
                {
                    vector<int> actionQueue = g_game->GetActionQueue(obj->m_objectId);
                    for( unsigned int j = 0; j < actionQueue.size(); ++j )
                    {
                        if( g_game->GetLongitude(actionQueue[j]) == longitude &&
                            g_game->GetLatitude(actionQueue[j]) == latitude )
                        {
                            targetedNukes++;
                        }
                    }
                }
            }
            else if( obj->m_type == TypeAirBase || obj->m_type == TypeCarrier )
            {
                if( obj->m_currentState == 1 )
                {
                    vector<int> actionQueue = g_game->GetActionQueue(obj->m_objectId);
                    for( unsigned int j = 0; j < actionQueue.size(); ++j )
                    {
                        if( g_game->GetLongitude(actionQueue[j]) == longitude &&
                            g_game->GetLatitude(actionQueue[j]) == latitude )
                        {
                            targetedNukes++;
                        }
                    }
                }
            }
        }
    }
    return targetedNukes;
}

void WorldObject2::RunFighterAI()
{
    if( IsIdle() )
    {
        g_game->SetLandingTarget( m_objectId, GetClosestLandingPad() );
    }
}
void WorldObject2::RunSiloAI()
{
    if( (g_bot->m_currentState >= Bot::StateStrike &&
        g_bot->m_subState >= Bot::SubStateLaunchNukes) ||
        g_bot->m_currentState == Bot::StatePanic )
    {
        int nukeCount = g_game->GetStateCount( m_objectId, STATE_SILONUKE );
        if( m_currentState != 0 && nukeCount > 0 )
        {
            if( g_bot->m_siloSwitchTimer <= 0 )
            {
                g_game->SetState( m_objectId, STATE_SILONUKE );
                g_bot->m_siloSwitchTimer = 30;
            }
        }

        if( m_currentState == 0 &&
            nukeCount > 0 &&
            g_game->GetStateTimer( m_objectId ) <= 0 )
        {
            float longitude = 0;
            float latitude  = 0;

            int objectId = -1;
            FindTarget( m_teamId, g_bot->m_targetTeam, m_objectId, 10000000, &longitude, &latitude, &objectId );

            if( longitude != 0 && latitude != 0 )
            {
                g_bot->m_conditionalCommands.ConditionalActionTarget( m_objectId, -1, longitude, latitude, &checkState, m_objectId, STATE_SILONUKE );
                m_nukeTargetedThisTick = true;
                m_nukeTargetLongitude = longitude;
                m_nukeTargetLatitude = latitude;
            }
        }
    }
}


void WorldObject2::RunSubAI()
{
    if( m_aiTimer <= 0 )
    {
        m_aiTimer = m_aiSpeed;
        int myFleetId = g_game->GetFleetId( m_objectId );
        Fleet2 *fleet = g_bot->GetFleet2( myFleetId );
                
        // Possible improvement here: clean up destroyed targets from nuke action queue

        vector<int> actionQueue = g_game->GetActionQueue( m_objectId );

        if( g_game->GetDefcon() == 1 )
        {
            if( fleet->IsInNukeRange() )
            {
                if( g_bot->m_maxTargetsSeen >= 4 ||
                    g_bot->m_currentState >= Bot::StateAssault &&
                    g_game->GetStateTimer( m_objectId ) == 0 )
                {            
                    if( g_game->GetStateCount(m_objectId, STATE_SUBNUKE) - actionQueue.size() <= 0 )
                    {
                        return;
                    }
                    int targetsInRange = 0;
                    float maxRange = 40;
                    for( unsigned int i = 0; i < g_bot->GetWorld2()->m_units.size(); ++i )
                    {
                        WorldObject2 *obj = g_bot->GetWorld2()->GetObject2(g_bot->GetWorld2()->m_units[i]);
                        if( obj )
                        {
                            if( !obj->IsMovingObject() &&
                                !g_bot->IsFriend( obj->m_teamId, m_teamId ) &&
                                g_game->GetDistance( m_longitude, m_latitude, obj->m_longitude, obj->m_latitude ) < maxRange )
                            {
                                targetsInRange ++;
                            }
                        }
                    }

                    float longitude = 0;
                    float latitude = 0;
                    int objectId = -1;
                    int targetTeam = g_bot->m_targetTeam;
                    if( g_game->IsVictoryTimerActive() )
                    {
                        for( int i = 0; i < NumTerritories; ++i )
                        {
                            int owner = g_bot->GetTerritoryOwner(i);
                            if( owner != -1 &&
                                !g_bot->IsFriend(owner, m_teamId ) )
                            {
                                vector<float> populationCenter = g_bot->GetPopulationCenter(i);
                                float popCenterLong = populationCenter[0];
                                float popCenterLat = populationCenter[1];

                                if( g_game->GetDistance( m_longitude, m_latitude, popCenterLong, popCenterLat ) < maxRange )
                                {                                
                                    targetTeam = g_bot->GetTerritoryOwner(i);
                                    break;
                                }
                            }
                        }
                    }

                    WorldObject2::FindTarget( m_teamId, targetTeam, m_objectId, maxRange, &longitude, &latitude, &objectId );
                    if( (longitude != 0 && latitude != 0) &&
                        (targetsInRange >= 4  || (g_bot->m_currentState >= Bot::StateAssault ) ))
                    {
                        if( g_game->GetStateCount(m_objectId, STATE_SUBNUKE) - actionQueue.size() > 0 )
                        {
                            if( m_currentState != 2 )
                            {
                                g_game->SetState( m_objectId, STATE_SUBNUKE );
                            }
                            g_bot->m_conditionalCommands.ConditionalActionTarget( m_objectId, objectId, longitude, latitude, &checkState, m_objectId, STATE_SUBNUKE );
                            m_nukeTargetedThisTick = true;
                            m_nukeTargetLongitude = longitude;
                            m_nukeTargetLatitude = latitude;
                        }
                    }
                    else
                    {
                        if( actionQueue.size() == 0 )
                        {
                            g_game->SetState( m_objectId, STATE_SUBPASSIVESONAR );
                        }
                    }
                }
            }
            else
            {
                if( actionQueue.size() == 0 )
                {
                    if( m_currentState != 0 )
                    {
                        g_game->SetState( m_objectId, STATE_SUBPASSIVESONAR );
                    }
                }
            }
        }
    }
}

