#ifndef _included_export_to_defcon_h
#define _included_export_to_defcon_h

#include "import_from_defcon.h"
#include <vector>
#include <string>

//extern "C" int AI_test(int);
extern "C" bool AI_run();
extern "C" int AI_init(Funct*, std::vector< std::vector< std::string > >);
extern "C" bool AI_shutdown();
extern "C" void AI_addevent(int _eventType, int _causeObjectId, int _targetObjectId, 
							int _unitType,  float _longitude, float _latitude);


#endif
