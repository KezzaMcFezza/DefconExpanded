// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

//#include "targetver.h"

#define WIN32_LEAN_AND_MEAN             // Exclude rarely-used stuff from Windows headers
// Windows Header Files:
#include <windows.h>
#include "dll/import_from_defcon.h"
#include "bot/bot.h"
//class Funct;
extern Funct *g_game;    // Functions exposed by the Defcon API
extern Bot *g_bot;  // Local representation of the game world

// TODO: reference additional headers your program requires here
