#pragma once

#include "dll/import_from_defcon.h"
#include <vector>
#include <string>

class AbstractBot
{
public:
	#define SERVER_ADVANCE_FREQ     10                     // Num server ticks per second
	#define SERVER_ADVANCE_PERIOD   1.0f/SERVER_ADVANCE_FREQ

	virtual bool Update() = 0;
	virtual bool Initialise(Funct *f, std::vector< std::vector< std::string > > commandLineOptions) = 0;
	virtual void AddEvent(int _eventType, int _causeObjectId, int _targetObjectId, 
		int _unitType,  float _longitude, float _latitude) = 0;
};