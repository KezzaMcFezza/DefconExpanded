// dllmain.cpp : Defines the entry point for the DLL application.
#include "dll/stdafx.h"
#include "import_from_defcon.h"
#include "export_to_defcon.h"
#include "enums.h"
#include "../bot/bot.h"

#include <vector>
using namespace std;

Bot m_bot;
Funct *g_game = NULL;

extern "C" bool AI_run()
{
	m_bot.Update();


	return true;
}

extern "C" int AI_init(Funct* f, vector<vector<string>> commandLineOptions)
{
	g_game = f;
    g_game->DebugLog("commandline options: ");
    for ( unsigned int i = 0; i < commandLineOptions.size(); i++)
    {
        g_game->DebugLog(commandLineOptions[i][0] + commandLineOptions[i][1]);
    }
	m_bot.Initialise(f, commandLineOptions);
	return INTERFACE_VERSION;
}

extern "C" bool AI_shutdown()
{
	return true;
}

extern "C" void AI_addevent(int _eventType, int _causeObjectId, int _targetObjectId, 
							int _unitType,  float _longitude, float _latitude)
{
	
	m_bot.AddEvent(_eventType, _causeObjectId, _targetObjectId, 
		_unitType, _longitude, _latitude);
}