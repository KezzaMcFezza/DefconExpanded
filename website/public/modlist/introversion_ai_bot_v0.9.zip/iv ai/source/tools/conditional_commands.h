#pragma once

class ConditionalCommandItem;
class ConditionalCommandItemArgs;

class ConditionalCommandList
{
public:
    enum 
    {
        CommandActionOrder
    };
    void ConditionalActionTarget( int _unitId, int _targetUnitId, float _longitude, float _latitude, bool (*_condition)(int, int), int _conditionArg1 = 0, int _conditionArg2 = 0, int _expiryDelay = 20 );
    void Update();
    void ExecuteCommand( ConditionalCommandItem *_command );
    bool IsUnitInList( int _unitId );
private:
    std::vector<ConditionalCommandItem *> m_conditionalCommands;
};


class ConditionalCommandItemArgs
{
public:
    enum
    {
        TypeInvalid,
        TypeInt,
        TypeFloat,
        TypeString
    };
    ConditionalCommandItemArgs(int _val)
    {
        m_valType = TypeInt;
        m_intVal = _val;
    }
    ConditionalCommandItemArgs(float _val)
    {
        m_valType = TypeFloat;
        m_floatVal = _val;
    }
    ConditionalCommandItemArgs(string _val)
    {
        m_valType = TypeString;
        m_stringVal = _val;
    }
    int GetType()
    {
        return m_valType;
    }
    int GetInt()
    {
        if (m_valType == TypeInt)
            return m_intVal;
        return 0;
    }
    float GetFloat()
    {
        if (m_valType == TypeFloat)
            return m_floatVal;
        return 0.0f;
    }
    string GetString()
    {
        if (m_valType == TypeString)
            return m_stringVal;
        return "";
    }
private:
    int m_valType;
    int m_intVal;
    float m_floatVal;
    string m_stringVal;
};

class ConditionalCommandItem
{
public:
    ~ConditionalCommandItem()
    {
        for (unsigned int i = 0; i < m_args.size(); i++ )
        {
            delete m_args[i];
            m_args[i] = NULL;
        }
        m_args.clear();
    }
    
    int GetInt( int _index )
    {
        if ( m_args[_index]->GetType() == ConditionalCommandItemArgs::TypeInt )
            return m_args[_index]->GetInt();
        return 0;
    }
    float GetFloat( int _index )
    {
        if ( m_args[_index]->GetType() == ConditionalCommandItemArgs::TypeFloat )
            return m_args[_index]->GetFloat();
        return 0.0f;
    }
    std::string GetString( int _index )
    {
        if ( m_args[_index]->GetType() == ConditionalCommandItemArgs::TypeString )
            return m_args[_index]->GetString();
        return "";
    }

    int m_commandId;
    int m_unitId;
    int m_expiryTick;  
    std::vector<ConditionalCommandItemArgs *> m_args;
    bool (*ConditionFunct)( int, int );
    int m_conditionArg1;
    int m_conditionArg2;

};

