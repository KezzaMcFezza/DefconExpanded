#include "dll/stdafx.h"
#include "dll/import_from_defcon.h"
#include "tools/conditional_commands.h"


void ConditionalCommandList::Update()
{
    // iterate over list
    if (m_conditionalCommands.size() > 0)
    {
        int currentTick = g_game->GetGameTick();
        for (unsigned int i = 0; i < m_conditionalCommands.size(); i++)
        {
            // run the condition function of the command and store the result
            bool execute = m_conditionalCommands[i]->ConditionFunct( m_conditionalCommands[i]->m_conditionArg1, m_conditionalCommands[i]->m_conditionArg2 );
            if ( execute || m_conditionalCommands[i]->m_expiryTick <= currentTick )
            {
                if ( execute )
                    ExecuteCommand( m_conditionalCommands[i] );

                g_game->DebugLog("Removing conditional command!");

                // remove command
                delete m_conditionalCommands[i];
                m_conditionalCommands[i] = NULL;
                m_conditionalCommands.erase( m_conditionalCommands.begin() + i );
                i--;
            }
        }
    }
}

void ConditionalCommandList::ExecuteCommand( ConditionalCommandItem *_command )
{
    switch( _command->m_commandId ) 
    {
    case ConditionalCommandList::CommandActionOrder:
        g_game->DebugLog("Executing conditional command!");
        g_game->SetActionTarget( _command->GetInt(0), _command->GetInt(1), 
            _command->GetFloat(2), _command->GetFloat(3) );
        return;
    default:
        return;
    }
}

void ConditionalCommandList::ConditionalActionTarget( int _unitId, int _targetUnitId, float _longitude, float _latitude, bool (*_condition)(int, int), int _conditionArg1, int _conditionArg2, int _expiryDelay /*= 10 */ )
{
    // execute if condition already holds
    ConditionalCommandItem *cci = new ConditionalCommandItem();
    cci->m_commandId = ConditionalCommandList::CommandActionOrder;
    cci->m_expiryTick = g_game->GetGameTick() + _expiryDelay;
    cci->m_args.push_back( new ConditionalCommandItemArgs(_unitId) );
    cci->m_args.push_back( new ConditionalCommandItemArgs(_targetUnitId) );
    cci->m_args.push_back( new ConditionalCommandItemArgs(_longitude) );
    cci->m_args.push_back( new ConditionalCommandItemArgs(_latitude) );
    cci->ConditionFunct = _condition;
    cci->m_conditionArg1 = _conditionArg1;
    cci->m_conditionArg2 = _conditionArg2;
    cci->m_unitId = _unitId;

    if ( _condition(_conditionArg1, _conditionArg2) )
        ExecuteCommand( cci );
    else
    {
        m_conditionalCommands.push_back( cci );
        g_game->DebugLog("Storing conditional command!");
    }
}

bool ConditionalCommandList::IsUnitInList( int _unitId )
{
    for (unsigned int i = 0; i < m_conditionalCommands.size(); i++)
    {
        if (m_conditionalCommands[i]->m_unitId == _unitId)
            return true;
    }
    return false;
}