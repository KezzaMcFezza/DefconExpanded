Royal Navy Fleet Mod for Defcon

by Snoopy

This mod changes the naval units in Defcon into those of the modern day British royal navy, the changes are as follows:

Battleship -----> Type 23 Frigate
Carrier -----> Invincible Class Carrier
Sub -----> Vanguard Class Submarine

To install this mod, you must first have extraced the Defcon data folder. To do this browser to your Defcon folder (eg C:\Program Files\Defcon) and reaname the file Main.dat to Main.rar. Then simply extract the archive. Finally extract this rar to the defcon folder.

Cheers

Thanks to:

Introversion Software (for making great games from day one)