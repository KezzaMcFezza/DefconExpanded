------------------------------
DEFCON: Westeros
By: Waffleusb
------------------------------

Is the lack of senseless death in GOT getting you down? Rejoice! Reduce the entirety of Westeros to a smoldering pile of ash in this really cool and neat mod. It's based on the famous West Virginia tutorial mod and replaces the world map with Westeros, fully populated with nearly every notable castle. It also uses stolen assets from B3rgil's middle earth mod, fixing the only problem I had with it: it needed more dragons. The territories are based on Claudius42's fan map and associated canon, fixing the only thing wrong with it: no dragons (disgraceful).

----------
Changelog:
----------

v1.0: Initial release