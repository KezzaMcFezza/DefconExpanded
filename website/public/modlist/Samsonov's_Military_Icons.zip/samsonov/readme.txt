Samsonov's Military Icon Set
============================


Hello, I made this set for my own use, most icons are modelled on real NATO military icons. One exception is an airbase icon, which is basically a simplified view on a 2-runway airfield from above. Once you get used to milicons, they are very easy and QUICK to use and much easier on the eyes than your average "game art" (even though Defcon's art is pretty clean by design).


icons.png shows how it all looks in game. Take a look before you install ;o)


Installation:

1. Locate the directory where Defcon is installed. For Steam users it's usually Steam/steamapps/common/defcon.

2. Create the subfolder named "data" there (ie. full path would then be Steam/steamapps/common/defcon/data).

3. Go to folder data that you created and create the subfolder named "graphics".

4. Put all BMP files from this archive into graphics folder.


Uninstallation:

1. Simply remove folders named data and graphics and all their contents.


Game stores the graphics in main.dat file, which is in fact just your regular RAR archive. However, if you create data and data/graphics folders, files from those folders will "override" main.dat file and be used instead. Once you delete them game reverts to the original and unchanged main.dat file set and no harm is done whatsoever.

Still, my lawyers require me to put a disclaimer here - you are using this mod on your own responsibility!

Let me know if you find this useful and/or nice.


Oleg in real life (Samsonov in game) - oleg@bug.hr
 