High resolution coastlines for Defcon
Version 1.0 by Brisad, Sept. 2007

Install
--------

Simply extract the "data" folder into your Defcon root folder keeping the file structure.
The install should look something like this:
----> DRIVELETTER:\...\Defcon's game folder\data\earth\coastlines.dat


Notes: The performance may vary depending on your CPU and RAM! I have no lag whatsoever on my AMD 64 Athlon (K8NF-9), 1 Gb RAM and GeForce 8800GS.

Enjoy!

Comments and questions to bromstarzan@gmail.com
