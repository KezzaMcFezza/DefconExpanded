=====================================================
-DEFCON: AceCon: Everybody Flies TC Mod Version 1.00-
=====================================================
  --23/12/11--
================
Version History:
================
1.00 - Full Mod Release

0.95b - Added Cities.dat

0.89b - Minor GUI graphics added

0.85b - Added international.dat

0.79b - Added coastlines.dat

0.69b - Improved russia.bmp, northamerica.bmp etc.

0.60b - Improved ai_markers.bmp and travel_nodes.bmp

0.51b - Unstable beta release

0.42b - More unit graphics and fixs

0.31b - Minor map graphic changes and fixs

0.20a - Basic map graphics

0.10a - Basic unit graphics

0.05a - Basic layout of mod
 
==============
About the mod:
==============
This mod replaces the world map in Defcon with a map of Strangereal and certain 
graphic icons with aircraft and other iconic stuff from the Ace Combat series.

The 6 territories are:
*North America -  West Osea and Wellow
*South America - South and East Osea
*Russia - Yuktobania
*South Asia - Sotoa and Verusa
*Europe - Anea
*Africa - Usea.

I will complete/fix/improve these files in future versions:
*cities.dat
*coastlines.dat
*coastlines_low.dat
*international.dat
*ai_markers.bmp
*travel_nodes.bmp
*territories.bmp
*And various other files when bugs or errors appear.

===================
Installing the mod:
===================
Defcon Mods are usally packaged as ZIP or RAR files - they must be unzipped 
into your Defcon game directory, in a subfolder called "mods". Once unzipped in 
the right place they (should) will automatically show up in the Mod browser 
in-game(restart Defcon to reload the list if the mod isn't appearing).

Steam PC Users : Install MODs by unzipping them here:
c:\program files\valve\steam\steamapps\common\defcon\mods\

Regular PC Users : Install MODs by unzipping them here:
c:\program files\defcon\mods\ (or where either you installed defcon)

================
Playing the mod:
================
Please make sure when playing against other human opponents they also have the 
mod enable before they connect to your game. When setting up a new game, I 
suggest disabling Spy Mode (spectator mode), as (Spies) spectators may cause 
the game to unsync.

========================
Thanks and Contact Info:
========================
Thanks for downloading my mod, if you have any questions, or find any problems 
with the mod, please contact me at:
midsummersnow@hotmail.co.uk with "AceCon Mod" as the subject header.

Or you can contact me here at Moddb:
http://www.moddb.com/members/midsummersnow

I would like to thank:
Namco Bandai Games and Project ACES for making Ace Combat.
Introversion Software and Ambrosia Software for making a classic game.
The Ace Combat and Defcon community at large and their invaluable help.

~ Midsummersnow
