-------------------------------------------------
DEFCON: Arsenals
By: Fiiral
-------------------------------------------------

This is a modified build of the game DEFCON: Everybody Dies by Introversion Software. This build is meant to overhaul the game with new units.
This build is an early branch of the DEFCON: Expanded Edition project which allows for 8 players. It is unfinished as its creator has ceased work on it during development.

This package contains the following files:
- a data folder which contains new territories, text, and unit sprites
- the DEFCON: Arsenals executable
- this README
- the DEFCON developer license agreement

Notes:
- All players must be running the same build of the game.
- Mods that require MINICOM to run not run on this build.
- Mods that make changes to gameoptions.txt will not run on this build of the game.
- This build is Windows-only. It will likely not run on Linux or Mac.
- This mod will NOT work unless the copy of DEFCON is purchased for Introversion Software or a licensed distributor (such as Steam).
- The license agreement for DEFCON source code applies. End users are allowed to modify the modded game subject to the same license.
- This is NOT a cracked version of the game. Code relating to purchase authentication is not modified in any way. You still need to buy the game.

Foundational Work:
- Introversion Software (DEFCON)

Mod Developers:
- Fiiral

Testers:
- Sievert
- FasterThanRaito
- Ben Herr/Corporation

Known Issues:
- All DEFCON 1.6 bugs are present
- AI cannot use new units properly
- Territories are very rough

README written by Sievert