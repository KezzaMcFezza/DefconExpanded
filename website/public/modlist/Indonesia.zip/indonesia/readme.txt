====================
DEFCON Indonesia Map version 1.0
====================
9th October
===========

Version History
===============

1.0 � Release

About the mod
=============
This mod replaces the world map in Defcon with a map of Indonesia and surrounding countries.

Installing the mod
==================
I recommend download the DEFCON modloader from http://defcongame.tk/, it's a good program
which allows diffrent mods to be started easily.

Extract this zip file into the mods folder, then select it in modloader, then start a new game.

Playing the mod
===============
When playing against other human oponets, make sure they have the mod enable before they connet
to your game, when setting up a new game, i susgest disabling spectator mode, as spectators may
cause the game to unsync.

Thanks for download my map, if you have any questions, or find any problems with the mod, please
contact me at Michael_fjs@hotmail.com, or at the Introversion Defcon forums 
http://forums.introversion.co.uk/defcon

- Spacemonkey