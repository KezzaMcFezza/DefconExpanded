package.path = debug.getinfo(1, "S").source:match[[^@?(.*[\/])[^\/]-$]] .."?.lua;".. package.path

-- Required by luabot binding. Fires when the agent is selected.
function OnInit()
  SendChat("/name [BOT]Scratch")
  SendChat("Scratch pad.")
  main = coroutine.create(MTLTest)
  live = true
end

-- Also required. 100ms execution time limit. Use it wisely.
function OnTick()
  if live ~= false then
    live, err = coroutine.resume(main)
    if live == false then DebugLog(err) end
  end
end

function OnEvent()

end

function MTLTest()
  local ud = {}
  local a, b
  while true do
    coroutine.yield()
    if GetGameTick() % 10 == 0 then
      GetAllUnitData(ud)
--      for id, unit in pairs(ud) do
 --       a, b = id:GetMovementTargetLocation()
--        DebugLog(tostring(id).." Target location: "..tostring(a)..", "..tostring(b))
--        a, b = id:GetVelocity()
--        DebugLog(tostring(id).." Velocity: "..tostring(a)..", "..tostring(b))
--      end
    end
  end
end

function FMOTest()
  local a, b
  while true do
    coroutine.yield()
    if GetGameTick() % 10 == 0 then
      a, b = GetFleetMemberOffset(5, 3)
      DebugLog("Fleet offset: "..tostring(a)..", "..tostring(b))
    end
  end
end