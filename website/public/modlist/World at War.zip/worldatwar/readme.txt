World at War - By NuclearDruid

Installation:
1. Extract it into your Defcon main folder
2. Run the ModLoader from http://defcongame.tk/
OR
2. Move "data" folder from "mods/worldatwar" to the Defcon main folder