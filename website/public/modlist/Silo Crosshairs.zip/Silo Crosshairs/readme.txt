Changelog

1.1 - 03.08.15
Added a crosshair to silos in launch mode as well as AA mode.