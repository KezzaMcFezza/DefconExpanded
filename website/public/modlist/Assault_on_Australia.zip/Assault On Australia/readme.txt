

Installing the mod
==================
I recommend download the DEFCON modloader from http://defcongame.tk/, it's a good program
which allows diffrent mods/maps to be started easily.

Extract this zip file into the mods folder, then select it in modloader, then start a new game.

Playing the mod
===============
When playing against other human oponets, make sure they have the mod enable before they connet
to your game, when setting up a new game, i susgest disabling spectator mode, as spectators may
cause the game to unsync.

