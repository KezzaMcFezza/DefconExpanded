#!/bin/sh

while true; do
    $(dirname $0)/dedcon8p "$*"
done
