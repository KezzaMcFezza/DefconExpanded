-------------------------------------------------
DEFCON: 8 Players Prerelease v2.8.8
By: Fiiral, Sievert, FasterThanRaito, and Wan May
-------------------------------------------------

This is a modified build of the game DEFCON: Everybody Dies by Introversion Software. This build is meant to overcome the six-player limit hardcoded into the vanilla game and accomodate eight different players simultaneously.
This mod also works an an all-around enhancement for the game which fixes some territory gaps, bad city data, UI and UX improvements, expanded color options, and overall polish.
It is built on top of MINICOM by bert_the_turtle, the minimal community enhanced version of DEFCON which includes bugfixes, performance improvements, and improvements to unit behavior.

This package contains the following files:
[tbd]

Installation Guide:
[tbd]

Notes:
- All players must be running the same build of the game.
- Mods that require MINICOM to run will also run on this build of the game.
- Mods that make changes to gameoptions.txt will not run on this build of the game.
- This build is Windows-only. It will likely not run on Linux or Mac.
- This mod will NOT work unless the copy of DEFCON is purchased for Introversion Software or a licensed distributor (such as Steam).
- The license agreement for DEFCON source code applies. End users are allowed to modify the modded game subject to the same license.
- This is NOT a cracked version of the game. Code relating to purchase authentication is not modified in any way. You still need to buy the game.

Visit our website! https://defconexpanded.com/

Foundational Work:
- Introversion Software (DEFCON)
- bert_the_turtle (MINICOM)

Mod Developers:
- Fiiral
- Sievert
- FasterThanRaito
- wan may

Website Developers:
- KezzaMcFezza
- Sierra
- Nexustini
- DEVIL

Prerelease Testers:
- Ben Herr/Corporation
- Erroneous
- GoodNight
- Gyarados
- Jackolite
- KezzaMcFezza
- Laika
- Lævateinn
- MemeWarrior
- photophobic/Nicole
- Red Duck/demo0096
- Sierra
- Vault Tec/Idealist0
- Very Fine Art
- zak

MINICOM Developers:
- amoskvin
- bert_the_turtle
- jhkrischel
- multimania
- sysctl

---------
Changelog
---------

Prerelease v1.0 (Released 6/30/2024):
- Added two new player colors, pink and purple
- Added support for eight teams in the lobby and in-game
- Changed the maximum number of teams in the server display window to eight to properly show empty/full player slots
- Relabelled team "Turq" to "Cyan"
- Changed territories to accomodate new teams: North America, South America, Europe+Greenland, Russia+Kazakhstan, Middle East+North Africa, Sub-Saharan Africa, South Asia+Oceania, and East Asia
- Various minor changes to territories, such as cleaner borders and sensible territory inclusion
- Changed travel nodes around the Philippines to allow passage around and into the South China Sea rather than straight through
- Added travel nodes to connect through the Bering Strait to allow easier passage
- Rounded out China's coastline so that random cities don't appear to be in the middle of the Taiwan strait
- Rebalanced populations by metropolitan area, changes are minor but city data should be more accurate proportionally
- Changed the capital for the Philippines to Manila instead of Quezon City
- Fixed bugged cities in Algeria and Benin, they now show properly instead of random British cities
- Fixed Vladivostok, Miami and Copenhagen not placing properly
- Added Pyongyang to the cities file for North Korea
- Moved Jeddah onto land so that it does not appear to be in the middle of the Red Sea
- Moved San Francisco closer to the west coast of the United States
- Moved Las Vegas to its proper place, it was east of Santa Fe before
- Deleted a duplicate entry of St. John, New Brunswick
- Deleted a duplicate entry of Manila, Philippines
- Deleted Oroumich, Iran from the cities list as it is the same city as Rezaiyeh 
- Deleted Kananga, Zaire from the cities list as it is the same city as Luluabourg 
- Cities which previously included a province or state in its name no longer do so
- Renamed certain cities with bizarre spellings and formatting
- Unabbreviated USA and USSR when country names are displayed, now they are simply displayed as "United States" and "Soviet Union"
- North and South Korean cities properly display "North Korea" and "South Korea" instead of just "Korea"
- North and South Vietnamese cities display "North Vietnam" and "South Vietnam" instead of just "Viet Nam"
- Shortened various country names in city data that were unnecessarily long (East Germany, Libya, Syria, Cambodia)
- Post-Soviet states have all their cities properly marked as their respective country rather than just the capital and major cities
- Renamed Ho Chi Minh City to Saigon and marked it as a capital so that it would not get overwritten by Phnom Penh during city placement
- Added DEFCON Discord link as splash text
- Updated each localization to properly display color text and tutorial text for correct matchups
- Changed text for DEFCON version on main menu to display build version and developers

Prerelease v1.1 (Released 7/7/2024):
- Removed the panic button/boss key as it doesn't have a real use and just confuses people unfamiliar with it 
- Added a custom icon to the program to differentiate it from vanilla DEFCON 
- Fixed right-facing airbases/carriers/subs from having offset smallnuke/smallbomber/smallfighter sprites (bug that popped up in Prerelease v1.0)
- Moved modified game resources into a new data directory instead of having to activate a companion mod
- Packaged a modified version of All Cities mod with the build
- Packaged an 8-Player Cold War mod by FasterThanRaito with the build
- Gave Sakhalin to Russia's territory
- Gave Cuba, Hispaniola, Puerto Rico, and Jamaica to North America
- Shaved some territory off of southern Spain to avoid Europe placing in Morocco
- Changed travel nodes around the Carribean islands to allow for naval passage into the Gulf of Mexico and the Carribean Sea
- Deleted Kermanshah, Iran from the cities list as it is the same city as Bakhtaran
- Changed the Rolling Demo to show 8 players instead of 3
- Added an installation video guide

Prerelease v1.2 (Released 7/14/2024):
- Changed the game base from DEFCON to MINICOM
- Undid MINICOM's feature which stored preferences and authkey files in Documents/My Games
- Reformat and clean up MINICOM's packaged vanilla reversion mods, they will be the only mods packaged from the start
- Removed Cold War: 8 Players and All Cities: 8 Players from the package, they will be available on the modlist
- Removed Panic Key dropdown in Options since functionality was removed in Prerelease v1.1
- Added a game option which lets you scale the number of units in a game. Mostly intended to allow cancelling out more units on a larger world scale
- Moved Discord splash message to localization files and given proper translations instead of being hardcoded to English
- Fixed bug where the last language in the options menu would display twice

Prerelease v1.3 (Released 7/21/2024):
- Added support for 16 different team colors
- Added option for unit outlines in graphics settings to make them easier to see against the water
- Changed unit ghost texture so that it is hatched. This makes ghosts distinct from the light gray team color
- Packaged a temporary 7-player setup until we can get arbitrary numbers of players working

Prerelease v2.8.7 (Released 7/28/2024):
- Created three builds (temporarily) for 8, 10, and 16 players
- Redid version schema
- Added a bomber launch option that allows for launching without a nuke loaded
- Added a color picker in the alliance window for quickly swapping to the desired color - you can't swap to colors in use and if you're in an alliance, more than half must vote for the change
- Made the alliances window open in the center of the screen
- Slightly increased the height of the graphics option window to allow space for the new graphical options

Prerelease v2.8.8 (Released 8/4/2024):
- Changed territory distribution based on opinions from more experienced players, now the setup is near identical to the original aside from splitting asia into west and east, and adding Oceania
- Packaged some 7-player and 8-player setups for testing, including a normal 7-player setup, a 7-player Cold War setup, and the previous 8-player setup desgined by FasterThanRaito/Sievert

Future Plans (Not final, kind of a wishlist):
- Integration with Raito's 10 + 16 player builds
- Map selector in lobby
- Radar range bmp toggle
- Ability to toggle the seam on and off - huge for map mods
- More drawing tools - cirlces, line segments, et cetera
- Sierra found a potentially gamebreaking bug?
- Spectator ability to draw
- Change project name
- Graphical option to display exact population instead of truncated version
- Fix desync involving team switching with the color window open
- Fix spectator names always showing as "Spectator" - MINICOM issue
- Fix color picker window getting longer during voting segments
- Fix blip.bmp showing as an error texture when unit outlines are turned on
- Fix Yokohama appearing in Aomori Prefecture in Japan
- FIX CRASHES