------------------------------------------
DEFCON - Japan and Korea  Mod - By Sievert
------------------------------------------

This mod replaces the playable world with a detailed map of Japan. Each terriory has a full roster of at least 50 cities with populations slightly rebalanced for gameplay reasons.
If you want to play with original unbalanced city population proportions, I've included a cities_real.dat which you can swap between as you please.
The map features fully functioning travel nodes between the islands of Honshu, Kyushu and Shikoku. You cannot fully navigate the channels as that would circumvent vital chokepoints.
The Pacific-Yellow Sea reacharound is baked into DEFCON's source code and is impossible to remove in the vanilla executable.
Each city is marked as a captial in cities.dat to override DEFCON's city placement distance requirements, so you probably want to disable "Show Country Names" in graphics settings.
A 2v2 edition is also included. It is installed identically to the main mod, but divides Japan into two parts instead of three so you can play a 2v2 with Japan vs Korea. Manchuria/Russia is included but it is not recommended as they are just placeholder territories to avoid the game bugging out with automatic placement. You could also run a 1v1 with 3 territories per player and do a Cold War NK+USSR+China vs SK+ Japan scenario. Up to you. :P

Thank you very much for playing my mod. Please let me know if there's anything I can do to improve it. You can contact me via Discord if you'd like at my handle "megasievert". 

Thanks to FasterThanRaito and Corporation/Ben Herr for playtesting and giving advice. Their input was invaluable for quality assurance.

I sincerely hope you enjoy.

	-Sievert

---------
Changelog
---------

v1.01: Removed duplicate city in North Korea (Chongju)
v1.02: Added coastlines-low.dat curteousy of wan may