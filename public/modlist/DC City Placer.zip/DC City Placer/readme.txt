=================================
=      DEFCON CITY PLACER       =
=========== VERSION ? ===========
= README FILE    4th of October =
=================================

= 1. TABLE OF CONTENTS =
========================
1. Table of Contents
2. Files in archive
3. Who? What? When? Where?
4. How to install
5. Version History


= 2. FILES IN ARCHIVE =
=======================
ARCHIVE NAME: dccityplacer.zip

dccityplacer.exe			The application
readme.txt				This file

If there are any other files/directories than these in the archive, quickly delete the archive and all files extracted, but not listed above, then do a full virus scan. If you still want to use this mod, please download a fresh .zip archive file from http://defcongame.tk/


= 3. WHO? WHAT? WHEN? WHERE? =
==============================
The "DEFCON CityPlacer" is a small application for quickly and painlessly adding cities to the game (more specifically, to 'data\earth\cities.dat'.
If an existing 'cities.dat' is found, the application appends every new city to that. Else it just creates a new 'data\earth\cities.dat' file.

By default, the program loads the map from "data\graphics\map.bmp" (or uses it's internal high-res map.bmp if that file doesn't exist).
By using the menu, you can load a different map file as a background, thus making the tool exponentially more useful.

Anyway, more info can be found at:
http://defcongame.tk/


= 4. HOW TO INSTALL =
=====================
Unzip this archive in the main DEFCON directory. Then just run the application.
Click anywhere on the map to add a city there. You're then presented with 3 textboxes (City, Country and Population) and an 'Add' button.
Pretty self-explanatory, I hope.


= 5. Version History =
======================

release 4th of October