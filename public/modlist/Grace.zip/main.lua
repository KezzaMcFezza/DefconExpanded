-- *****
-- Grace
-- *****
-- Sean McPhail, 2010
-- smc10028@gmail.com

-- Make require look in this folder for .lua files
package.path = debug.getinfo(1, "S").source:match[[^@?(.*[\/])[^\/]-$]] .."?.lua;".. package.path

-- Required files
require "setup"
require "grace"
require "tasks"
require "activities"
require "atoms"
require "grace_utilities"
require "draw"              -- draw package by Ciar�n Eaton
require "utility"


function OnInit()
SendChat "/name [Bot]Grace"
SendChat "Hello, I'm Grace, version 0.4.0"
  
Initiation()
LoadMaps()
  
end

function OnTick()

if GAME_TICK==0 then
   FIRST_TICK=GetGameTick()
   GAME_TICK=FIRST_TICK
   print("First game tick = ",FIRST_TICK)
else
   GAME_TICK=GAME_TICK+1
   GAME_TIME=GetGameTime()
end

if GAME_TICK==FIRST_TICK+1 then
   Setup()
   Initial_Strategy()
   Place_Structures()
end 

if (GAME_TICK>FIRST_TICK+1 and GAME_TICK<FIRST_TICK+39) then
   Place_Fleet()
end

-- define main grace cycle
if GAME_TICK==FIRST_TICK+40 then
   print("Beginning Grace")
   StartLongTask(function()
   time_management()
   end) 
end

-- Start working on Whiteboard markup and Grace main loop
WorkOnLongTasks()

end


function OnFirstTick()
end


function OnEvent(eventType, sourceID, targetID, unitType, longitude, latitude)
--  print(eventType, ",", tostring(sourceID), ",", tostring(targetID), ",", unitType, (", %.3f , %.3f"):format(longitude, latitude))
end


function OnShutdown()
end


