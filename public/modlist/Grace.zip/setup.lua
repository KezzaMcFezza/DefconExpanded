-- ***********
-- Grace setup
-- ***********
-- Sean McPhail, 2010
-- smc10028@gmail.com

--[[
This file holds functions called only once when Grace is setting up.
]]

function Initiation()
-- ** set up global variables **
LONG_SQS = 36
LAT_SQS =20

GAME_TICK=0
GAME_TIME=0
FIRST_TICK=0
DEFCON=5 


-- global variables for hardcoded fleet centres. Remove in Grace 0.8
FLEET_CENTRE1 ={}
FLEET_CENTRE2 ={}

-- global table to hold team ids
TEAMS={}

-- global data variables

EXTRA_UNIT_DATA ={} -- global extra data for units
TASK_GROUP = {}    -- global task groups
MAP = {}          -- global maps variable

MAP["population"]={}

UNIT_DATA ={}     -- global unit data
UNIT_MAPS={}      -- global units maps - merge with "MAP?"
CITY_DATA={}

-- proper random numbers!
math.randomseed(os.time())

end




function Setup()
-- called as soon as game starts when game specific knowledge is available

-- find out some basic facts about the world
k = {}

grace_team_id=GetOwnTeamID()
local location=GetTeamTerritories(grace_team_id)
k.territory=location[1]

print("I am in ",k.territory)

local cities = GetCityIDs()
   
   for _, city in ipairs(cities) do
  --    local long, lat, pop = city:GetLongitude(), city:GetLatitude(), city:GetCityPopulation()

      CITY_DATA[city]={}
      CITY_DATA[city]["longitude"]=GetLongitude(city)
      CITY_DATA[city]["latitude"]=GetLatitude(city)
      CITY_DATA[city]["team"]=GetTeamID(city)

  
-- code for future application to mutiple enemies
      if TEAMS[CITY_DATA[city]["team"]]==nil then
         TEAMS[CITY_DATA[city]["team"]]=CITY_DATA[city]["team"]
      end
  
	  if  CITY_DATA[city]["team"]~= grace_team_id then
         enemy_team_id=CITY_DATA[city]["team"]   
      end
   end
 
 
    if enemy_team_id==nil then
       print("No enemy detected.")
	   enemy_team_id=0
    else
       enemy_location=GetTeamTerritories(enemy_team_id)
       k.enemy_territory=enemy_location[1]
       print("Enemy is in",k.enemy_territory)
    end

-- setup whiteboard
--[[
StartLongTask(function()
   SetupWhiteboard(GrowMap(MAP[k.territory]))
   end)
]]
end


function SetupWhiteboard(this_map)
-- mark up whiteboard with a map, one square per tick, box=1, no-box = other value
local x,y,i,j
print("Marking up whiteboard")

for x = -175,175,10 do
   for y = -95,95,10 do

      i=(x-5)/10+19
      j=10-(y-5)/10
      if this_map[i][j]==1 then	
          draw.Square3f(x, y, 10)
      end
      YieldLongTask() 
   end	
end
end



function SetupUnitTable()
--[[ Loops over all units and populates task groups with units

** Temporary function to be replaced **
 
]]

print("Populating task groups")
UNIT_DATA = GetAllUnitData()

for id, data in pairs(UNIT_DATA) do

   if data.team==grace_team_id then
      
         if (data.type == "AirBase") then
               TASK_GROUP[2]["units"][id]=id        
         elseif (data.type == "BattleShip") then

            if ((data.longitude- FLEET_CENTRE1.long)<20 and (data.latitude- FLEET_CENTRE1.lat)<20) then
               TASK_GROUP[4]["units"][id]=id			   
            else
               TASK_GROUP[5]["units"][id]=id
            end

         elseif (data.type == "Carrier") then

            if ((data.longitude- FLEET_CENTRE1.long)<20 and (data.latitude- FLEET_CENTRE1.lat)<20) then
               TASK_GROUP[4]["units"][id]=id
            else
               TASK_GROUP[5]["units"][id]=id
            end

-- Not allocating Radar to task groups
--            elseif (data.type == "RadarStation") then

         elseif (data.type == "Silo") then
            TASK_GROUP[1]["units"][id]=id
         elseif (data.type == "Sub") then
            if ((data.longitude- FLEET_CENTRE1.long)<20 and (data.latitude- FLEET_CENTRE1.lat)<20) then
               TASK_GROUP[4]["units"][id]=id
            else
               TASK_GROUP[5]["units"][id]=id
            end     
             
         end

   end
end
end



function Initial_Strategy()

--[[ Sets initial task group tasks and targets
** Hardcoded until Grace 0.8 **
]]

--set up task groups

CreateTaskGroup(0,"Intercept",{},"Fighter Intercept",0,0,nil,{})
CreateTaskGroup(1,"Silos",{},"Defence",0,0,nil,{})
CreateTaskGroup(2,"Territory Air Defence",{},"TAD",nil,nil,nil,{["atoms"]={"AtomAirbaseWait", "AtomScoutFighter","AtomMusterBombers", "AtomEqualiseFighters", "AtomEqualiseBombers", "AtomSupplyFightersToCarriers", "AtomSupplyBombersToCarriers"}})
CreateTaskGroup(3,"Coast Guard",{},"Waiting",0,0,nil,{})
CreateTaskGroup(4,"Sweep and Clear",{},"Scout",-30,-30,nil,{})
CreateTaskGroup(5,"Sweep and Clear",{},"Scout",-30,-20,nil,{})





if k.enemy_territory~=nil then
-- if we detect an enemy (otherwise use values hardcoded in setup)
   
   local dummy
   local targ1_x, targ1_y,targ1_long,targ1_lat
   local targ2_x, targ2_y,targ2_long,targ2_lat


   dummy, targ1_x, targ1_y =    MaxMap(MultiplyMaps(MultiplyMaps(BoundMap(GrowMap(MAP[k.enemy_territory])),MAP["Sea"]),RandomMap(10)))
   dummy, targ2_x, targ2_y =    MaxMap(MultiplyMaps(MultiplyMaps(BoundMap(GrowMap(MAP[k.enemy_territory])),MAP["Sea"]),RandomMap(10)))
 
   targ1_long, targ1_lat = MapCoordToLongLat(targ1_x,targ1_y)
   targ2_long, targ2_lat = MapCoordToLongLat(targ2_x,targ2_y)

 
   TASK_GROUP[4]["target_long"]= targ1_long
   TASK_GROUP[4]["target_lat"]=targ1_lat
   print("Task Group 4 target: Long ",targ1_long,", Lat ",targ1_lat)
   
   TASK_GROUP[5]["target_long"]=targ2_long
   TASK_GROUP[5]["target_lat"]=targ2_lat
   print("Task Group 5 target: Long ",targ2_long,", Lat ",targ2_lat)


end
end




function Place_Structures()
--[[
Places structures
** Hardcoded until Grace 0.8 **
]]

SendChat "Placing structures"

-- define a centre point to place around

local centre = {}
if (k.territory == "Africa") then
   centre.lat = 15
   centre.long = 15
elseif (k.territory == "Europe") then
   centre.lat = 47
   centre.long = 17
elseif (k.territory == "NorthAmerica") then
   centre.lat= 45
   centre.long = -100
elseif (k.territory == "Russia") then
   centre.lat = 60
   centre.long = 57
elseif (k.territory == "SouthAmerica") then
   centre.lat = -10
   centre.long = -60
elseif (k.territory == "SouthAsia") then
   centre.lat = 35
   centre.long = 90
end

--place silos
centre.scale=6

PlaceStructure(centre.long-centre.scale, centre.lat+centre.scale/2, "Silo")
PlaceStructure(centre.long, centre.lat+centre.scale/2, "Silo")
PlaceStructure(centre.long+centre.scale, centre.lat+centre.scale/2, "Silo")
PlaceStructure(centre.long-centre.scale, centre.lat-centre.scale/2, "Silo")
PlaceStructure(centre.long, centre.lat-centre.scale/2, "Silo")
PlaceStructure(centre.long+centre.scale, centre.lat-centre.scale/2, "Silo")


--place scout radar
if k.enemy_territory~=nil then

   scout_radar_long={-111.5, -103.6, -88.8, -117.1, -97.2, -81.2, 33.7, 21.4,  9.7, -5.1, 49.3, -2.6, 22.0, 38.9, 29.3, 44.0, 35.3, 47.0, 70.3, 100.1, 131.9, 109.6, 87.2, 46.3, 28.9, 31.0, 55.6}
   scout_radar_lat= {  30.0,   28.3,  20.0,   34.6,  27.8,  26.7, 25.9, 32.0, 36.7, 35.0,  9.8, 37.7, 38.9, 49.1, 62.9, 14.1, 29.1, 39.1, 55.0,  51.4,  40.0,  48.0, 48.0, 43.1, 57.4, 65.5, 44.0}

--loop through scout_radar co-ords and check if in enemy boundary region
   for i = 1,27 do

      local temp_map=GrowMap(MAP[k.enemy_territory])
      local temp_long,temp_lat=LongLatToMapCoord(scout_radar_long[i],scout_radar_lat[i])

      if temp_map[temp_long][temp_lat]>0 then
         PlaceStructure(scout_radar_long[i], scout_radar_lat[i], "RadarStation")
      end

   end
end

--place radar
PlaceStructure(centre.long-centre.scale*0.5, centre.lat+centre.scale*1.2, "RadarStation")
PlaceStructure(centre.long-centre.scale*1.5, centre.lat+centre.scale*1.2, "RadarStation")
PlaceStructure(centre.long+centre.scale*0.5, centre.lat+centre.scale*1.2, "RadarStation")
PlaceStructure(centre.long+centre.scale*1.5, centre.lat+centre.scale*1.2, "RadarStation")
PlaceStructure(centre.long-centre.scale*3, centre.lat, "RadarStation")
PlaceStructure(centre.long+centre.scale*3, centre.lat, "RadarStation")
PlaceStructure(centre.long, centre.lat+centre.scale*2, "RadarStation")

--place airbases
PlaceStructure(centre.long-centre.scale*2, centre.lat+centre.scale/2, "AirBase")

PlaceStructure(centre.long+centre.scale*2, centre.lat+centre.scale/2, "AirBase")
PlaceStructure(centre.long-centre.scale*2, centre.lat-centre.scale/2, "AirBase")
PlaceStructure(centre.long+centre.scale*2, centre.lat-centre.scale/2, "AirBase")

end



function Place_Fleet()
--[[ Place the fleet in two lumps
** Hard coded until Grace 0.8 **
]]

if (k.territory == "Africa") then
   FLEET_CENTRE1.lat = -10
   FLEET_CENTRE1.long = -10
elseif (k.territory == "Europe") then
   FLEET_CENTRE1.lat = 50
   FLEET_CENTRE1.long = -25
elseif (k.territory == "NorthAmerica") then
   FLEET_CENTRE1.lat = 30
   FLEET_CENTRE1.long = -135
elseif (k.territory == "Russia") then
   FLEET_CENTRE1.lat = 80
   FLEET_CENTRE1.long = 45
elseif (k.territory == "SouthAmerica") then
   FLEET_CENTRE1.lat = 1
   FLEET_CENTRE1.long = -105
elseif (k.territory == "SouthAsia") then
   FLEET_CENTRE1.lat = -5
   FLEET_CENTRE1.long = 85
end

if (k.territory == "Africa") then
   FLEET_CENTRE2.lat = -5
   FLEET_CENTRE2.long = 60
elseif (k.territory == "Europe") then
   FLEET_CENTRE2.lat = 74
   FLEET_CENTRE2.long = -1
elseif (k.territory == "NorthAmerica") then
   FLEET_CENTRE2.lat= 35
   FLEET_CENTRE2.long = -55
elseif (k.territory == "Russia") then
   FLEET_CENTRE2.lat = 45
   FLEET_CENTRE2.long = 170
elseif (k.territory == "SouthAmerica") then
   FLEET_CENTRE2.lat = -35
   FLEET_CENTRE2.long = -30
elseif (k.territory == "SouthAsia") then
   FLEET_CENTRE2.lat = 20
   FLEET_CENTRE2.long = 140
end

-- Place fleet one tick at a time

if (GAME_TICK==FIRST_TICK+2) then

   print("Placing fleet")
   PlaceFleet(FLEET_CENTRE1.long+4,FLEET_CENTRE1.lat+2,"BattleShip")	
elseif (GAME_TICK==FIRST_TICK+3) then
   PlaceFleet(FLEET_CENTRE1.long,FLEET_CENTRE1.lat+2,"BattleShip")	
elseif (GAME_TICK==FIRST_TICK+4) then
   PlaceFleet(FLEET_CENTRE1.long-4,FLEET_CENTRE1.lat+2,"BattleShip")	
elseif (GAME_TICK==FIRST_TICK+5) then
   PlaceFleet(FLEET_CENTRE1.long+4,FLEET_CENTRE1.lat,"BattleShip")	
elseif (GAME_TICK==FIRST_TICK+6) then
   PlaceFleet(FLEET_CENTRE1.long,FLEET_CENTRE1.lat,"BattleShip")	
elseif (GAME_TICK==FIRST_TICK+7) then
   PlaceFleet(FLEET_CENTRE1.long-4,FLEET_CENTRE1.lat,"BattleShip")	
elseif (GAME_TICK==FIRST_TICK+8) then

   PlaceFleet(FLEET_CENTRE2.long+4,FLEET_CENTRE2.lat+2,"BattleShip")	
elseif (GAME_TICK==FIRST_TICK+9) then
   PlaceFleet(FLEET_CENTRE2.long,FLEET_CENTRE2.lat+2,"BattleShip")	
elseif (GAME_TICK==FIRST_TICK+10) then
   PlaceFleet(FLEET_CENTRE2.long-4,FLEET_CENTRE2.lat+2,"BattleShip")	
elseif (GAME_TICK==FIRST_TICK+11) then
   PlaceFleet(FLEET_CENTRE2.long+4,FLEET_CENTRE2.lat,"BattleShip")	
elseif (GAME_TICK==FIRST_TICK+12) then
   PlaceFleet(FLEET_CENTRE2.long,FLEET_CENTRE2.lat,"BattleShip")	
elseif (GAME_TICK==FIRST_TICK+13) then
   PlaceFleet(FLEET_CENTRE2.long-4,FLEET_CENTRE2.lat,"BattleShip")	

elseif (GAME_TICK==FIRST_TICK+14) then
   PlaceFleet(FLEET_CENTRE1.long+4,FLEET_CENTRE1.lat-2,"Carrier")	
elseif (GAME_TICK==FIRST_TICK+15) then
   PlaceFleet(FLEET_CENTRE1.long,FLEET_CENTRE1.lat-2,"Carrier")	
elseif (GAME_TICK==FIRST_TICK+16) then
   PlaceFleet(FLEET_CENTRE1.long-4,FLEET_CENTRE1.lat-2,"Carrier")	
elseif (GAME_TICK==FIRST_TICK+17) then
   PlaceFleet(FLEET_CENTRE1.long+4,FLEET_CENTRE1.lat-4,"Carrier")	
elseif (GAME_TICK==FIRST_TICK+18) then
   PlaceFleet(FLEET_CENTRE1.long,FLEET_CENTRE1.lat-4,"Carrier")	
elseif (GAME_TICK==FIRST_TICK+19) then
   PlaceFleet(FLEET_CENTRE1.long-4,FLEET_CENTRE1.lat-4,"Carrier")	

elseif (GAME_TICK==FIRST_TICK+20) then
   PlaceFleet(FLEET_CENTRE2.long+4,FLEET_CENTRE2.lat-2,"Carrier")	
elseif (GAME_TICK==FIRST_TICK+21) then
   PlaceFleet(FLEET_CENTRE2.long,FLEET_CENTRE2.lat-2,"Carrier")	
elseif (GAME_TICK==FIRST_TICK+22) then
   PlaceFleet(FLEET_CENTRE2.long-4,FLEET_CENTRE2.lat-2,"Carrier")	
elseif (GAME_TICK==FIRST_TICK+23) then
   PlaceFleet(FLEET_CENTRE2.long+4,FLEET_CENTRE2.lat-4,"Carrier")	
elseif (GAME_TICK==FIRST_TICK+24) then
   PlaceFleet(FLEET_CENTRE2.long,FLEET_CENTRE2.lat-4,"Carrier")	
elseif (GAME_TICK==FIRST_TICK+25) then
   PlaceFleet(FLEET_CENTRE2.long-4,FLEET_CENTRE2.lat-4,"Carrier")	

elseif (GAME_TICK==FIRST_TICK+26) then
   PlaceFleet(FLEET_CENTRE1.long+4,FLEET_CENTRE1.lat-6,"Sub")	
elseif (GAME_TICK==FIRST_TICK+27) then
   PlaceFleet(FLEET_CENTRE1.long,FLEET_CENTRE1.lat-6,"Sub")	
elseif (GAME_TICK==FIRST_TICK+28) then
   PlaceFleet(FLEET_CENTRE1.long-4,FLEET_CENTRE1.lat-6,"Sub")	
elseif (GAME_TICK==FIRST_TICK+29) then
   PlaceFleet(FLEET_CENTRE1.long+4,FLEET_CENTRE1.lat-8,"Sub")	
elseif (GAME_TICK==FIRST_TICK+30) then
   PlaceFleet(FLEET_CENTRE1.long,FLEET_CENTRE1.lat-8,"Sub")	
elseif (GAME_TICK==FIRST_TICK+31) then
   PlaceFleet(FLEET_CENTRE1.long-4,FLEET_CENTRE1.lat-8,"Sub")	
elseif (GAME_TICK==FIRST_TICK+32) then

   PlaceFleet(FLEET_CENTRE2.long+4,FLEET_CENTRE2.lat-6,"Sub")	
elseif (GAME_TICK==FIRST_TICK+33) then
   PlaceFleet(FLEET_CENTRE2.long,FLEET_CENTRE2.lat-6,"Sub")	
elseif (GAME_TICK==FIRST_TICK+34) then
   PlaceFleet(FLEET_CENTRE2.long-4,FLEET_CENTRE2.lat-6,"Sub")	
elseif (GAME_TICK==FIRST_TICK+35) then
   PlaceFleet(FLEET_CENTRE2.long+4,FLEET_CENTRE2.lat-8,"Sub")	
elseif (GAME_TICK==FIRST_TICK+36) then
   PlaceFleet(FLEET_CENTRE2.long,FLEET_CENTRE2.lat-8,"Sub")	
elseif (GAME_TICK==FIRST_TICK+37) then
   PlaceFleet(FLEET_CENTRE2.long-4,FLEET_CENTRE2.lat-8,"Sub")	

-- allocate units to Task Groups
elseif (GAME_TICK==FIRST_TICK+38) then
  SetupUnitTable()
end



end



function load_information()
-- load library of maps from csv file
-- not used anymore - replaced by LoadMaps, but might prove useful at some point

-- !!UGLY!!, got to fix this
io.input("C:\\Program Files (x86)\\Defcon\\AI\\luabot\\library.csv")

local i,j
local string_pos,last_comma, string_length
local this_line
local map_name
 
while io.read(0)~=nil do
   map_name=io.read("*line")
   print("Loading: ", map_name)

-- create a new map
   MAP[map_name] = {} 
   for i=1,LONG_SQS do
        MAP[map_name][i] = {}     
        for j=1,LAT_SQS do
           MAP[map_name][i][j] = 0
        end
   end
   
-- take each line as a string in turn
-- function adapted from "Programming in Lua", R Ierusalimschy
   for j=1,LAT_SQS do
      this_line=io.read("*line")

      string_pos=1
      last_comma=0
      string_length=string.len(this_line)
      i=1

-- loop through string extracting values and assigning to map cells
      while string_pos<=string_length+1 do

         if (string.sub(this_line,string_pos,string_pos)=="," or string_pos==string_length+1) then
            MAP[map_name][i][j]=tonumber(string.sub(this_line,last_comma+1,string_pos-1))
            i=i+1
            last_comma=string_pos
         end
         string_pos=string_pos+1
      end
   end

end
end


function LoadMaps()
MAP["NorthAmerica"]={
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}}
MAP["SouthAmerica"]={
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,0,0,0,0},
{0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,0,0,0,0},
{0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}}
MAP["Europe"]={
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}}
MAP["Russia"]={
{0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}}
MAP["SouthAsia"]={
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}}
MAP["Africa"]={
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,1,1,1,1,1,1,1,1,0,0,0,0,0,0},
{0,0,0,0,0,0,1,1,1,1,1,1,1,1,0,0,0,0,0,0},
{0,0,0,0,0,0,0,1,1,1,1,1,1,1,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}}
MAP["Land"]={
{0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1},
{0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1},
{0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1},
{0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1},
{0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1},
{0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,1,1,1},
{0,0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,1,1,1},
{0,0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,1,1,1},
{0,0,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,1,1,1},
{0,0,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,1,1,1},
{0,0,1,1,1,1,0,0,1,1,1,1,0,0,1,0,0,1,1,1},
{0,0,1,1,1,1,0,0,0,1,1,1,1,1,1,1,1,1,1,1},
{0,0,1,0,0,1,0,0,0,1,1,1,1,1,0,0,0,0,1,1},
{0,0,1,1,0,0,0,0,0,0,1,1,1,0,0,0,0,0,1,1},
{0,0,1,1,0,0,0,0,0,0,1,1,0,0,0,0,0,0,1,1},
{0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1},
{0,0,0,1,0,0,0,1,1,0,0,0,0,0,0,0,0,1,1,1},
{0,0,0,0,1,1,1,1,1,1,0,0,0,0,0,0,0,1,1,1},
{0,0,0,0,1,1,1,1,1,1,0,0,0,0,0,0,0,1,1,1},
{0,0,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,1,1,1},
{0,0,0,1,1,1,1,1,1,1,1,1,1,1,0,0,0,1,1,1},
{0,0,0,1,1,1,1,1,1,1,1,1,1,0,0,0,0,1,1,1},
{0,0,0,1,1,1,1,1,1,1,0,1,1,0,0,0,0,1,1,1},
{0,0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,1,1,1},
{0,0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,1,1,1},
{0,0,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,1,1,1},
{0,0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,1,1,1},
{0,0,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,1,1,1},
{0,0,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,1,1,1},
{0,0,0,1,1,1,1,1,1,1,1,0,1,1,0,0,0,1,1,1},
{0,0,0,1,1,1,1,0,1,1,1,1,1,1,0,0,0,1,1,1},
{0,0,0,1,1,1,1,0,0,0,1,1,1,1,0,0,0,1,1,1},
{0,0,1,1,1,1,0,0,0,0,1,1,1,1,0,0,0,1,1,1},
{0,0,0,1,1,0,0,0,0,0,0,0,1,1,0,0,0,1,1,1},
{0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1},
{0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1}}
MAP["Sea"]={
{1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0},
{1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0},
{1,1,1,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0},
{1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0},
{1,1,1,0,0,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0},
{1,1,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,0,0,0},
{1,1,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,0,0,0},
{1,1,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,0,0,0},
{1,1,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,0,0,0},
{1,1,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,0,0,0},
{1,1,0,0,0,0,1,1,0,0,0,0,1,1,0,1,1,0,0,0},
{1,1,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0},
{1,1,0,1,1,0,1,1,1,0,0,0,0,0,1,1,1,1,0,0},
{1,1,0,0,1,1,1,1,1,1,0,0,0,1,1,1,1,1,0,0},
{1,1,0,0,1,1,1,1,1,1,0,0,1,1,1,1,1,1,0,0},
{1,1,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0},
{1,1,1,0,1,1,1,0,0,1,1,1,1,1,1,1,1,0,0,0},
{1,1,1,1,0,0,0,0,0,0,1,1,1,1,1,1,1,0,0,0},
{1,1,1,1,0,0,0,0,0,0,1,1,1,1,1,1,1,0,0,0},
{1,1,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0},
{1,1,1,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0},
{1,1,1,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0},
{1,1,1,0,0,0,0,0,0,0,1,0,0,1,1,1,1,0,0,0},
{1,1,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,0,0,0},
{1,1,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,0,0,0},
{1,1,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,0,0,0},
{1,1,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,0,0,0},
{1,1,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,0,0,0},
{1,1,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0,0},
{1,1,1,0,0,0,0,0,0,0,0,1,0,0,1,1,1,0,0,0},
{1,1,1,0,0,0,0,1,0,0,0,0,0,0,1,1,1,0,0,0},
{1,1,1,0,0,0,0,1,1,1,0,0,0,0,1,1,1,0,0,0},
{1,1,0,0,0,0,1,1,1,1,0,0,0,0,1,1,1,0,0,0},
{1,1,1,0,0,1,1,1,1,1,1,1,0,0,1,1,1,0,0,0},
{1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0},
{1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0}}
end

