-- ***********************
-- Grace utility functions
-- ***********************
-- Sean McPhail, 2010
-- smc10028@gmail.com


function GetClosestOfPair(this_unit,first_unit,first_unit_dist,second_unit,second_unit_dist)
-- return the closest of a pair of units
if first_unit==nil and second_unit==nil then
   return nil,nil
elseif second_unit==nil then
   return first_unit,first_unit_dist
elseif first_unit==nil then
   return second_unit,second_unit_dist
elseif first_unit_dist<second_unit_dist then
      return first_unit,first_unit_dist
elseif first_unit_dist>=second_unit_dist then
      return second_unit,second_unit_dist
end

end


function pairsByKeys (t,f)
-- function from "Programming in Lua", R Ierusalimschy
local a = {}
for n in pairs(t) do a[#a+1] = n end
table.sort(a,f)
local i=0 -- iterator variable
return function () -- iterator function
i=i+1
return a[i], t[a[i]]
end
end


function GetClosestUnits(this_unit)
-- return a table of the closest units to this_unit

local distance
local unit_distance={}
local unit_type_list={"AirBase","BattleShip","Bomber","Carrier","Fighter","RadarStation","Silo","Sub"}

unit_distance[grace_team_id]={}
unit_distance[enemy_team_id]={}

unit_distance[grace_team_id]["unit"]={["AirBase"]=nil,["BattleShip"]=nil,["Bomber"]=nil,["Carrier"]=nil,["Fighter"]=nil,["Nuke"]=nil,["RadarStation"]=nil,["Silo"]=nil,["Sub"]=nil}
unit_distance[enemy_team_id]["unit"]={["AirBase"]=nil,["BattleShip"]=nil,["Bomber"]=nil,["Carrier"]=nil,["Fighter"]=nil,["Nuke"]=nil,["RadarStation"]=nil,["Silo"]=nil,["Sub"]=nil}

unit_distance[grace_team_id]["dist"]={["AirBase"]=1000,["BattleShip"]=1000,["Bomber"]=1000,["Carrier"]=1000,["Fighter"]=1000,["Nuke"]=1000,["RadarStation"]=1000,["Silo"]=1000,["Sub"]=1000}
unit_distance[enemy_team_id]["dist"]={["AirBase"]=1000,["BattleShip"]=1000,["Bomber"]=1000,["Carrier"]=1000,["Fighter"]=1000,["Nuke"]=1000,["RadarStation"]=1000,["Silo"]=1000,["Sub"]=1000}

-- loop over all units comparing distances and save minimum distance unit into unit_distance
   for unit_id,data in pairs(UNIT_DATA) do
      distance=(math.sqrt((UNIT_DATA[this_unit]["longitude"]-data.longitude)^2+(UNIT_DATA[this_unit]["latitude"]-data.latitude)^2))

      if (unit_distance[data.team]["dist"][data.type]>distance and unit_id~=this_unit) then
         unit_distance[data.team]["dist"][data.type]=distance
    	 unit_distance[data.team]["unit"][data.type]=unit_id
      end
   end

-- *** Return units distances ***
return unit_distance

end




function CreateTaskGroup(TG_number,TG_task,TG_units,TG_state,TG_long,TG_lat,TG_parent,TG_data)

-- if first parameter nil then loop over task groups to find an empty task group slot, otherwise use it
if TG_number==nil then
   TG_number=4
   repeat 
      TG_number=TG_number+1
   until TASK_GROUP[TG_number]==nil
end

print("Task Group ",TG_number," created")

local this_task_group={}
this_task_group["number"]=TG_number
this_task_group["task"]=TG_task
this_task_group["units"]=TG_units
this_task_group["state"]=TG_state
this_task_group["target_long"]=TG_long
this_task_group["target_lat"]=TG_lat
this_task_group["priority"]=0
this_task_group["do_or_die"]=0
this_task_group["centre_long"]=0
this_task_group["centre_lat"]=0
this_task_group["map"]={}
this_task_group["parent"]=TG_parent
this_task_group["children"]={}
this_task_group["data"]=TG_data

-- table of lat and long
-- table of target cities
-- table of target units
-- target time point
-- parent taskgroup
-- table of child taskgroups

-- assign to global variable
TASK_GROUP[TG_number]=this_task_group
-- return task group number 
return(TG_number)

end


function CreateMap()
-- create a new heat map populated with zeros
local i,j
local new_map={}

for i=1,LONG_SQS do
new_map[i]={}
   for j=1,LAT_SQS do
         new_map[i][j]=0
   end
end
return new_map
end


function VectorNormalise(x,y)
--return a vector pointing in same direction as the input, but length 1
local length=math.sqrt(x^2+y^2)
return x/length,y/length
end


function VectorScale(x,y,scale)
--return a vector pointing in the same direction as the input, but scaled by the "scale" parameter
return x*scale,y*scale
end


function LongLatToMapCoord(long,lat)
--return the 36 by 20 heat map cell x and y co-ordinates that the Long-Lat co-ordinate is in 
return math.ceil((180+long)/10), math.ceil((100-lat)/10) 
end


function MapCoordToLongLat(x,y)
--return the Long and Lat of the centre-point of the specified 36 by 20 heat map cell 
return (x*10)-185,105-y*10
end


function ThresholdMap(this_map, threshold)
-- if a cell in input map is > threshold, return a 1 in that cell, otherwise return a 0
local i,j
local new_map=CreateMap()

for i=1,LONG_SQS do
   for j=1,LAT_SQS do

      if this_map[i][j]>=threshold then
         new_map[i][j]=1
      else
         new_map[i][j]=0
      end

   end
end

return(new_map)
end


function InverseMap(this_map)
-- return 1- the contents of each cell

local i,j
local new_map=CreateMap()

for i=1,LONG_SQS do
   for j=1,LAT_SQS do

         new_map[i][j]=1-this_map[i][j]
   end
end

return(new_map)
end



function CentreOfMassMap(this_map)
-- Calculate a centre of mass (in heat map co-ordinates) of the input heat map
local CoM_x,CoM_y,total,i,j
CoM_x=0
CoM_y=0
total=0

for i=1,LONG_SQS do
   for j=1,LAT_SQS do

      CoM_x=CoM_x+i*this_map[i][j]
      CoM_y=CoM_y+j*this_map[i][j]
      total = total+this_map[i][j]
   end
end

return CoM_x/total,CoM_y/total
end



function GenerateUnitMap(these_units)
-- take a list of unit ids, look up them up on the global unit_table, and count them onto a heat map

--generate new heatmap
local new_map=CreateMap()
local i,j

--loop over units
for count,id in pairs(these_units) do
   i,j=LongLatToMapCoord(UNIT_DATA[id]["longitude"],UNIT_DATA[id]["latitude"])
   new_map[i][j]=new_map[i][j]+1
end

return(new_map)
end


function TotalMap(this_map)
--[[
Function adds up all cells of map and returns that count.
]]
local total=0
local i,j

for i=1,LONG_SQS do
   for j=1,LAT_SQS do

         total=total+this_map[i][j]

   end
end

return(total)
end


function MultiplyMaps(this_map,that_map)
--[[
Function takes two heat maps and returns a single map which is the cell-by-cell
multiple of the two.
]]
local new_map=CreateMap()
local i,j

for i=1,LONG_SQS do
   for j=1,LAT_SQS do
         new_map[i][j]=this_map[i][j]*that_map[i][j]
   end
end

return(new_map)
end


function SumMaps(this_map, that_map)
-- take two maps and return the cell-by-cell summation
local i,j
local new_map=CreateMap()

for i=1,LONG_SQS do
   for j=1,LAT_SQS do
         new_map[i][j]=this_map[i][j]+that_map[i][j]
   end
end

return(new_map)
end


function DiffuseMap(this_map,diff_mag)
--[[
Function takes a map and a real constant between 0.0 and 1.0. It returns a map which has added to each cell the contents of each horizontally and vertically adjacent cell multiplied by the constant, diagnonal cells muliplied by half the constant. The cell is reduced by 0.6* the constant - i.e. total count is preserved

** This function does not correctly deal with the seam **
]]


-- define new map to work with

local new_map=CreateMap()
local i,j
local diff_sum=0


-- loop over map testing each adjacent cell and adding appropriate count to running total
for i=1,LONG_SQS do
   for j=1,LAT_SQS do
   diff_sum=0
      if i-1>0 and j-1>0 then
         new_map[i-1][j-1]=new_map[i-1][j-1]+this_map[i][j]*diff_mag/2
         diff_sum=diff_sum+diff_mag/2
      end

      if i-1>0 then
         new_map[i-1][j]=new_map[i-1][j]+this_map[i][j]*diff_mag
         diff_sum=diff_sum+diff_mag
      end

      if i-1>0 and j+1<LAT_SQS+1 then
         new_map[i-1][j+1]=new_map[i-1][j+1]+this_map[i][j]*diff_mag/2
         diff_sum=diff_sum+diff_mag/2
      end

      if j-1>0 then
         new_map[i][j-1]=new_map[i][j-1]+this_map[i][j]*diff_mag
         diff_sum=diff_sum+diff_mag/2
      end

      if j+1<LAT_SQS+1 then
         new_map[i][j+1]=new_map[i][j+1]+this_map[i][j]*diff_mag
         diff_sum=diff_sum+diff_mag/2
      end


      if i+1<LONG_SQS+1 and j-1>0 then
         new_map[i+1][j-1]=new_map[i+1][j-1]+this_map[i][j]*diff_mag/2
         diff_sum=diff_sum+diff_mag/2
      end

      if i+1<LONG_SQS+1 then
         new_map[i+1][j]=new_map[i+1][j]+this_map[i][j]*diff_mag
         diff_sum=diff_sum+diff_mag
      end

      if i+1<LONG_SQS+1 and j+1<LAT_SQS+1 then
         new_map[i+1][j+1]=new_map[i+1][j+1]+this_map[i][j]*diff_mag/2
         diff_sum=diff_sum+diff_mag/2
      end

      new_map[i][j]=new_map[i][j]+this_map[i][j]-diff_sum

   end
end

return(new_map)
end


function PrintMap(this_map)
-- print map line by line (looks rubbish unless map is integers <10)

local this_line=""
local i,j
for i=1,LAT_SQS do
   for j=1,LONG_SQS do
      this_line=this_line .. this_map[j][i]
   end

   print(this_line)
   this_line=""
end
end


function MaxMap(this_map)
-- return the maximum positive value in the map, and the x and y values of the max square
local this_value=0
local i,j,this_x,this_y

this_x=1
this_y=1

for i=1,LONG_SQS do
   for j=1,LAT_SQS do

      if this_map[i][j]>this_value then
         this_value=this_map[i][j]
         this_x=i
         this_y=j
      end

   end
end
return this_value,this_x,this_y
end


function ScaleMap(this_map, scale)
-- multiply map by a constant scale factor
local i,j
local new_map=CreateMap()

for i=1,LONG_SQS do
   for j=1,LAT_SQS do
         new_map[i][j]=this_map[i][j]*scale
   end
end

return(new_map)
end


function RandomMap(max_rand)
--return a map populated with random values between 0 and input parameter
local i,j
local new_map={}

for i=1,LONG_SQS do
new_map[i]={}

   for j=1,LAT_SQS do
         new_map[i][j]=math.random(max_rand)
   end
end

return(new_map)
end



function FloorMap(this_map)
-- return the input map with each cell having had a floor operation applied to it
local i,j

for i=1,LONG_SQS do
   for j=1,LAT_SQS do
         this_map[i][j]=math.floor(this_map[i][j])
   end
end
return(this_map)
end


function CeilMap(this_map)
-- return the input map with each cell having had a ceil operation applied to it
local i,j

for i=1,LONG_SQS do
   for j=1,LAT_SQS do
         this_map[i][j]=math.ceil(this_map[i][j])
   end
end
return(this_map)
end


function BoundMap(this_map)
--[[ take the input map and return a map which has the input values in cells which are adjacent to  
a zero, and zero in cells which were not - i.e. it finds a boundary

This function correctly deals with the seam
]]


local new_map=CreateMap()
local i,j


for i=1,LONG_SQS do
   for j=1,LAT_SQS do

      if j-1>0 then

         if i-1>0 then
            if this_map[i-1][j-1] == 0 then
               new_map[i][j]=1
            end
         else
            if this_map[LONG_SQS][j-1] == 0 then
               new_map[i][j]=1
            end
	 end
      end

      if i-1>0 then
         if this_map[i-1][j] == 0 then
            new_map[i][j]=1
         end
      else
         if this_map[LONG_SQS][j] == 0 then
            new_map[i][j]=1
         end
      end

      if i-1>0 and j+1<LAT_SQS+1 then
         if this_map[i-1][j+1] == 0 then
            new_map[i][j]=1
         end
      else
         if this_map[LONG_SQS][j+1] == 0 then
            new_map[i][j]=1
         end
 
       end

      if j-1>0 then
         if this_map[i][j-1] == 0 then
            new_map[i][j]=1
         end
               
       end

      if j+1<LAT_SQS+1 then
         if this_map[i][j+1] == 0 then
            new_map[i][j]=1
         end 
      end

      if j-1>0 then
         if i+1<LONG_SQS+1 then
            if this_map[i+1][j-1] == 0 then
               new_map[i][j]=1
            end
         else
            if this_map[1][j-1] == 0 then
               new_map[i][j]=1
            end
         end
      end

      if i+1<LONG_SQS+1 then
         if this_map[i+1][j] == 0 then
            new_map[i][j]=1
         end
      else
         if this_map[1][j] == 0 then
            new_map[i][j]=1
         end
      end

      if j+1<LAT_SQS+1 then
         if i+1<LONG_SQS+1 then
            if this_map[i+1][j+1] == 0 then
               new_map[i][j]=1
            end
         else
            if this_map[1][j+1] == 0 then
               new_map[i][j]=1
            end
         end
      end

      
      if new_map[i][j]~=0 and this_map[i][j]~=0 then
         new_map[i][j]=1
      else
         new_map[i][j]=0
      end


   end
end

return(new_map)
end



function GrowMap(this_map)
--[[ take the input map and return a map which has the input values in cells which are adjacent to  
a zero, and 1 in cells with value zero which were adjacent to cells which did not - i.e. it finds grows the non-zero
area of a map by one cell in each direction 

This function correctly deals with the seam.

]]

local new_map=CreateMap()
local i,j

-- loop over all cells for 
for i=1,LONG_SQS do
   for j=1,LAT_SQS do

--test each adjacent square
      if j-1>0 then
         if i-1>0 then
            if this_map[i-1][j-1] ~= 0 then
               new_map[i][j]=1
            end
         else
            if this_map[LONG_SQS][j-1] ~= 0 then
               new_map[i][j]=1
            end
	 end
      end

      if i-1>0 then
         if this_map[i-1][j] ~= 0 then
            new_map[i][j]=1
         end
      else
         if this_map[LONG_SQS][j] ~= 0 then
            new_map[i][j]=1
         end
      end

      if j+1<LAT_SQS+1 then
         if i-1>0 then
            if this_map[i-1][j+1] ~= 0 then
               new_map[i][j]=1
            end
         else
            if this_map[LONG_SQS][j+1] ~= 0 then
               new_map[i][j]=1
            end
         end
      end

      if j-1>0 then
         if this_map[i][j-1] ~= 0 then
            new_map[i][j]=1
         end         
      end

      if j+1<LAT_SQS+1 then
         if this_map[i][j+1] ~= 0 then
            new_map[i][j]=1
         end 
      end

      if j-1>0 then
         if i+1<LONG_SQS+1 then
            if this_map[i+1][j-1] ~= 0 then
               new_map[i][j]=1
            end
         else
            if this_map[1][j-1] ~= 0 then
               new_map[i][j]=1
            end
         end
      end

      if i+1<LONG_SQS+1 then
         if this_map[i+1][j] ~= 0 then
            new_map[i][j]=1
         end
      else
         if this_map[1][j] ~= 0 then
            new_map[i][j]=1
         end
      end

      if j+1<LAT_SQS+1 then
         if i+1<LONG_SQS+1 then
            if this_map[i+1][j+1] ~= 0 then
               new_map[i][j]=1
            end
         else
            if this_map[1][j+1] ~= 0 then
               new_map[i][j]=1
            end
         end
      end

-- test centre square      
      if this_map[i][j]~= 0 then
         new_map[i][j]=1
      end

   end
end

return(new_map)
end

