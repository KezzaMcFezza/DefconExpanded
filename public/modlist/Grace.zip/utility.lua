-- ***********************
-- General utility functions
-- ***********************
-- Written by Peter Cawley?


-- Redefine print to write to the alliance chat channel
function print(...)
  local args = {...}
  local n = select('#', ...)
  local tostring = tostring
  local txt = {}
  for i = 1, n do
    if i ~= 1 then
      txt[#txt + 1] = " "
    end
    txt[#txt + 1] = tostring(args[i])
  end
  SendChat(table.concat(txt), "alliance")
end

-- Extra whiteboard functions
function DrawBadWhiteboardCircle(x, y, radius)
  local mrandom, msin, mcos, pi = math.random, math.sin, math.cos, math.pi
  local segments = mrandom(7, 14)
  local theta_step = pi * 2 / segments
  local sin, cos = msin(theta_step), mcos(theta_step)
  local irot = mrandom() * 2 * pi
  local dx = mcos(irot) * radius
  local dy = msin(irot) * radius
  for i = 1, segments + mrandom(2, segments - 2) do
    local nx = cos * dx - sin * dy + mrandom(-2, 2) / 10
    local ny = sin * dx + cos * dy + mrandom(-2, 2) / 10
    
    WhiteboardDraw(x + dx, y + dy, x + nx, y + ny)
    dx, dy = nx, ny
  end
end

function DrawGoodWhiteboardCircle(x, y, radius)
  local segments = 20
  local theta_step = math.pi * 2 / segments
  local sin, cos = math.sin(theta_step), math.cos(theta_step)
  local dx = radius
  local dy = 0
  for i = 1, segments do
    local nx = cos * dx - sin * dy
    local ny = sin * dx + cos * dy
    
    WhiteboardDraw(x + dx, y + dy, x + nx, y + ny)
    dx, dy = nx, ny
  end
end

-- Simple coroutine management functions
local co, pairs, assert = coroutine, pairs, assert
local long_tasks_in_progress = {}

function StartLongTask(f)
  long_tasks_in_progress[co.create(f)] = true
end

function WorkOnLongTasks(...)
  for c in pairs(long_tasks_in_progress) do
    if co.status(c) == "dead" then
      long_tasks_in_progress[c] = nil
    else
      assert(co.resume(c, ...))
    end
  end
end

YieldLongTask = co.yield
