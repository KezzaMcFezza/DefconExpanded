-- ***************************
-- Grace task group activities
-- ***************************
-- Sean McPhail, 2010
-- smc10028@gmail.com

function ActivityScout(this_task_group)--takes task group reference as argument
--Scout - minimal interpretation
local at_target_count=0
local unit_count=0

--loop over all units
for count, id in pairs(this_task_group["units"]) do
  unit_count=unit_count+1

--	atom.move toward target
   if AtomMove(id,this_task_group["target_long"],this_task_group["target_lat"],false)=="At target" then 
      at_target_count=at_target_count+1
   end

end

-- ******************************
-- return result
-- ******************************
if at_target_count==unit_count then 
   return "At target"
end


end




function ActivityFight(this_task_group)
--Fight activity - handles naval combat

local lat_vec_1, lat_vec_2, lat_vec_3, lat_vec_final
local long_vec_1, long_vec_2,long_vec_3, long_vec_final
local unit_distance

-- calculate enemy centre of mass
local e_CoM_long,e_CoM_lat=MapCoordToLongLat(CentreOfMassMap(MultiplyMaps(GrowMap(this_task_group["map"]),UNIT_MAPS[enemy_team_id]["Mobile"])))

-- calculate friendly centre of mass
local f_CoM_long,f_CoM_lat=MapCoordToLongLat(CentreOfMassMap(this_task_group["map"]))


--loop over all units
for count, id in pairs(this_task_group["units"]) do

-- zero movement vectors
   long_vec_1=0
   lat_vec_1=0 
   long_vec_2=0
   lat_vec_2=0
   long_vec_3=0
   lat_vec_3=0
   long_vec_final=0
   lat_vec_final=0

--get unit distances
   unit_distance=GetClosestUnits(id)

--bomber 
--sub


--carrier
   if UNIT_DATA[id]["type"]=="Carrier" then   
   
-- move rule #1 - Vector away from enemy ships

      if (unit_distance[enemy_team_id]["unit"]["BattleShip"]~=nil and unit_distance[enemy_team_id]["dist"]["BattleShip"]<15) then 

         long_vec_1=-UNIT_DATA[unit_distance[enemy_team_id]["unit"]["BattleShip"]]["longitude"]+UNIT_DATA[id]["longitude"]
         lat_vec_1=-UNIT_DATA[unit_distance[enemy_team_id]["unit"]["BattleShip"]]["latitude"]+UNIT_DATA[id]["latitude"]
         long_vec_1,lat_vec_1=VectorNormalise(long_vec_1,lat_vec_1)
	     long_vec_1,lat_vec_1=VectorScale(long_vec_1,lat_vec_1,3)

	  elseif (unit_distance[enemy_team_id]["unit"]["Carrier"]~=nil and unit_distance[enemy_team_id]["dist"]["Carrier"]<20) then
		 
         long_vec_1=-UNIT_DATA[unit_distance[enemy_team_id]["unit"]["Carrier"]]["longitude"]+UNIT_DATA[id]["longitude"]
         lat_vec_1=-UNIT_DATA[unit_distance[enemy_team_id]["unit"]["Carrier"]]["latitude"]+UNIT_DATA[id]["latitude"]
		 long_vec_1,lat_vec_1=VectorNormalise(long_vec_1,lat_vec_1)
		 long_vec_1,lat_vec_1=VectorScale(long_vec_1,lat_vec_1,3)
      end
		 


-- move rule #2 - Vector away from closest friendly ship
      if (unit_distance[grace_team_id]["unit"]["Carrier"]~=nil and unit_distance[grace_team_id]["dist"]["Carrier"]<10) or (unit_distance[grace_team_id]["unit"]["BattleShip"]~=nil and unit_distance[grace_team_id]["dist"]["BattleShip"]<10) then

         if (unit_distance[grace_team_id]["unit"]["BattleShip"]~=nil and unit_distance[grace_team_id]["dist"]["BattleShip"]<10 and unit_distance[grace_team_id]["dist"]["BattleShip"]<unit_distance[grace_team_id]["dist"]["Carrier"]) then 
            long_vec_2=-(UNIT_DATA[unit_distance[grace_team_id]["unit"]["BattleShip"]]["longitude"]-UNIT_DATA[id]["longitude"])
            lat_vec_2=-(UNIT_DATA[unit_distance[grace_team_id]["unit"]["BattleShip"]]["latitude"]-UNIT_DATA[id]["latitude"])
            long_vec_2,lat_vec_2=VectorNormalise(long_vec_2,lat_vec_2)
			long_vec_2,lat_vec_2=VectorScale(long_vec_2,lat_vec_2,6*(1/math.sqrt(0.1+(UNIT_DATA[unit_distance[grace_team_id]["unit"]["BattleShip"]]["latitude"]-UNIT_DATA[id]["latitude"])^2+(UNIT_DATA[unit_distance[grace_team_id]["unit"]["BattleShip"]]["longitude"]-UNIT_DATA[id]["longitude"])^2)))

		 elseif (unit_distance[grace_team_id]["unit"]["Carrier"]~=nil and unit_distance[grace_team_id]["dist"]["Carrier"]<10 and unit_distance[grace_team_id]["dist"]["Carrier"]<unit_distance[grace_team_id]["dist"]["BattleShip"]) then
		    long_vec_2=-(UNIT_DATA[unit_distance[grace_team_id]["unit"]["Carrier"]]["longitude"]-UNIT_DATA[id]["longitude"])
            lat_vec_2=-(UNIT_DATA[unit_distance[grace_team_id]["unit"]["Carrier"]]["latitude"]-UNIT_DATA[id]["latitude"])
            long_vec_2,lat_vec_2=VectorNormalise(long_vec_2,lat_vec_2)
			long_vec_2,lat_vec_2=VectorScale(long_vec_2,lat_vec_2,6*(1/math.sqrt(0.1+(UNIT_DATA[unit_distance[grace_team_id]["unit"]["Carrier"]]["latitude"]-UNIT_DATA[id]["latitude"])^2+(UNIT_DATA[unit_distance[grace_team_id]["unit"]["Carrier"]]["longitude"]-UNIT_DATA[id]["longitude"])^2)))
         end
		 
      end

-- move rule #3 - Vector toward friendly CoM
      long_vec_3=(f_CoM_long-UNIT_DATA[id]["longitude"])
	  lat_vec_3=(f_CoM_lat-UNIT_DATA[id]["latitude"])
      long_vec_3,lat_vec_3=VectorNormalise(long_vec_3,lat_vec_3)
      long_vec_3,lat_vec_3=VectorScale(long_vec_3,lat_vec_3,0.5)

			
-- final vector
	  long_vec_final,lat_vec_final=VectorNormalise(long_vec_1+long_vec_2+long_vec_3,lat_vec_1+lat_vec_2+lat_vec_3)
	  long_vec_final,lat_vec_final=VectorScale(long_vec_final,lat_vec_final,2)

-- give move order 
      AtomMove(id,UNIT_DATA[id]["longitude"]+long_vec_final,UNIT_DATA[id]["latitude"]+lat_vec_final,true)

   end

   
--Battleship
   if UNIT_DATA[id]["type"]=="BattleShip" then
   
-- move rule #1 - Vector towards 10% point of carriers and enemy ships
      if (unit_distance[grace_team_id]["unit"]["Carrier"]~=nil and unit_distance[grace_team_id]["dist"]["Carrier"]<30) then

         if (unit_distance[enemy_team_id]["unit"]["BattleShip"]~=nil and unit_distance[enemy_team_id]["dist"]["BattleShip"]<30) then 
            long_vec_1=(0.9*UNIT_DATA[unit_distance[grace_team_id]["unit"]["Carrier"]]["longitude"]+0.1*UNIT_DATA[unit_distance[enemy_team_id]["unit"]["BattleShip"]]["longitude"])-UNIT_DATA[id]["longitude"]
            lat_vec_1=(0.9*UNIT_DATA[unit_distance[grace_team_id]["unit"]["Carrier"]]["latitude"]+0.1*UNIT_DATA[unit_distance[enemy_team_id]["unit"]["BattleShip"]]["latitude"])-UNIT_DATA[id]["latitude"]
            long_vec_1,lat_vec_1=VectorNormalise(long_vec_1,lat_vec_1)
			long_vec_1,lat_vec_1=VectorScale(long_vec_1,lat_vec_1,3)
		 elseif (unit_distance[enemy_team_id]["unit"]["Carrier"]~=nil and unit_distance[enemy_team_id]["dist"]["Carrier"]<30) then
		 
		    long_vec_1=(0.9*UNIT_DATA[unit_distance[grace_team_id]["unit"]["Carrier"]]["longitude"]+0.1*UNIT_DATA[unit_distance[enemy_team_id]["unit"]["Carrier"]]["longitude"])-UNIT_DATA[id]["longitude"]
            lat_vec_1=(0.9*UNIT_DATA[unit_distance[grace_team_id]["unit"]["Carrier"]]["latitude"]+0.1*UNIT_DATA[unit_distance[enemy_team_id]["unit"]["Carrier"]]["latitude"])-UNIT_DATA[id]["latitude"]
            long_vec_1,lat_vec_1=VectorNormalise(long_vec_1,lat_vec_1)
			long_vec_1,lat_vec_1=VectorScale(long_vec_1,lat_vec_1,3)
		 end
		 
      end

-- move rule #2 - Vector away from closest friendly ship
      if (unit_distance[grace_team_id]["unit"]["Carrier"]~=nil and unit_distance[grace_team_id]["dist"]["Carrier"]<10) or (unit_distance[grace_team_id]["unit"]["BattleShip"]~=nil and unit_distance[grace_team_id]["dist"]["BattleShip"]<10) then

         if (unit_distance[grace_team_id]["unit"]["BattleShip"]~=nil and unit_distance[grace_team_id]["dist"]["BattleShip"]<10 and unit_distance[grace_team_id]["dist"]["BattleShip"]<unit_distance[grace_team_id]["dist"]["Carrier"]) then 
            long_vec_2=-(UNIT_DATA[unit_distance[grace_team_id]["unit"]["BattleShip"]]["longitude"]-UNIT_DATA[id]["longitude"])
            lat_vec_2=-(UNIT_DATA[unit_distance[grace_team_id]["unit"]["BattleShip"]]["latitude"]-UNIT_DATA[id]["latitude"])
            long_vec_2,lat_vec_2=VectorNormalise(long_vec_2,lat_vec_2)
			long_vec_2,lat_vec_2=VectorScale(long_vec_2,lat_vec_2,6*(1/math.sqrt(0.1+(UNIT_DATA[unit_distance[grace_team_id]["unit"]["BattleShip"]]["latitude"]-UNIT_DATA[id]["latitude"])^2+(UNIT_DATA[unit_distance[grace_team_id]["unit"]["BattleShip"]]["longitude"]-UNIT_DATA[id]["longitude"])^2)))
		 elseif (unit_distance[grace_team_id]["unit"]["Carrier"]~=nil and unit_distance[grace_team_id]["dist"]["Carrier"]<10 and unit_distance[grace_team_id]["dist"]["Carrier"]<unit_distance[grace_team_id]["dist"]["BattleShip"]) then
		    long_vec_2=-(UNIT_DATA[unit_distance[grace_team_id]["unit"]["Carrier"]]["longitude"]-UNIT_DATA[id]["longitude"])
            lat_vec_2=-(UNIT_DATA[unit_distance[grace_team_id]["unit"]["Carrier"]]["latitude"]-UNIT_DATA[id]["latitude"])
            long_vec_2,lat_vec_2=VectorNormalise(long_vec_2,lat_vec_2)
			long_vec_2,lat_vec_2=VectorScale(long_vec_2,lat_vec_2,6*(1/math.sqrt(0.1+(UNIT_DATA[unit_distance[grace_team_id]["unit"]["Carrier"]]["latitude"]-UNIT_DATA[id]["latitude"])^2+(UNIT_DATA[unit_distance[grace_team_id]["unit"]["Carrier"]]["longitude"]-UNIT_DATA[id]["longitude"])^2)))
        end
		 
      end

-- move rule #3 - Vector toward enemy CoM
      long_vec_3=(e_CoM_long-UNIT_DATA[id]["longitude"])
      lat_vec_3=(e_CoM_lat-UNIT_DATA[id]["latitude"])

      long_vec_3,lat_vec_3=VectorNormalise(long_vec_3,lat_vec_3)
      long_vec_3,lat_vec_3=VectorScale(long_vec_3,lat_vec_3,1)
	

-- final vector
	  long_vec_final,lat_vec_final=VectorNormalise(long_vec_1+long_vec_2+long_vec_3,lat_vec_1+lat_vec_2+lat_vec_3)
	  long_vec_final,lat_vec_final=VectorScale(long_vec_final,lat_vec_final,2)

			
-- do move
      AtomMove(id,UNIT_DATA[id]["longitude"]+long_vec_final,UNIT_DATA[id]["latitude"]+lat_vec_final,true)

   end
   
end
end


function ActivityIdle(this_task_group)
--
end


function ActivityMove(this_task_group)
--Move
end

function ActivityTAD(this_task_group)

-- count friendly and enemy planes
local enemy_fighters= TotalMap(MultiplyMaps(GrowMap(MAP[k.territory]),UNIT_MAPS[enemy_team_id]["Fighter"]))
local enemy_bombers=TotalMap(MultiplyMaps(GrowMap(MAP[k.territory]),UNIT_MAPS[enemy_team_id]["Bomber"]))
local enemy_subs=TotalMap(MultiplyMaps(GrowMap(MAP[k.territory]),UNIT_MAPS[enemy_team_id]["Sub"]))

local grace_fighters=TotalMap(MultiplyMaps(GrowMap(MAP[k.territory]),UNIT_MAPS[grace_team_id]["Fighter"]))
local grace_airbases=0

-- setup a table of nearby units for each airbase (to avoid multiple computation)
local close_units={}
-- and the distance and closest unit for each airbase
local min_unit_distance={}
local min_unit_id={}
local min_distance_airbase={}
local launching_bases=0

local count=0
--loop over all airbases to count them and get closest units
for _, id in pairs(this_task_group["units"]) do
   if UNIT_DATA[id]["type"]=="AirBase" then
      grace_airbases=grace_airbases+1
      close_units[id]=GetClosestUnits(id)
      
-- only launch from one base
      if (GetStateTimer(id)>0 and GetCurrentState(id)==0) then 
         launching_bases=launching_bases+1
      end

  -- find closest fighter, bomber or sub
      min_unit_id[id],min_unit_distance[id]=GetClosestOfPair(id,close_units[id][enemy_team_id]["unit"]["Fighter"],close_units[id][enemy_team_id]["dist"]["Fighter"],close_units[id][enemy_team_id]["unit"]["Bomber"],close_units[id][enemy_team_id]["dist"]["Bomber"])
      min_unit_id[id],min_unit_distance[id]=GetClosestOfPair(id,min_unit_id[id],min_unit_distance[id],close_units[id][enemy_team_id]["unit"]["Sub"],close_units[id][enemy_team_id]["dist"]["Sub"])

   -- if none to be found insert dummy value to allow ordering of airbases
      if min_unit_id[id]==nil then
         min_distance_airbase[1000+grace_airbases]=id
      else
	     min_distance_airbase[math.ceil(1000*min_unit_distance[id])]=id
      end
   end
   
end

local active_bases=enemy_fighters+enemy_bombers+2*enemy_subs-grace_fighters-launching_bases


--loop over all units by order of distance using pairsByKeys
for count, id in pairsByKeys(min_distance_airbase) do
--
   if UNIT_DATA[id]["type"]=="AirBase" then
--if need to launch defensive fighters and have fighters launch them
      if active_bases>0 and GetStateCount(id,0)>0 then
-- if in action and not already launching
         if GAME_TIME>EXTRA_UNIT_DATA[id]["time"] and GetStateTimer(id)<1 then 
            SetState(id,0)   


            SetActionTarget(id,nil,UNIT_DATA[min_unit_id[id]]["longitude"],UNIT_DATA[min_unit_id[id]]["latitude"])

            EXTRA_UNIT_DATA[id]["time"]=GAME_TIME+150
-- set fighter to intercept mode and create new task group
            EXTRA_UNIT_DATA[id]["data"]["fighter TG"]=CreateTaskGroup(nil,"Intercept",{},"Fighter Intercept",0.7*UNIT_DATA[id]["longitude"]+0.3*UNIT_DATA[min_unit_id[id]]["longitude"],0.7*UNIT_DATA[id]["latitude"]+0.3*UNIT_DATA[min_unit_id[id]]["latitude"],nil,"",{})
--            SetActionTarget(id,min_unit_id[id])
            active_bases=active_bases-1

         end
      else
-- no more active defense airbases needed - can now consider whether to launch planes for maintenance
-- if airbase has recovered
         if GAME_TIME>EXTRA_UNIT_DATA[id]["time"] then
--do maintenance tasks - pick a random Atom from those in the task group data field
            local atom_to_do=this_task_group["data"]["atoms"][math.random(#this_task_group["data"]["atoms"])]
--print(atom_to_do)

            if atom_to_do=="AtomAirbaseWait" then
               AtomAirbaseWait()
            elseif atom_to_do == "AtomScoutFighter" then
               AtomScoutFighter(this_task_group,id)
            elseif atom_to_do == "AtomSendFighter" then
               AtomScoutFighter(this_task_group,id)
            elseif atom_to_do == "AtomMusterBombers"then
               AtomMusterBombers(this_task_group,id)
            elseif atom_to_do == "AtomEqualiseFighters" then
               AtomEqualiseFighters(this_task_group,id)
            elseif atom_to_do == "AtomEqualiseBombers" then
               AtomEqualiseBombers(this_task_group,id)
            elseif atom_to_do == "AtomSupplyFightersToCarriers" then
               AtomSupplyFightersToCarriers(this_task_group,id,close_units[id])
            elseif atom_to_go == "AtomSupplyBombersToCarriers" then
               AtomSupplyBombersToCarriers()
            end
         end
      end
   end
end
end


function ActivityFighterIntercept(this_task_group)
-- loop over all units in task group
-- not already attacking and enemy within 20 then reset movement target to force re-targeting

for _, id in pairs(this_task_group["units"]) do
   local close_units=GetClosestUnits(id)
   
   if close_units[enemy_team_id]["dist"]["Sub"]<20 or close_units[enemy_team_id]["dist"]["Fighter"]<20 or close_units[enemy_team_id]["dist"]["Bomber"]<20 or close_units[enemy_team_id]["dist"]["Carrier"]<20 or close_units[enemy_team_id]["dist"]["BattleShip"]<20 then

-- avoid doing it every tick - screws up fighter movement
      if GetCurrentTargetID(id)==nil and GAME_TIME>EXTRA_UNIT_DATA[id]["time"] then
         EXTRA_UNIT_DATA[id]["time"]=GAME_TIME+5
--otherwise get closest units
         SetMovementTarget(id,UNIT_DATA[id]["longitude"],UNIT_DATA[id]["latitude"])
      end
   end

end
end


function ActivityLandFighter(this_task_group)
-- no need for any functionality here yet - landing is set at launch time
end


