-------------------------------------------------------------------------------
-- @author Ciar�n Eaton
-- @copyright 2010 Ciar�n Eaton
--
-- @release draw.lua, v1.1
--
-- <p>Permission is hereby granted, free of charge, to any person
-- obtaining a copy of this software and associated documentation
-- files (the "Software"), to deal in the Software without
-- restriction, including without limitation the rights to use,
-- copy, modify, merge, publish, distribute, sublicense, and/or sell
-- copies of the Software, and to permit persons to whom the
-- Software is furnished to do so, subject to the following
-- conditions:</p>
-- 
-- <p>The above copyright notice and this permission notice shall be
-- included in all copies or substantial portions of the Software.</p>
-- 
-- <p>THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
-- EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
-- OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
-- NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
-- HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
-- WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
-- FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
-- OTHER DEALINGS IN THE SOFTWARE.</p>
-------------------------------------------------------------------------------


require "utility"

-------------------------------------------------------------------------------
-- Draw is a Lua library developed to complement the Whiteboard
-- capability provided in the Defcon AI API.
-------------------------------------------------------------------------------
module ("draw", package.seeall)


-------------------------------------------------------------------------------
-- Draw version number.
-------------------------------------------------------------------------------
_COPYRIGHT = "Copyright (c) 2010 Ciar�n Eaton"
_DESCRIPTION = "Drawing library for the Defcon AI API"
_NAME = "Draw"
_VERSION = "1.1.0"


-------------------------------------------------------------------------------
-- Default options.
-- @class table
-- @name default_options
-- @field yield_frequency Determines how many iterations of a loop should be 
-- executed before yielding. Set to -1 to never yield in a loop.
-- @field arrow_head_ratio Ratio of arrow head compared to its length.
-- @field arrow_head_angle Determines how pointy arrow is in radians.
-- @field circle_segments Numbers of segments to draw for a circle. Minimum 5.
-- @field semicircle_segments Numbers of segments to draw for a semicircle. Minimum 5.
-------------------------------------------------------------------------------
local default_options = {
	yield_frequency = 15,
	arrow_head_ratio = 0.4,
	arrow_head_angle = 0.25,
	circle_segments = 10,
	semicircle_segments = 6
}


-------------------------------------------------------------------------------
-- Teapot data.
-- Data used to describe the points of the teapot
-- @class table
-- @name teapot_data
-- @see Teapot3f, Teapot4f, Teapot2v, Teapot3v
-------------------------------------------------------------------------------
local teapot_data = { {-0.5000,0.1050}, {-0.4142,0.1287}, {-0.3817,0.1139}, {-0.2544,-0.0222}, 
					{-0.2189,0.0518}, {-0.1834,0.0695}, {-0.1834,0.1287}, {-0.0828,0.1524}, 
					{-0.0237,0.1701}, {-0.0237,0.1849}, {-0.0473,0.2086}, {-0.0473,0.2382}, 
					{0.0118,0.2500}, {0.0621,0.2411}, {0.0680,0.2115}, {0.0503,0.1908}, 
					{0.0503,0.1760}, {0.1065,0.1494}, {0.2071,0.1317}, {0.2071,0.0814}, 
					{0.2426,0.0577}, {0.3432,0.1169}, {0.4142,0.1228}, {0.5000,-0.0340}, 
					{0.4645,-0.1435}, {0.2456,-0.2825}, {0.2012,-0.3180}, {0.1923,-0.3388}, 
					{-0.1598,-0.3417}, {-0.1598,-0.3240}, {-0.2278,-0.2589}, {-0.3136,-0.2086}, 
					{-0.3609,-0.1198}, {-0.4201,0.0370}, {-0.4941,0.0843}, {'b', 'b'}, 
					{0.3077,0.0311}, {0.3876,0.0754}, {0.4675,-0.0429}, {0.4112,-0.1287}, 
					{0.2870,-0.1908}
				}


------------------------------------------------------------------------------
-- Set yield frequency.
-- @see default_options
-------------------------------------------------------------------------------
function SetYieldFreq (freq)
	default_options.yield_frequency = freq
	return true
end


------------------------------------------------------------------------------
-- Set arrow head ratio.
-- @see default_options
-------------------------------------------------------------------------------
function SetArrowHeadRatio (ratio)
	default_options.arrow_head_ratio = ratio
	return true
end


------------------------------------------------------------------------------
-- Set arrow head angle.
-- @see default_options
-------------------------------------------------------------------------------
function SetArrowHeadAngle (angle)
	default_options.arrow_head_angle = angle
	return true
end


------------------------------------------------------------------------------
-- Set circle segments.
-- @see default_options
-------------------------------------------------------------------------------
function SetCircleSegments (segments)
	default_options.circle_segments = segments
	return true
end


------------------------------------------------------------------------------
-- Set semicircle segments.
-- @see default_options
-------------------------------------------------------------------------------
function SetSemiCircleSegments (segments)
	default_options.semicircle_segments = segments
	return true
end


-------------------------------------------------------------------------------
-- Clears the whiteboard.
-- @usage draw.Clear()
-------------------------------------------------------------------------------
function Clear ()
	WhiteboardClear()
	return true
end


-------------------------------------------------------------------------------
--- Draw an arrow pointing at a provided point.
-- @param x1 x-coord of arrow head.
-- @param y1 y-coord of arrow head.
-- @param length length of arrow from head to tail.
-- @param bearing bearing arrow should point.
-- @usage draw.ArrowAt4f(0.0,0.0,10.0,math.pi*0.25)
-- @see default_options
-- @see ArrowAt3v, ArrowFrom3v, ArrowFrom4f
-------------------------------------------------------------------------------
function ArrowAt4f (x1, y1, length, bearing)
	local head_ratio = default_options.arrow_head_ratio
	local head_angle = default_options.arrow_head_angle

	--arrow body
	local angle = math.pi + bearing
	local x2 = x1 + (math.sin(angle) * length)
	local y2 = y1 + (math.cos(angle) * length)
	WhiteboardDraw(x1, y1, x2, y2)

	--arrow head left
	angle = (math.pi * (1.0 - head_angle)) + bearing
	x2 = x1 + (math.sin(angle) * length * head_ratio)
	y2 = y1 + (math.cos(angle) * length * head_ratio)
	WhiteboardDraw(x1, y1, x2, y2)

	--arrow head right
	angle = (math.pi * (1.0 + head_angle)) + bearing
	x2 = x1 + (math.sin(angle) * length * head_ratio)
	y2 = y1 + (math.cos(angle) * length * head_ratio)
	WhiteboardDraw(x1, y1, x2, y2)
	
	return true
end


-------------------------------------------------------------------------------
--- Draw an arrow pointing at a provided point.
-- @param xy1 table with the x-y coords for arrow head
-- @param length length of arrow from head to tail.
-- @param bearing bearing arrow should point.
-- @usage draw.ArrowAt3v({0.0,0.0},10.0,math.pi*0.25)
-- @see default_options
-- @see ArrowAt4f, ArrowFrom3v, ArrowFrom4f
-------------------------------------------------------------------------------
function ArrowAt3v (xy1, length, bearing)
	ArrowAt4f (xy1[1], xy1[2], length, bearing)
	return true
end


-------------------------------------------------------------------------------
--- Draw an arrow pointing from a provided point.
-- @param x1 x-coord of arrow tail.
-- @param y1 y-coord of arrow tail.
-- @param length length of arrow from head to tail.
-- @param bearing bearing arrow should point.
-- @usage draw.ArrowFrom4f(15.0,0.0,10.0,math.pi*0.56)
-- @see default_options
-- @see ArrowAt3v, ArrowAt4f, ArrowFrom3v
-------------------------------------------------------------------------------
function ArrowFrom4f (x1, y1, length, bearing)
	local head_ratio = default_options.arrow_head_ratio
	local head_angle = default_options.arrow_head_angle

	--arrow body
	local angle = bearing
	local x2 = x1 + (math.sin(angle) * length)
	local y2 = y1 + (math.cos(angle) * length)
	WhiteboardDraw(x1, y1, x2, y2)

	--arrow head left
	x1 = x2
	y1 = y2
	angle = bearing - (head_angle * math.pi)
	x2 = x1 - (math.sin(angle) * length * head_ratio)
	y2 = y1 - (math.cos(angle) * length * head_ratio)
	WhiteboardDraw(x1, y1, x2, y2)

	--arrow head right
	angle = bearing + (head_angle * math.pi)
	x2 = x1 - (math.sin(angle) * length * head_ratio)
	y2 = y1 - (math.cos(angle) * length * head_ratio)
	WhiteboardDraw(x1, y1, x2, y2)
	
	return true
end


-------------------------------------------------------------------------------
--- Draw an arrow pointing from a provided point.
-- @param xy1 x-y coord for arrow tail
-- @param length length of arrow from head to tail.
-- @param bearing bearing arrow should point.
-- @usage draw.ArrowFrom3v({15.0,0.0},10.0,math.pi*0.56)
-- @see default_options
-- @see ArrowAt3v, ArrowAt4f, ArrowFrom4f
-------------------------------------------------------------------------------
function ArrowFrom3v (xy1, length, bearing)
	ArrowFrom4f (xy1[1], xy1[2], length, bearing)
	return true
end


-------------------------------------------------------------------------------
--- Draw a circle
-- Uses a set number of segments.
-- @param cx x-coord of centre.
-- @param cy y-coord of centre.
-- @param radius length from centre to edge.
-- @usage draw.Circle3f(0.0,10.0,5.0)
-- @see default_options
-- @see Circle2v, Circle3vi, Circle4fi
-------------------------------------------------------------------------------
function Circle3f (cx, cy, radius)
	local segments = default_options.circle_segments
	
	Circle4fi(cx, cy, radius, segments)
	return true
end


-------------------------------------------------------------------------------
--- Draw a circle
-- Uses a set number of segments.
-- @param cxy x-y coord of centre.
-- @param radius length from centre to edge.
-- @usage draw.Circle2v({0.0,10.0},5.0)
-- @see default_options
-- @see Circle3f, Circle3vi, Circle4fi
-------------------------------------------------------------------------------
function Circle2v (cxy, radius)
	local segments = default_options.circle_segments
	
	Circle4fi(cxy[1], cxy[2], radius, segments)
	return true
end


-------------------------------------------------------------------------------
--- Draw a circle
-- @param cx x-coord of centre.
-- @param cy y-coord of centre.
-- @param radius length from centre to edge.
-- @param segments number of segments to use.
-- @usage draw.Circle4fi(15.0,10.0,5.0,20)
-- @see Circle2v, Circle3f, Circle3vi
-------------------------------------------------------------------------------
function Circle4fi (cx, cy, radius, segments)
	
	-- enforce a minimum number of segments
	if (segments < 5) then
		segments = 5
	end

	local theta = math.pi * 2 / segments
	local sinv = math.sin(theta)
	local cosv = math.cos(theta)

	-- start values
	local dx = 0.0
	local dy = radius
	
	StartLongTask(function()
		for i=1, segments do
			local nx = cosv * dx - sinv * dy
			local ny = sinv * dx + cosv * dy

			WhiteboardDraw(cx+dx, cy+dy, cx+nx, cy+ny)

			dx = nx
			dy = ny
			
			-- yield frequency
			if (i % default_options.yield_frequency == 0) then
				YieldLongTask()
			end
		end
	end)
	return true
end


-------------------------------------------------------------------------------
--- Draw a circle
-- @param cxy x-y coord of centre.
-- @param radius length from centre to edge.
-- @param segments number of segments to use.
-- @usage draw.Circle3vi({15.0,10.0},5.0,20)
-- @see Circle2v, Circle3f, Circle4fi
-------------------------------------------------------------------------------
function Circle3vi (cxy, radius, segments)
	Circle4fi (cxy[1], cxy[2], radius, segments)
end


-------------------------------------------------------------------------------
--- Draw a cross
-- @param cx x-coord of centre.
-- @param cy y-coord of centre.
-- @param radius length from centre to edge.
-- @usage draw.Cross3f(0.0,25.0,5.0)
-- @see Cross2v, Cross3v, Cross4f
-------------------------------------------------------------------------------
function Cross3f (cx, cy, radius)
	WhiteboardDraw(cx-radius, cy+radius, cx+radius, cy-radius)
	WhiteboardDraw(cx-radius, cy-radius, cx+radius, cy+radius)
	return true
end


-------------------------------------------------------------------------------
--- Draw a cross
-- @param cxy x-y coord of centre.
-- @param radius length from centre to edge.
-- @usage draw.Cross2v({0.0,25.0},5.0)
-- @see Cross3f, Cross3v, Cross4f
-------------------------------------------------------------------------------
function Cross2v (cxy, radius)
	WhiteboardDraw(cxy[1]-radius, cxy[2]+radius, cxy[1]+radius, cxy[2]-radius)
	WhiteboardDraw(cxy[1]-radius, cxy[2]-radius, cxy[1]+radius, cxy[2]+radius)
	return true
end


-------------------------------------------------------------------------------
--- Draw a cross
-- @param cx x-coord of centre.
-- @param cy y-coord of centre.
-- @param radius length from centre to edge.
-- @param rotation amount to rotate in radians.
-- @usage draw.Cross4f(15.0,25.0,5.0,math.pi*0.5)
-- @see Cross2v, Cross3f, Cross3v
-------------------------------------------------------------------------------
function Cross4f (cx, cy, radius, rotation)
	local theta = (math.pi * 0.25) + rotation
	local sinv = math.sin(theta)
	local cosv = math.cos(theta)
	
	local nx = radius * cosv + radius * sinv
	local ny = radius * cosv - radius * sinv

	WhiteboardDraw(cx-nx, cy+ny, cx+nx, cy-ny)
	WhiteboardDraw(cx-ny, cy-nx, cx+ny, cy+nx)
	return true
end


-------------------------------------------------------------------------------
--- Draw a cross
-- @param cxy x-y coord of centre.
-- @param radius length from centre to edge.
-- @param rotation amount to rotate in radians.
-- @usage draw.Cross3v({15.0,25.0},5.0,math.pi*0.5)
-- @see Cross2v, Cross3f, Cross4f
-------------------------------------------------------------------------------
function Cross3v (cxy, radius, rotation)
	Cross4f (cxy[1], cxy[2], radius, rotation)
	return true
end


-------------------------------------------------------------------------------
--- Draw a line using a point and a bearing.
-- @param x1 x-coord of point.
-- @param y1 y-coord of point.
-- @param length length of line.
-- @param bearing bearing of line in radians.
-- @usage draw.LineB4f(0.0,40.0,5.0,math.pi*0.25)
-- @see LineB3v, LineH2v, LineH3f, LineP2v, LineP4f, LineV2v, LineV3f
-------------------------------------------------------------------------------
function LineB4f (x1, y1, length, bearing)
	local x2 = x1 + (math.sin(bearing) * length)
	local y2 = y1 + (math.cos(bearing) * length)
	
	WhiteboardDraw(x1, y1, x2, y2)
	return true
end


-------------------------------------------------------------------------------
--- Draw a line using a point and a bearing.
-- @param xy1 x-y coord for point.
-- @param length length of line.
-- @param bearing bearing of line in radians.
-- @usage draw.LineB3v({0.0,40.0},5.0,math.pi*0.25)
-- @see LineB4f, LineH2v, LineH3f, LineP2v, LineP4f, LineV2v, LineV3f
-------------------------------------------------------------------------------
function LineB3v (xy1, length, bearing)
	LineB4f(xy1[1], xy1[2], length, bearing)
	return true
end


-------------------------------------------------------------------------------
--- Draw a horizontal line from a point.
-- @param x1 x-coord of point.
-- @param y1 y-coord of point.
-- @param length length of line.
-- @usage draw.LineH3f(10.0,40.0,5.0)
-- @see LineB3v, LineB4f, LineH2v, LineP2v, LineP4f, LineV2v, LineV3f
-------------------------------------------------------------------------------
function LineH3f(x1, y1, length)
	WhiteboardDraw(x1, y1, x1+length, y1)
	return true
end


-------------------------------------------------------------------------------
--- Draw a horizontal line from a point.
-- @param xy1 x-y coord for point.
-- @param length length of line.
-- @usage draw.LineH2v({10.0,40.0},5.0)
-- @see LineB3v, LineB4f, LineH3f, LineP2v, LineP4f, LineV2v, LineV3f
-------------------------------------------------------------------------------
function LineH2v(xy1, length)
	WhiteboardDraw(xy1[1], xy1[2], xy1[1]+length, xy1[2])
	return true
end


-------------------------------------------------------------------------------
--- Draw a line using two points.
-- @param x1 x-coord of first point.
-- @param y1 y-coord of first point.
-- @param x2 x-coord of second point.
-- @param y2 y-coord of second point.
-- @usage draw.LineP4f(20.0,40.0,25.0,45.0)
-- @see LineB3v, LineB4f, LineH2v, LineH3f, LineP2v, LineV2v, LineV3f
-------------------------------------------------------------------------------
function LineP4f (x1, y1, x2, y2)
	WhiteboardDraw(x1, y1, x2, y2)
	return true
end


-------------------------------------------------------------------------------
--- Draw a line using two points.
-- @param xy1 x-y coord for first point.
-- @param xy2 x-y coord for second point.
-- @usage draw.LineP2v({20.0,40.0},{25.0,45.0})
-- @see LineB3v, LineB4f, LineH2v, LineH3f, LineP4f, LineV2v, LineV3f
-------------------------------------------------------------------------------
function LineP2v (xy1, xy2)
	WhiteboardDraw(xy1[1], xy1[2], xy2[1], xy2[2])
	return true
end


-------------------------------------------------------------------------------
--- Draw a vertical line from a point.
-- @param x1 x-coord of point.
-- @param y1 y-coord of point.
-- @param length length of line.
-- @usage draw.LineV3f(30.0,40.0,5.0)
-- @see LineB3v, LineB4f, LineH2v, LineH3f, LineP2v, LineP4f, LineV2v
-------------------------------------------------------------------------------
function LineV3f (x1, y1, length)
	WhiteboardDraw(x1, y1, x1, y1+length)
	return true
end


-------------------------------------------------------------------------------
--- Draw a vertical line from a point.
-- @param xy1 table of x-y coord for point.
-- @param length length of line.
-- @usage draw.LineV2v({30.0,40.0},5.0)
-- @see LineB3v, LineB4f, LineH2v, LineH3f, LineP2v, LineP4f, LineV3f
-------------------------------------------------------------------------------
function LineV2v (xy1, length)
	WhiteboardDraw(xy1[1], xy1[2], xy1[1], xy1[2]+length)
	return true
end


-------------------------------------------------------------------------------
--- Draw a semicircle.
-- Uses a set number of segments.
-- @param x1 x-coord for the mid-point along the straight edge.
-- @param y1 y-coord for the mid-point along the straight edge.
-- @param radius length from x1,y1 to curved edge.
-- @usage draw.SemiCircle3f(0.0,55.0,5.0)
-- @see default_options
-- @see SemiCircle2v, SemiCircle3v, SemiCircle4f, SemiCircle4vi, SemiCircle5fi
-------------------------------------------------------------------------------
function SemiCircle3f (x1, y1, radius)
	local segments = default_options.semicircle_segments
	
	SemiCircle5fi(x1, y1, radius, 0.0, segments)
	return true
end


-------------------------------------------------------------------------------
--- Draw a semicircle.
-- Uses a set number of segments.
-- @param xy1 table of x-y coord for the mid-point along the straight edge.
-- @param radius length from xy1 to curved edge.
-- @usage draw.SemiCircle2v({0.0,85.0},5.0)
-- @see default_options
-- @see SemiCircle3f, SemiCircle3v, SemiCircle4f, SemiCircle4vi, SemiCircle5fi
-------------------------------------------------------------------------------
function SemiCircle2v (xy1, radius)
	local segments = default_options.semicircle_segments
	
	SemiCircle5fi(xy1[1], xy1[2], radius, 0.0, segments)
	return true
end


-------------------------------------------------------------------------------
--- Draw a semicircle.
-- Uses a set number of segments.
-- @param x1 x-coord for the mid-point along the straight edge.
-- @param y1 y-coord for the mid-point along the straight edge.
-- @param radius length from x1,y1 to curved edge.
-- @param rotation amount to rotate in radians.
-- @usage draw.SemiCircle4f(15.0,55.0,5.0,math.pi*0.25)
-- @see default_options
-- @see SemiCircle2v, SemiCircle3f, SemiCircle3v, SemiCircle4vi, SemiCircle5fi
-------------------------------------------------------------------------------
function SemiCircle4f (x1, y1, radius, rotation)
	local segments = default_options.semicircle_segments
	
	SemiCircle5fi(x1, y1, radius, rotation, segments)
	return true
end


-------------------------------------------------------------------------------
--- Draw a semicircle.
-- Uses a set number of segments.
-- @param xy1 x-y coord for the mid-point along the straight edge.
-- @param radius length from xy1 to curved edge.
-- @param rotation amount to rotate in radians.
-- @usage draw.SemiCircle3v({15.0,55.0},5.0,math.pi*0.25)
-- @see default_options
-- @see SemiCircle2v, SemiCircle3f, SemiCircle4f, SemiCircle4vi, SemiCircle5fi
-------------------------------------------------------------------------------
function SemiCircle3v (xy1, radius, rotation)
	local segments = default_options.semicircle_segments
	
	SemiCircle5fi(xy1[1], xy1[2], radius, rotation, segments)
	return true
end


-------------------------------------------------------------------------------
--- Draw a semicircle.
-- @param x1 x-coord for the mid-point along the straight edge.
-- @param y1 y-coord for the mid-point along the straight edge.
-- @param radius length from x1,y1 to curved edge.
-- @param rotation amount to rotate in radians.
-- @param segments number of segments to use.
-- @usage draw.SemiCircle5fi(30.0,55.0,5.0,math.pi,20)
-- @see SemiCircle2v, SemiCircle3f, SemiCircle3v, SemiCircle4f, SemiCircle4vi
-------------------------------------------------------------------------------
function SemiCircle5fi (x1, y1, radius, rotation, segments)
	--rotation offset
	rotation = (math.pi * 0.5) + rotation
	
	--base
	local dx = math.sin(rotation) * radius
	local dy = math.cos(rotation) * radius
	WhiteboardDraw(x1-dx, y1-dy, x1+dx, y1+dy)

	--semi
	if (segments < 5) then
		segments = 5
	end

	local theta = math.pi / segments
	local sinv = math.sin(theta)
	local cosv = math.cos(theta)

	StartLongTask(function()
		for i=1,segments do
			local nx = cosv * dx - sinv * dy
			local ny = sinv * dx + cosv * dy

			WhiteboardDraw(x1+dx, y1+dy, x1+nx, y1+ny)
			
			dx = nx
			dy = ny
			
			-- yield frequency
			if (i % default_options.yield_frequency == 0) then
				YieldLongTask()
			end
		end
	end)
	return true
end


-------------------------------------------------------------------------------
--- Draw a semicircle.
-- @param xy1 x-y coord for the mid-point along the straight edge.
-- @param radius length from xy1 to curved edge.
-- @param rotation amount to rotate in radians.
-- @param segments number of segments to use.
-- @usage draw.SemiCircle4vi({30.0,55.0},5.0,math.pi,20)
-- @see SemiCircle2v, SemiCircle3f, SemiCircle3v, SemiCircle4f, SemiCircle5fi
-------------------------------------------------------------------------------
function SemiCircle4vi (xy1, radius, rotation, segments)
	SemiCircle5fi(xy1[1], xy1[2], radius, rotation, segments)
	return true
end


-------------------------------------------------------------------------------
--- Draw a quadrilateral using two points.
-- @param x1 x-coord of first point.
-- @param y1 y-coord of first point.
-- @param x2 x-coord of second point.
-- @param y2 y-coord of second point.
-- @usage draw.Quad4f(0.0,65.0,20.0,75.0)
-- @see Square2v, Square3f, Square3v, Square4f, Quad2v
-------------------------------------------------------------------------------
function Quad4f (x1, y1, x2, y2)
	WhiteboardDraw(x1, y1, x2, y1)
	WhiteboardDraw(x2, y1, x2, y2)
	WhiteboardDraw(x2, y2, x1, y2)
	WhiteboardDraw(x1, y2, x1, y1)
	return true
end


-------------------------------------------------------------------------------
--- Draw a quadrilateral using two points.
-- @param xy1 x-y coord of first point.
-- @param xy2 x-y coord of second point.
-- @usage draw.Quad2v({0.0,65.0},{20.0,75.0})
-- @see Square2v, Square3f, Square3v, Square4f, Quad4f
-------------------------------------------------------------------------------
function Quad2v (xy1, xy2)
	Quad4f (xy1[1], xy1[2], xy2[1], xy2[2])
	return true
end

-------------------------------------------------------------------------------
--- Draw a square
-- @param cx x-coord of centre point.
-- @param cy y-coord of centre point.
-- @param length length of an edge.
-- @usage draw.Square3f(0.0,85.0,5.0)
-- @see Square2v, Square3v, Square4f, Quad4f, Quad2v
-------------------------------------------------------------------------------
function Square3f (cx, cy, length)
	local x1 = cx - (length * 0.5)
	local y1 = cy - (length * 0.5)
	local x2 = cx + (length * 0.5)
	local y2 = cy + (length * 0.5)
	
	WhiteboardDraw(x1, y1, x2, y1)
	WhiteboardDraw(x2, y1, x2, y2)
	WhiteboardDraw(x2, y2, x1, y2)
	WhiteboardDraw(x1, y2, x1, y1)
	return true
end


-------------------------------------------------------------------------------
--- Draw a square
-- @param cxy x-y coord of centre point.
-- @param length length of an edge.
-- @usage draw.Square2v({0.0,85.0},5.0)
-- @see Square3f, Square3v, Square4f, Quad4f, Quad2v
-------------------------------------------------------------------------------
function Square2v (cxy, length)
	Square3f (cxy[1], cxy[2], length)
	return true
end


-------------------------------------------------------------------------------
--- Draw a square
-- @param cx x-coord of centre point.
-- @param cy y-coord of centre point.
-- @param length length of a side.
-- @param rotation amount to rotate in radians.
-- @usage draw.Square4f(15.0,85.0,10.0,math.pi*0.25)
-- @see Square2v, Square3f, Square3v, Quad4f, Quad2v
-------------------------------------------------------------------------------
function Square4f (cx, cy, length, rotation)
	local radius = length * 0.5
	local theta = (math.pi * 0.25) - rotation
	local nx = math.sin(theta) * radius
	local ny = math.cos(theta) * radius

	WhiteboardDraw(cx-nx, cy+ny, cx-ny, cy-nx)	-- topleft to bottomleft
	WhiteboardDraw(cx+nx, cy-ny, cx+ny, cy+nx)	-- bottomright to topright
	WhiteboardDraw(cx-nx, cy+ny, cx+ny, cy+nx)	-- topleft to topright
	WhiteboardDraw(cx-ny, cy-nx, cx+nx, cy-ny)	-- bottomleft to bottomright
	return true
end


-------------------------------------------------------------------------------
--- Draw a square
-- @param cxy x-y coord of centre point.
-- @param length length of a side.
-- @param rotation amount to rotate in radians.
-- @usage draw.Square3v({15.0,85.0},10.0,math.pi*0.25)
-- @see Square2v, Square3f, Square4f, Quad4f, Quad2v
-------------------------------------------------------------------------------
function Square3v (cxy, length, rotation)
	Square4f(cxy[1], cxy[2], length, rotation)
	return true
end


-------------------------------------------------------------------------------
--- Draw a teapot.
-- @param cx x-coord of centre point.
-- @param cy y-coord of centre point.
-- @param size scale of teapot.
-- @usage draw.Teapot3f(0.0,-15.0,15.0)
-- @see teapot_data
-- @see Teapot2v, Teapot3v, Teapot4f
-------------------------------------------------------------------------------
function Teapot3f (cx, cy, size)
	local x1, x2, y1, y2
	
	local startindex = 1
	local i = 1
	StartLongTask(function()
		while (i < #teapot_data) do
			x1 = cx + teapot_data[i][1] * size
			y1 = cy + teapot_data[i][2] * size
			
			if (teapot_data[i+1][1] == 'b' and teapot_data[i+1][2] == 'b') then
				x2 = cx + teapot_data[startindex][1] * size
				y2 = cy + teapot_data[startindex][2] * size
				
				startindex = i + 2
				i = i+1
			else
				x2 = cx + teapot_data[i+1][1] * size
				y2 = cy + teapot_data[i+1][2] * size
			end
			
			WhiteboardDraw(x1, y1, x2, y2)

			i = i+1
			
			-- yield frequency
			if (i % default_options.yield_frequency == 0) then
				YieldLongTask()
			end
		end
		
		x1 = cx + teapot_data[i][1] * size
		y1 = cy + teapot_data[i][2] * size
		x2 = cx + teapot_data[startindex][1] * size
		y2 = cy + teapot_data[startindex][2] * size
		WhiteboardDraw(x1, y1, x2, y2)
	end)

	return true
end


-------------------------------------------------------------------------------
--- Draw a teapot.
-- @param cxy x-y coord of centre point.
-- @param size scale of teapot.
-- @usage draw.Teapot2v({0.0,-15.0},15.0)
-- @see teapot_data
-- @see Teapot3f, Teapot3v, Teapot4f
-------------------------------------------------------------------------------
function Teapot2v (cxy, size)
	Teapot3f(cxy[1], cxy[2], size)
end


-------------------------------------------------------------------------------
--- Trigonmetry to rotate point 
-- @param cx x-coord to rotate around.
-- @param cy y-coord to rotate around.
-- @param coord point to be rotated.
-- @param scale scale point/length. Use 1.0 to not scale.
-- @param sinv sin value for angle of rotation i.e. sin(angle)
-- @param cosv cos value for angle of rotation i.e. cos(angle)
-------------------------------------------------------------------------------
function TrigRotate6f (cx, cy, coord, scale, sinv, cosv)
	local x = coord[1] * scale
	local y = coord[2] * scale
	local x1 = cx + x * cosv + y * sinv
	local y1 = cy + y * cosv - x * sinv
	
	return x1, y1
end


-------------------------------------------------------------------------------
--- Draw a teapot.
-- @param cx x-coord of centre point.
-- @param cy y-coord of centre point.
-- @param size scale of teapot.
-- @param rotation amount of rotation in radians.
-- @usage draw.IsoTriangle4f(30.0,100.0,10.0,math.pi*0.2)
-- @see teapot_data
-- @see Teapot2v, Teapot3f, Teapot3v
-------------------------------------------------------------------------------
function Teapot4f (cx, cy, size, rotation)
	local x1, x2, y1, y2
	local x
	local y

	local sinv = math.sin(rotation)
	local cosv = math.cos(rotation)
	
	local startindex = 1
	local i = 1
	StartLongTask(function()
		while (i < # teapot_data) do
			x1, y1 = TrigRotate6f(cx, cy, teapot_data[i], size, sinv, cosv)
			
			if (teapot_data[i+1][1] == 'b' and teapot_data[i+1][2] == 'b') then
				x2, y2 = TrigRotate6f(cx, cy, teapot_data[startindex], size, sinv, cosv)

				startindex = i + 2
				i = i + 1
			else
				x2, y2 = TrigRotate6f(cx, cy, teapot_data[i+1], size, sinv, cosv)
			end
			
			WhiteboardDraw(x1, y1, x2, y2)

			i = i + 1
			
			if (i % default_options.yield_frequency == 0) then
				YieldLongTask()
			end
		end
		
		x1, y1 = TrigRotate6f(cx, cy, teapot_data[i], size, sinv, cosv)
		x2, y2 = TrigRotate6f(cx, cy, teapot_data[startindex], size, sinv, cosv)
		WhiteboardDraw(x1, y1, x2, y2)	
	end)
	return true
end


-------------------------------------------------------------------------------
--- Draw a teapot.
-- @param cxy x-y coord of centre point.
-- @param size scale of teapot.
-- @param rotation amount of rotation in radians.
-- @usage draw.Teapot3v({15.0,-15.0},7.0,math.pi*-0.25)
-- @see teapot_data
-- @see Teapot2v, Teapot3f, Teapot4f
-------------------------------------------------------------------------------
function Teapot3v (cxy, size, rotation)
	Teapot4f(cxy[1], cxy[2], size, rotation)
end


-------------------------------------------------------------------------------
--- Compute and draw a rotated triangle.
-- @param cx x-coord of centre.
-- @param cy y-coord of centre.
-- @param dx length from centre to x-most point.
-- @param dy length from centre to y-most point.
-- @param sinv sin value for angle of rotation i.e. sin(angle).
-- @param cosv cos value for angle of rotation i.e. cos(angle).
-------------------------------------------------------------------------------
function TrigTriangle (cx, cy, dx, dy, sinv, cosv)
	local x = 0.0
	local y = dy
	local x1 = cx + x * cosv + y * sinv
	local y1 = cy + y * cosv - x * sinv

	x = dx
	y = -dy
	local x2 = cx + x * cosv + y * sinv
	local y2 = cy + y * cosv - x * sinv
	
	x = -dx
	y = -dy
	local x3 = cx + x * cosv + y * sinv
	local y3 = cy + y * cosv - x * sinv

	WhiteboardDraw(x1, y1, x2, y2)
	WhiteboardDraw(x2, y2, x3, y3)
	WhiteboardDraw(x3, y3, x1, y1)
	return true
end


-------------------------------------------------------------------------------
--- Draw a equilateral triangle
-- @param cx x-coord of centre point.
-- @param cy y-coord of centre point.
-- @param length length of an edge.
-- @usage draw.EqTriangle3f(0.0,100.0,10.0)
-- @see EqTriangle2v, EqTriangle3v, EqTriangle4f
-- @see IsoTriangle3v, IsoTriangle4f, IsoTriangle4v, IsoTriangle5f
-- @see Triangle3v, Triangle6f
-------------------------------------------------------------------------------
function EqTriangle3f (cx, cy, length)
	local nx = length * 0.5
	local ny = math.tan(math.pi/3) * nx * 0.5

	WhiteboardDraw(cx-nx, cy-ny, cx, cy+ny)		--bottomleft to top
	WhiteboardDraw(cx, cy+ny, cx+nx, cy-ny)		--top to bottomright
	WhiteboardDraw(cx+nx, cy-ny, cx-nx, cy-ny)	--bottomright to bottomleft
	return true
end


-------------------------------------------------------------------------------
--- Draw a equilateral triangle
-- @param cxy x-y coord of centre point.
-- @param length length of an edge.
-- @usage draw.EqTriangle2v({0.0,100.0},10.0)
-- @see EqTriangle3f, EqTriangle3v, EqTriangle4f
-- @see IsoTriangle3v, IsoTriangle4f, IsoTriangle4v, IsoTriangle5f
-- @see Triangle3v, Triangle6f
-------------------------------------------------------------------------------
function EqTriangle2v (cxy, length)
	EqTriangle3f (cxy[1], cxy[2], length)
	return true
end


-------------------------------------------------------------------------------
--- Draw a equilateral triangle.
-- @param cx x-coord of centre point.
-- @param cy y-coord of centre point.
-- @param length length of an edge.
-- @param rotation amount to rotate in radians.
-- @usage draw.EqTriangle4f(15.0,100.0,10.0,math.pi*0.25)
-- @see EqTriangle2v, EqTriangle3f, EqTriangle3v
-- @see IsoTriangle3v, IsoTriangle4f, IsoTriangle4v, IsoTriangle5f
-- @see Triangle3v, Triangle6f
-------------------------------------------------------------------------------
function EqTriangle4f (cx, cy, length, rotation)
	local sinv = math.sin(rotation)
	local cosv = math.cos(rotation)
	local dx = length * 0.5
	local dy = math.tan(math.pi/3.0) * 0.5 * dx

	TrigTriangle(cx, cy, dx, dy, sinv, cosv)
	return true
end


-------------------------------------------------------------------------------
--- Draw a equilateral triangle.
-- @param cx x-y coord of centre point.
-- @param length length of an edge.
-- @param rotation amount to rotate in radians.
-- @usage draw.EqTriangle3v({15.0,100.0},10.0,math.pi*0.25)
-- @see EqTriangle2v, EqTriangle3f, EqTriangle3v, EqTriangle4f
-- @see IsoTriangle4f, IsoTriangle4v, IsoTriangle5f
-- @see Triangle3v, Triangle6f
-------------------------------------------------------------------------------
function EqTriangle3v (cxy, length, rotation)
	EqTriangle4f (cxy[1], cxy[2], length, rotation)
	return true
end


-------------------------------------------------------------------------------
--- Draw an isosceles triangle.
-- @param cx x-coord of centre point.
-- @param cy y-coord of centre point.
-- @param length length of an edge.
-- @param angle size of the top angle in radians.
-- @usage draw.IsoTriangle4f(30.0,100.0,10.0,math.pi*0.2)
-- @see EqTriangle2v, EqTriangle3f, EqTriangle3v, EqTriangle4f
-- @see IsoTriangle3v, IsoTriangle4v, IsoTriangle5f
-- @see Triangle3v, Triangle6f
-------------------------------------------------------------------------------
function IsoTriangle4f (cx, cy, length, angle)
	local nx = length * 0.5
	local ny = math.tan(angle) * nx * 0.5

	WhiteboardDraw(cx-nx, cy-ny, cx, cy+ny)		--bottomleft to top
	WhiteboardDraw(cx, cy+ny, cx+nx, cy-ny)		--top to bottomright
	WhiteboardDraw(cx+nx, cy-ny, cx-nx, cy-ny)	--bottomright to bottomleft
	return true
end


-------------------------------------------------------------------------------
--- Draw an isosceles triangle.
-- @param cxy x-ycoord of centre point.
-- @param length length of an edge.
-- @param angle size of the top angle in radians.
-- @usage draw.IsoTriangle3v({30.0,100.0},10.0,math.pi*0.2)
-- @see EqTriangle2v, EqTriangle3f, EqTriangle3v, EqTriangle4f
-- @see IsoTriangle4f, IsoTriangle4v, IsoTriangle5f
-- @see Triangle3v, Triangle6f
-------------------------------------------------------------------------------
function IsoTriangle3v (cxy, length, angle)
	IsoTriangle4f(cxy[1], cxy[2], length, angle)
	return true
end


-------------------------------------------------------------------------------
--- Draw an isosceles triangle.
-- @param cx x-coord of centre point.
-- @param cy y-coord of centre point.
-- @param length length of an edge.
-- @param angle size of the top angle in radians.
-- @param rotation amount to rotate in radians.
-- @usage draw.IsoTriangle5f(50.0,100.0,10.0,math.pi*0.4,math.pi*0.15)
-- @see EqTriangle2v, EqTriangle3f, EqTriangle3v, EqTriangle4f
-- @see IsoTriangle3v, IsoTriangle4f, IsoTriangle4v
-- @see Triangle3v, Triangle6f
-------------------------------------------------------------------------------
function IsoTriangle5f (cx, cy, length, angle, rotation)
	local sinv = math.sin(rotation)
	local cosv = math.cos(rotation)
	local dx = length * 0.5
	local dy = math.tan(angle) * 0.5 * dx

	TrigTriangle(cx, cy, dx, dy, sinv, cosv)
	return true
end


-------------------------------------------------------------------------------
--- Draw an isosceles triangle.
-- @param cxy x-y coord of centre point.
-- @param length length of an edge.
-- @param angle size of the top angle in radians.
-- @param rotation amount to rotate in radians.
-- @usage draw.IsoTriangle4v({50.0,100.0},10.0,math.pi*0.4,math.pi*0.15)
-- @see EqTriangle2v, EqTriangle3f, EqTriangle3v, EqTriangle4f
-- @see IsoTriangle3v, IsoTriangle4f, IsoTriangle5f
-- @see Triangle3v, Triangle6f
-------------------------------------------------------------------------------
function IsoTriangle4v (cxy, length, angle, rotation)
	IsoTriangle5f(cxy[1], cxy[2], length, angle, rotation)
	return true
end


-------------------------------------------------------------------------------
--- Draw a triangle using three points.
-- @param x1 x-coord of first point.
-- @param y1 y-coord of first point.
-- @param x2 x-coord of second point.
-- @param y2 y-coord of second point.
-- @param x3 x-coord of third point.
-- @param y3 y-coord of third point.
-- @usage draw.Triangle6f(65.0,100.0,65.0,110.0,90.0,100.0)
-- @see EqTriangle2v, EqTriangle3f, EqTriangle3v, EqTriangle4f
-- @see IsoTriangle3v, IsoTriangle4f, IsoTriangle4v, IsoTriangle5f
-- @see Triangle3v
-------------------------------------------------------------------------------
function Triangle6f (x1, y1, x2, y2, x3, y3)
	WhiteboardDraw(x1, y1, x2, y2)
	WhiteboardDraw(x2, y2, x3, y3)
	WhiteboardDraw(x3, y3, x1, y1)
	return true
end


-------------------------------------------------------------------------------
--- Draw a triangle using three points.
-- @param xy1 x-y coord of first point.
-- @param xy2 x-y coord of second point.
-- @param xy3 x-y coord of third point.
-- @usage draw.Teapot3v({15.0,-15.0},7.0,math.pi*-0.25)
-- @see EqTriangle2v, EqTriangle3f, EqTriangle3v, EqTriangle4f
-- @see IsoTriangle3v, IsoTriangle4f, IsoTriangle4v, IsoTriangle5f
-- @see Triangle6f
-------------------------------------------------------------------------------
function Triangle3v (xy1, xy2, xy3)
	WhiteboardDraw(xy1[1], xy1[2], xy2[1], xy2[2])
	WhiteboardDraw(xy2[1], xy2[2], xy3[1], xy3[2])
	WhiteboardDraw(xy3[1], xy3[2], xy1[1], xy1[2])
	return true
end
