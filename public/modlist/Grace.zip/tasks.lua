-- *********************************
-- Grace task group task definitions
-- *********************************
-- Sean McPhail, 2010
-- smc10028@gmail.com

function TaskSweepAndClear(this_task_group) -- takes task group reference as input
-- Minimal implementation!

-- ****************************
-- do test for state transition
-- ****************************
-- case on current state of taskgroup

--scout
-- if gives enemy sighted exit code change current state to fight
-- if gives at target exit code change current state to idle

--print("Task group state: ",this_task_group["state"])

if this_task_group["state"]=="Scout" then
-- scout toward target spot
-- check for enemy

-- multiply task group map by enemy maps
-- if max > zero set state to Fight

   if MaxMap(MultiplyMaps(GrowMap(GrowMap(this_task_group["map"])),UNIT_MAPS[enemy_team_id]["Mobile"]))>0 then

      print("Task Group ",this_task_group["number"]," entering Fight activity")
      this_task_group["state"]="Fight"

   end

elseif this_task_group["state"]=="Fight" then

-- check for no enemies

-- multiply task group map by enemy maps
-- if max == zero set state to Scout 
   if (MaxMap(MultiplyMaps(GrowMap(GrowMap(this_task_group["map"])),UNIT_MAPS[enemy_team_id]["Mobile"]))==0 and MaxMap(this_task_group["map"])>0) then

      print("Task Group ",this_task_group["number"]," entering Scout activity")
      this_task_group["state"]="Scout"
   end

elseif this_task_group["state"]=="Idle" then
-- at target spot

-- check for enemy
   if MaxMap(MultiplyMaps(GrowMap(GrowMap(this_task_group["map"])),UNIT_MAPS[enemy_team_id]["Mobile"]))>0 then
      print("Task Group ",this_task_group["number"]," entering Fight activity")
      this_task_group["state"]="Fight"
   end
end

-- ****************************
-- separate any fighters into their own group

for count, id in pairs(this_task_group["units"]) do

if UNIT_DATA[id]["type"]=="Fighter" then
EXTRA_UNIT_DATA[id]["data"]["TG"]=CreateTaskGroup(nil,"Intercept",{[id]=id},"Fighter Intercept",0,0,nil,"",{})
this_task_group["units"][id]=nil
end
end

-- ****************************
-- do activity
-- ****************************
-- case on current state of taskgroup


if this_task_group["state"]=="Scout" then
-- scout toward target spot

   if ActivityScout(this_task_group)=="At target" then
      this_task_group["state"]="Idle"
   end

elseif this_task_group["state"]=="Fight" then
-- fight enemy
ActivityFight(this_task_group)
elseif this_task_group["state"]=="Idle" then
-- at target spot
ActivityIdle(this_task_group)

end

-- ***************************
-- return
-- ***************************
return this_task_group["state"]
-- return state code

end


function TaskTerritoryAirDefence(this_task_group)
-- just check for DEFCON at this level
if DEFCON<4 then
   ActivityTAD(this_task_group)
end
end



function TaskSilos(this_task_group)
end



function TaskCoastGuard(this_task_group)
end



function TaskIntercept(this_task_group)
-- use a three state FSM to allow fighters to fight on the way out and on the way back but distinguish
-- the return journey so that when this is complete the fighter will land

if this_task_group["state"]=="Fighter Intercept" then
   ActivityFighterIntercept(this_task_group)
elseif this_task_group["state"]=="Land Fighter" then
   ActivityLandFighter(this_task_group)
end

end


function TaskBomberPatrol()
end

