-- **************************
-- Grace unit behaviour atoms
-- **************************
-- Sean McPhail, 2010
-- smc10028@gmail.com

-- ** Attack atom **
function AtomAttack()
end

-- ** Move atom **
function AtomMove(id,targ_long,targ_lat,force)


current_move_long, current_move_lat= GetMovementTargetLocation(id)
current_lat=GetLatitude (id)
current_long=GetLongitude (id)


if math.abs(current_long-targ_long)>1 or math.abs(current_lat-targ_lat)>1 then 

   if (current_move_long==0 or force==true) then

 --    local close_unit_id,close_unit_dist=closest_units(id)
 --    print("Closest BS to unit ",id,"is: ",close_unit_id,", ",close_unit_dist)
 --    print("Target for unit ",id,": ", targ_long," ",targ_lat)
     SetMovementTarget (id ,targ_long,targ_lat)

   
   end

else
   return "At target"
end
   
   
end


function AtomAirbaseWait()
end


function AtomScoutFighter(this_task_group,id)
local targ_num, targ_x, targ_y, targ_long,targ_lat

targ_num, targ_x, targ_y =MaxMap(MultiplyMaps(MultiplyMaps(GrowMap(MAP[k.territory]),RandomMap(10)),InverseMap(MAP["visible_now"])))
targ_long,targ_lat=MapCoordToLongLat(targ_x,targ_y)

-- if target not to far to get back...
if math.sqrt((UNIT_DATA[id]["longitude"]-targ_long)^2+(UNIT_DATA[id]["latitude"]-targ_lat)^2)<18 then
   print("Airbase ",id," sending scout fighter to long: ",targ_long,", lat:",targ_lat)
   SetState(id,0)   
   SetActionTarget(id,nil,targ_long,targ_lat)

-- set airbase fighters into intercept task group
   EXTRA_UNIT_DATA[id]["time"]=GAME_TIME+150
   EXTRA_UNIT_DATA[id]["data"]["fighter TG"]=CreateTaskGroup(nil,"Intercept",{},"Fighter Intercept",targ_long,targ_lat,nil,"",{})
end
end


function AtomSendFighter(this_task_group,id)
-- launch fighter to muster co-ordinates
-- if not out of range
if math.sqrt((UNIT_DATA[id]["longitude"]-targ_long)^2+(UNIT_DATA[id]["latitude"]-targ_lat)^2)<45 then
   if GetStateCount(id,0)>0 and GetStateTimer(id)<1 then
      print("Airbase ",id," sending fighter to long: ",this_task_group["targ_long"],", lat:",this_task_group["targ_lat"])
      SetState(id,0)   
      SetActionTarget(id,nil,this_task_group["targ_long"],this_task_group["targ_lat"])
      EXTRA_UNIT_DATA[id]["time"]=GAME_TIME+150
-- set fighter to travel mode and create new task group
      EXTRA_UNIT_DATA[id]["data"]["fighter TG"]=CreateTaskGroup(nil,"Intercept",{},"Fighter Intercept",0,0,nil,"",{})
   end
end
end


function AtomMusterBombers(this_task_group,id)
-- launch bomber to muster co-ordinates

if GetStateCount(id,1)>0 and GetStateTimer(id)<1 then
      print("Airbase ",id," mustering bomber to long: ",this_task_group["targ_long"],", lat:",this_task_group["targ_lat"]," Time:",EXTRA_UNIT_DATA[id]["time"]," ",GAME_TIME)
      SetState(id,1)   
      SetActionTarget(id,nil,this_task_group["targ_long"],this_task_group["targ_lat"])
      EXTRA_UNIT_DATA[id]["time"]=GAME_TIME+150
      EXTRA_UNIT_DATA[id]["data"]["bomber TG"]=CreateTaskGroup(nil,"Bomber Patrol",{},"",0,0,nil,"",{})
-- set bomber to travel mode and create new task group
end
end


function AtomEqualiseFighters(this_task_group,this_airbase)
--loop over task group units

for _, id in pairs(this_task_group["units"]) do
-- if airbases and conditions met send fighter

   if UNIT_DATA[id]["type"]=="AirBase" and id~=this_airbase and GetStateCount(id,0)+1<GetStateCount(this_airbase,0) and GetStateTimer(this_airbase)<1 then
      print("Airbase ",this_airbase," fighter re-supply to airbase ",id)
      SetState(this_airbase,0)  
      --SetActionTarget(this_airbase,nil,(0.1*UNIT_DATA[this_airbase]["longitude"]+0.9*UNIT_DATA[id]["longitude"]),(0.1*UNIT_DATA[this_airbase]["latitude"]+0.9*UNIT_DATA[id]["latitude"]))
SetActionTarget(this_airbase,id)
	  
	  -- set figher to move mode
   EXTRA_UNIT_DATA[id]["time"]=GAME_TIME+150
   EXTRA_UNIT_DATA[id]["data"]["fighter TG"]=CreateTaskGroup(nil,"Intercept",{},"Land Fighter",0,0,nil,"",{})
-- break to avoid queuing multiple fighters 
   break
   end
end
end


function AtomEqualiseBombers(this_task_group,this_airbase)
--loop over task group units
for _, id in pairs(this_task_group["units"]) do
-- if airbases and conditions met send bomber

   if UNIT_DATA[id]["type"]=="AirBase" and id~=this_airbase and GetStateTimer(this_airbase)<1 and GetStateCount(this_airbase,1)>0 and GetNukeCount(this_airbase)==0 and GetNukeCount(id)>GetStateCount(id,1) then

      print("Airbase ",this_airbase," bomber re-supply to airbase ",id)

      SetState(this_airbase,1)   
      --SetActionTarget(this_airbase,nil,(0.1*UNIT_DATA[this_airbase]["longitude"]+0.9*UNIT_DATA[id]["longitude"]),(0.1*UNIT_DATA[this_airbase]["latitude"]+0.9*UNIT_DATA[id]["latitude"]))
      SetActionTarget(this_airbase,id)
      EXTRA_UNIT_DATA[id]["time"]=GAME_TIME+150
-- set bomber to move mode
      EXTRA_UNIT_DATA[id]["data"]["bomber TG"]=CreateTaskGroup(nil,"Bomber Patrol",{},"",0,0,nil,"",{})
      break
   end
end
end


function AtomSupplyFightersToCarriers(this_task_group,id,close_units)
-- if closest friendly carrier less than fighter range away
if close_units[grace_team_id]["dist"]["Carrier"]<42 and GetStateCount(id,0)>4 and GetStateCount(close_units[grace_team_id]["unit"]["Carrier"],0)<4 then

   if GetStateCount(id,0)>0 and GetStateTimer(id)<1 then
      print("Airbase ",id," fighter re-supply to carrier ",close_units[grace_team_id]["unit"]["Carrier"])

      SetState(id,0)   
      --SetActionTarget(id,nil,(0.1*UNIT_DATA[id]["longitude"]+0.9*UNIT_DATA[close_units[grace_team_id]["unit"]["Carrier"]]["longitude"]),(0.1*UNIT_DATA[id]["latitude"]+0.9*UNIT_DATA[close_units[grace_team_id]["unit"]["Carrier"]]["latitude"]))
      SetActionTarget(id,close_units[grace_team_id]["unit"]["Carrier"])
	  -- set fighter to travel mode
      EXTRA_UNIT_DATA[id]["time"]=GAME_TIME+150
      EXTRA_UNIT_DATA[id]["data"]["fighter TG"]=CreateTaskGroup(nil,"Intercept",{},"Land Fighter",0,0,nil,"",{})
   end
end
end


function AtomSupplyBombersToCarriers()
-- if closest friendly carrier has nukes and airbase has bombers without nukes
if close_units[grace_team_id]["dist"]["Carrier"]<100 and GetStateCount(id,1)>0 and GetNukeCount(id)==0 and GetNukeCount(close_units[grace_team_id]["unit"]["Carrier"])>GetStateCount(close_units[grace_team_id]["unit"]["Carrier"],1) and GetStateCount(close_units[grace_team_id]["unit"]["Carrier"],1)<2 then

   if GetStateCount(id,1)>0 and GetStateTimer(id)<1 then
      print("Airbase ",id," bomber re-supply to carrier ",close_units[grace_team_id]["unit"]["Carrier"])

      SetState(id,1)   
      --SetActionTarget(id,nil,(0.1*UNIT_DATA[id]["longitude"]+0.9*UNIT_DATA[close_units[grace_team_id]["unit"]["Carrier"]]["longitude"]),(0.1*UNIT_DATA[id]["latitude"]+0.9*UNIT_DATA[close_units[grace_team_id]["unit"]["Carrier"]]["latitude"]))
      SetActionTarget(id,close_units[grace_team_id]["unit"]["Carrier"])
	  -- set fighter to travel mode
      EXTRA_UNIT_DATA[id]["time"]=GAME_TIME+150
      EXTRA_UNIT_DATA[id]["data"]["bomber TG"]=CreateTaskGroup(nil,"Bomber Patrol",{},"",0,0,nil,"",{})
   end
end
end











