-- *************************
-- Grace main loop & engines
-- *************************
-- Sean McPhail, 2010
-- smc10028@gmail.com

function time_management()
--[[
This is Grace's main loop, which runs as a long task. Grace calls a single engine, which runs and then yields. Which engine is called is determined by a series of count down variables. About half the ticks are devoted to processing low level task group actions, the rest to higher level functions. As task group code gets more complicated it may be necessary to execute it over several ticks.
]]

local strat_count=11
local TGC_count=6 
local fact_count=0 -- force fact engine to run in the first tick
local belief_count=21
local task_count=1

while 1==1 do
   
   strat_count=strat_count-1
   fact_count=fact_count-1
   belief_count=belief_count-1
   TGC_count=TGC_count-1
   task_count=task_count-1
   
   
   if strat_count<0 then
      grace_strategy()
      strat_count=10
      YieldLongTask()
   end
   
   if fact_count<0 then
      fact_engine()
      fact_count=5
      YieldLongTask()
   end
 
   if belief_count<0 then
      belief_engine()
      belief_count=20
      YieldLongTask()
   end
   
   if TGC_count<0 then
      grace_TGC()
      TGC_count=6
      YieldLongTask()
   end
   
   if task_count<0 then
-- if no other engines want to run then run task_engine
      task_engine()
      task_count=1
      YieldLongTask()
   end
   
end
end



function grace_strategy()

-- compare facts against strategy and compute score
-- change to best new strategy if fitness high enough

end



function grace_TGC()

-- process tactical priorities
--	Check for targets of opportunity
--	Check for unhandled enemies (including outnumbered task groups)
--	Check for win-opportunities

-- add tactical priorities to strategic priorities

-- assess fitness of current plan against facts

-- fitness above threshold? - allocate unused units to closest task group

-- fitness below threshold? - re-allocate TGs

end



function task_engine()

-- update unit data table with info current to this tick
UNIT_DATA =  GetAllUnitData()

-- loop over each task group and do some admin

for group_id, this_group in pairs(TASK_GROUP) do

-- first check for destroyed units - DEFCON crashes if you try and address these
-- loop over units and remove any unit from the task groups that isn't in the unit table
-- i.e. if some have been destroyed

--    unit_count=0
    for unit_id, this_unit in pairs(this_group["units"]) do 
--d       unit_count=unit_count+1
       if UNIT_DATA[TASK_GROUP[group_id]["units"][unit_id]]==nil then
          TASK_GROUP[group_id]["units"][unit_id]=nil
       else


  EXTRA_UNIT_DATA[unit_id]["data"]["TG"]=group_id
-- make sure each carrier captures any fighters or bombers into its own task group
-- is this the best place for this check??
          if UNIT_DATA[unit_id]["type"]=="Carrier" then
             EXTRA_UNIT_DATA[unit_id]["data"]["fighter TG"]=group_id
             EXTRA_UNIT_DATA[unit_id]["data"]["bomber TG"]=group_id
          end
       end
    end

-- generate TASK_GROUP map	
   TASK_GROUP[group_id]["map"]=GenerateUnitMap(TASK_GROUP[group_id]["units"])

-- check for empty task groups
--   if (unit_count==0 and TASK_GROUP[group_id]["task"]~="Empty") then
--      print("Task Group ",TASK_GROUP[group_id]["number"]," empty")
--     TASK_GROUP[group_id]["task"]="Empty"
--   end
	
-- pass the TASK_GROUP to the appropriate task function
	
   if TASK_GROUP[group_id]["task"]=="Sweep and Clear" then
      TaskSweepAndClear(this_group)
   elseif TASK_GROUP[group_id]["task"]=="Territory Air Defence" then
      TaskTerritoryAirDefence(this_group)
   elseif TASK_GROUP[group_id]["task"]=="Silos" then
      TaskSilos(this_group)
   elseif TASK_GROUP[group_id]["task"]=="Coast Guard" then
      TaskCoastGuard(this_group)
   elseif TASK_GROUP[group_id]["task"]=="Intercept" then
      TaskIntercept(this_group)
   elseif TASK_GROUP[group_id]["task"]=="Bomber Patrol" then
      TaskBomberPatrol(this_group)
   end

end
end



function fact_engine()
-- update various bits of knowledge about the world

--*************************************************
-- update the EXTRA_UNIT_DATA table
for id, data in pairs(UNIT_DATA) do
-- create entry in EXTRA_UNIT_TABLE if necessary
   if EXTRA_UNIT_DATA[id]==nil then
      EXTRA_UNIT_DATA[id]={}
      EXTRA_UNIT_DATA[id]["data"]={}
      EXTRA_UNIT_DATA[id]["data"]["TG"]=nil

-- initialise plane launch data for units which can launch
      if UNIT_DATA[id]["type"]=="Carrier" or UNIT_DATA[id]["type"]=="AirBase" then
         EXTRA_UNIT_DATA[id]["data"]["fighter TG"]=0
         EXTRA_UNIT_DATA[id]["data"]["bomber TG"]=3
      end
      EXTRA_UNIT_DATA[id]["time"]=GAME_TIME
   end

--otherwise just update the long and lat
   EXTRA_UNIT_DATA[id]["longitude"]=UNIT_DATA[id]["longitude"]
   EXTRA_UNIT_DATA[id]["latitude"]=UNIT_DATA[id]["latitude"]
end

-- clean up extra unit data to remove dead units
for id, data in pairs(EXTRA_UNIT_DATA) do
   if UNIT_DATA[id]==nil then
      EXTRA_UNIT_DATA[id]=nil
   end
end


--*************************************************
-- also check for unallocated fighters or bombers and assign them to the task group
-- that is listed in the nearest carrier or airbase
for id, data in pairs(UNIT_DATA) do

   if UNIT_DATA[id]["team"]==grace_team_id and UNIT_DATA[id]["type"]=="Fighter" and EXTRA_UNIT_DATA[id]["data"]["TG"]==nil then

      local close_units=GetClosestUnits(id)
      local allocate_from= GetClosestOfPair(id,close_units[grace_team_id]["unit"]["AirBase"],close_units[grace_team_id]["dist"]["AirBase"],close_units[grace_team_id]["unit"]["Carrier"],close_units[grace_team_id]["dist"]["Carrier"])

      EXTRA_UNIT_DATA[id]["data"]["TG"]=EXTRA_UNIT_DATA[allocate_from]["data"]["fighter TG"]
      TASK_GROUP[EXTRA_UNIT_DATA[allocate_from]["data"]["fighter TG"]]["units"][id]=id
      print("Fighter ",id," allocated to task Group ",EXTRA_UNIT_DATA[allocate_from]["data"]["fighter TG"])
   end

-- do the same for bombers
   if UNIT_DATA[id]["team"]==grace_team_id and UNIT_DATA[id]["type"]=="Bomber" and EXTRA_UNIT_DATA[id]["data"]["TG"]==nil then

      local close_units=GetClosestUnits(id)
      local allocate_from= GetClosestOfPair(id,close_units[grace_team_id]["unit"]["AirBase"],close_units[grace_team_id]["dist"]["AirBase"],close_units[grace_team_id]["unit"]["Carrier"],close_units[grace_team_id]["dist"]["Carrier"])

      EXTRA_UNIT_DATA[id]["data"]["TG"]=EXTRA_UNIT_DATA[allocate_from]["data"]["bomber TG"]
      TASK_GROUP[EXTRA_UNIT_DATA[allocate_from]["data"]["bomber TG"]]["units"][id]=id
      print("Bomber ",id," allocated to task Group ",EXTRA_UNIT_DATA[allocate_from]["data"]["bomber TG"])
   end
end


--*************************************************
-- temporary hack to force TAD task group to send bombers to randomly selected fleet start point
if math.random()<0.5 then
TASK_GROUP[2]["targ_long"]=FLEET_CENTRE1.long 
TASK_GROUP[2]["targ_lat"]=FLEET_CENTRE1.lat 
else
TASK_GROUP[2]["targ_long"]=FLEET_CENTRE2.long 
TASK_GROUP[2]["targ_lat"]=FLEET_CENTRE2.lat 
end


--*************************************************
-- get defcon level
DEFCON=GetDefconLevel()


--*************************************************
-- generate unit maps
UNIT_DATA =  GetAllUnitData()
-- first generate unit lists
local unit_lists={}
unit_lists[grace_team_id]={["AirBase"]={},["BattleShip"]={},["Bomber"]={},["Carrier"]={},["Fighter"]={},["Nuke"]={},["RadarStation"]={},["Silo"]={},["Sub"]={}}

if enemy_team_id~=nil then
unit_lists[enemy_team_id]={["AirBase"]={},["BattleShip"]={},["Bomber"]={},["Carrier"]={},["Fighter"]={},["Nuke"]={},["RadarStation"]={},["Silo"]={},["Sub"]={}}
end

-- loop over all units
for id,data in pairs(UNIT_DATA) do
   -- if it's a valid unit type add the id to list of units
   if unit_lists[data.team][data.type]~=nil then
         unit_lists[data.team][data.type][id]=id
   end 	  
end

-- now turn enemy unit lists into maps
-- clear maps
UNIT_MAPS={}

UNIT_MAPS[grace_team_id]={["AirBase"]={},["BattleShip"]={},["Bomber"]={},["Carrier"]={},["Fighter"]={},["Nuke"]={},["RadarStation"]={},["Silo"]={},["Sub"]={}}

if enemy_team_id~=nil then
UNIT_MAPS[enemy_team_id]={["AirBase"]={},["BattleShip"]={},["Bomber"]={},["Carrier"]={},["Fighter"]={},["Nuke"]={},["RadarStation"]={},["Silo"]={},["Sub"]={}}
end

-- generate a map for each combination of team and unit type
for team_id,this_team in pairs(unit_lists) do
   for list_id,this_list in pairs(unit_lists[team_id]) do
     UNIT_MAPS[team_id][list_id]=GenerateUnitMap(this_list)
   end
end

--generate a few useful combinations
for team_id,this_team in pairs(unit_lists) do
   UNIT_MAPS[team_id]["Mobile"]=SumMaps(UNIT_MAPS[team_id]["BattleShip"],SumMaps(UNIT_MAPS[team_id]["Carrier"],SumMaps(UNIT_MAPS[team_id]["Sub"],SumMaps(UNIT_MAPS[team_id]["Fighter"],UNIT_MAPS[team_id]["Bomber"]))))
   UNIT_MAPS[team_id]["Ship"]=SumMaps(UNIT_MAPS[team_id]["BattleShip"],UNIT_MAPS[team_id]["Carrier"])
   UNIT_MAPS[team_id]["Structure"]=SumMaps(UNIT_MAPS[team_id]["Silo"],SumMaps(UNIT_MAPS[team_id]["RadarStation"],UNIT_MAPS[team_id]["AirBase"]))
end


--*************************************************
--generate map of currently visible map squares
MAP["visible_now"]=SumMaps(UNIT_MAPS[grace_team_id]["Mobile"],SumMaps(UNIT_MAPS[grace_team_id]["Structure"],GrowMap(UNIT_MAPS[grace_team_id]["RadarStation"])))


--*************************************************
-- generate population map

-- refresh population map for each team   
   for id,data in pairs(TEAMS) do
      MAP["population"][id]=CreateMap()
   end
   
--update populations in maps
   local x,y
   local other_pop=0
   
   for city_id, data in pairs(CITY_DATA) do
      CITY_DATA[city_id]["population"]= GetCityPopulation(city_id)
      x,y=LongLatToMapCoord(CITY_DATA[city_id]["longitude"],CITY_DATA[city_id]["latitude"])	  
      MAP["population"][CITY_DATA[city_id]["team"]][x][y]=MAP["population"][CITY_DATA[city_id]["team"]][x][y]+CITY_DATA[city_id]["population"]/1000000
   end

--*************************************************
-- generate defense zone

MAP["grace_defend"]=GrowMap(ThresholdMap(SumMaps(ThresholdMap(MAP["population"][grace_team_id],5), UNIT_MAPS[grace_team_id]["Structure"]),0.99))
MAP["enemy_targets"]=SumMaps(ThresholdMap(MAP["population"][enemy_team_id],1), UNIT_MAPS[grace_team_id]["Structure"])

-- display whiteboard map (once only)
--[[
if FIRST==nil then
FIRST=1
StartLongTask(function()
   SetupWhiteboard(MAP["Africa"])
   end)
end
]]
end


function belief_engine()
-- do reasoning
end


